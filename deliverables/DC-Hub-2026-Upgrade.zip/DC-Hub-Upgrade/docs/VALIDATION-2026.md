# Validation — November 2, 2026

All results below are from the current local source and digest-pinned PHP/Apache runtime. Synthetic test identities/records are used. No production data was accessed or changed.

| Check | Outcome | Scope |
|---|---|---|
| Apps Script backend | 56 passed | Service doubles, including direct signed API privacy/read-only denial, aliases/stable IDs/Affiliates, original-event projection, existing intake/calendar/Roam/migration/typing regression |
| Browser | 45 passed | Actual local PHP anonymous gates plus explicitly mocked authorized Workspace UI responses; mobile, read-only detail, local markets/resources, missing asset/map, day/week/month and three typing durations |
| Apache/PHP HTTP | 18 passed | Real auth/role/CSRF/traversal gates, ETag revalidation, private/no-store headers, authenticated mutation denial; synthetic sessions seeded via CLI only |
| PHP content | 7 passed | HTML sanitization and all 14 source script texts (including the eight latest DOCX imports) |
| PHP transport/cache | 8 passed | Real signing/session logic with a transport double; identity/permission cache separation |
| Typing engine | 9 passed | Duration, correction and WPM logic |
| Globe | 6 passed | Supported WebGL, mobile size, no-WebGL, reduced motion, missing texture and safe fallback |
| Market schema | 11 files passed | All eight requested markets represented, unique IDs, version hashes, original-note provenance; no verified coverage maps supplied |
| Static syntax | 29 JS/Apps Script files passed | Module-aware syntax, JSON parsing, passage synchronization, no runtime credentials/archives |
| PHP syntax | 14 runtime files passed | PHP 8.3 syntax checks |

Machine-readable current reports are in tests/; screenshots are in tests/evidence/. The supplied baseline browser report is preserved as baseline-browser-results.json and historical documentation is labeled accordingly. A passing local run is not a live Google Workspace acceptance result.

## Performance

Under concurrent synthetic 250 ms Workspace response delays, full dashboard readiness changed from **1042 ms to 756 ms (27.4% faster)**. First contentful paint changed from 212 ms to 176 ms. Both use three initial Workspace calls; the new version parallelizes schedule/analytics after bootstrap. Static Market/Resources navigation makes zero Workspace data calls. Session/in-memory caches reduce repeated reads without cross-account storage. These are single controlled local runs, not Hostinger/Google latency measurements or a performance guarantee.

## Uploaded-content update

The November 2 uploads additionally pass 73 source/text/formatting/provenance checks and 31 browser content checks. All eight supplied markets, including New Jersey, are now populated. See CONTENT-UPDATE-2026-11-02.md and tests/content-import-results.json / tests/content-browser-results.json. The existing 45-check browser suite is rerun for this package; the unchanged authentication/Apps Script/typing code retains the earlier scoped regression evidence.

## Not run live

Google consent/token exchange, deployed Sheets/Calendar authorization and data mapping, real Forms-trigger execution, real Roam delivery, live typing persistence, Hostinger permissions/rewrite/cache behavior and actual utility tariff/map verification remain unrun. See UPGRADE-2026.md for staging steps and precise prerequisites. No production rollout is implied.
