(function () {
  'use strict';
  const core = window.DCLeaderboardCore;
  const config = window.DC_LEADERBOARD_CONFIG || {};
  const boards = [...document.querySelectorAll('[data-leaderboard]')];
  const calendarRoot = document.querySelector('[data-team-calendar]');
  if (!core || (!boards.length && !calendarRoot && !document.querySelector('[data-campaign-list], [data-kpi]'))) return;
  const labels = { set: 'Appointments set', confirmed: 'Confirmed', completed: 'Completed', closedWon: 'Closed won', noShows: 'No shows' };
  const number = new Intl.NumberFormat('en-US');
  const refreshMs = Math.max(60, Number(config.refreshSeconds) || 60) * 1000;
  const endpoint = String(config.apiUrl || '').trim();
  const cacheKey = 'dc-leaderboard-v1:' + endpoint;
  let data = null, inFlight = null, lastError = '', sequence = 0;

  function el(tag, className, value) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (value !== undefined) element.textContent = value;
    return element;
  }
  function shortDate(day) { return new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' }).format(new Date(day + 'T12:00:00Z')); }
  function initials(name) { return name.trim().split(/\s+/).filter(Boolean).slice(0, 2).map(part => [...part][0]).join('').toUpperCase(); }
  function zoneLabel() { const zone = data ? data.timezone : config.reportingTimezone; return zone === 'America/Mexico_City' ? 'Mexico City time' : zone === 'America/New_York' ? 'Eastern Time' : zone || 'CRM time'; }
  function liveToday() { return core.todayInZone(data ? data.timezone : config.reportingTimezone || 'America/Mexico_City'); }
  function updatedTime() { return data ? new Intl.DateTimeFormat('en-US', { timeZone: data.timezone, hour: 'numeric', minute: '2-digit' }).format(new Date(data.generatedAt)) : ''; }

  function connection(node, state, message) {
    if (!node) return;
    node.dataset.state = state;
    const dot = el('span', 'lb-dot');
    node.replaceChildren(dot, document.createTextNode(message));
  }
  function stateText() {
    if (!endpoint) return ['pending', 'CRM connection pending'];
    if (lastError) return ['delayed', data ? 'Update delayed · last ' + updatedTime() : 'Connection unavailable'];
    if (inFlight) return ['pending', data ? 'Updating standings' : 'Connecting to CRM'];
    return data ? ['live', 'Updated ' + updatedTime()] : ['pending', 'Connecting to CRM'];
  }
  function updateConnections() {
    const [state, message] = stateText();
    boards.forEach(root => {
      connection(root.querySelector('[data-lb-connection]'), state, message);
      const button = root.querySelector('[data-lb-refresh]');
      button.disabled = !!inFlight || !endpoint;
      button.textContent = inFlight ? 'Updating…' : '↻ Refresh';
      root.setAttribute('aria-busy', String(!!inFlight));
    });
    if (calendarRoot) connection(calendarRoot.querySelector('[data-cal-connection]'), state, message);
  }

  const views = boards.map(root => {
    const find = selector => root.querySelector(selector);
    const compact = root.dataset.leaderboard === 'compact';
    const period = find('[data-lb-period]');
    const params = new URLSearchParams(window.location.search);
    const requested = params.get('period') || config.defaultPeriod;
    if ([...period.options].some(option => option.value === requested)) period.value = requested;
    const controls = {
      period, metric: find('[data-lb-metric]'), campaign: find('[data-lb-campaign]'), state: find('[data-lb-state]'), basis: find('[data-lb-basis]'),
      from: find('[data-lb-from]'), to: find('[data-lb-to]'), search: find('[data-lb-search]')
    };
    const message = find('[data-lb-message]');
    const table = find('[data-lb-table-wrap]');
    const podium = find('[data-lb-podium]');

    function options(includeQuery) {
      return { period: period.value, metric: controls.metric ? controls.metric.value : 'set', campaign: controls.campaign ? controls.campaign.value : '',
        state: controls.state ? controls.state.value : '', basis: controls.basis ? controls.basis.value : 'submission',
        from: controls.from ? controls.from.value : '', to: controls.to ? controls.to.value : '', query: includeQuery && controls.search ? controls.search.value : '', today: liveToday() };
    }
    function showMessage(value, kind) { message.hidden = !value; message.dataset.kind = kind || ''; message.textContent = value; }
    function updateFilter(select, values, label) {
      if (!select) return;
      const saved = select.value;
      select.replaceChildren(new Option(label, ''));
      values.forEach(value => select.add(new Option(value, value)));
      if (values.includes(saved)) select.value = saved;
    }
    function fillFilters() {
      if (!data) return;
      updateFilter(controls.campaign, [...new Set(data.buckets.map(bucket => bucket.campaign))].sort(), 'All campaigns');
      updateFilter(controls.state, [...new Set(data.buckets.map(bucket => bucket.state))].sort(), 'All states');
      if (controls.from && !controls.from.value) controls.from.value = core.periodRange('week', liveToday()).from;
      if (controls.to && !controls.to.value) controls.to.value = liveToday();
    }
    function drawStats(result) {
      const metrics = compact ? ['set', 'completed', 'agents'] : ['set', 'confirmed', 'completed', 'closedWon'];
      const articles = metrics.map(metric => {
        const card = el('article');
        card.append(el('span', '', metric === 'agents' ? 'Agents on the board' : labels[metric]), el('strong', '', result ? number.format(metric === 'agents' ? result.agentCount : result.totals[metric]) : '—'));
        return card;
      });
      find('[data-lb-stats]').replaceChildren(...articles);
    }
    function render() {
      const custom = find('[data-lb-custom-dates]');
      if (custom) custom.hidden = period.value !== 'custom';
      if (!data) {
        table.hidden = true;
        if (podium) podium.hidden = true;
        drawStats(null);
        showMessage(lastError || (endpoint ? 'Loading agent standings…' : 'Standings will appear when the CRM connection is ready.'), lastError ? 'error' : '');
        return;
      }
      let result, leaders;
      try { result = core.standings(data, options(true)); leaders = core.standings(data, options(false)); }
      catch (error) { table.hidden = true; if (podium) podium.hidden = true; drawStats(null); showMessage(error.message, 'error'); return; }
      drawStats(result);
      const range = result.range;
      find('[data-lb-range]').textContent = range.from ? shortDate(range.from) + (range.from === range.to ? '' : ' – ' + shortDate(range.to)) : 'All recorded appointments';
      const basisLabel = controls.basis && controls.basis.value === 'appointment' ? 'Appointment date' : 'Submission date';
      find('[data-lb-method]').textContent = 'Ranked by ' + labels[result.metric].toLowerCase() + ' · ' + basisLabel + ' · ' + zoneLabel();
      const explanation = find('[data-lb-explanation]');
      if (explanation) explanation.textContent = 'Periods use ' + zoneLabel() + '. ' + (basisLabel === 'Submission date' ? 'Set counts use the form submission date. ' : 'Counts use the scheduled appointment date. ') + 'Outcomes reflect the latest CRM status. Equal scores share a rank.';
      const agentCount = find('[data-lb-agent-count]');
      if (agentCount) agentCount.textContent = number.format(result.agentCount);
      if (podium) {
        const top = leaders.rows.filter(agent => agent[result.metric] > 0).slice(0, 3);
        podium.hidden = !top.length;
        podium.replaceChildren(...top.map(agent => {
          const card = el('article', 'lb-podium-card'); card.dataset.rank = String(agent.rank);
          const score = el('span', 'lb-podium-score'); score.append(el('b', '', number.format(agent[result.metric])), document.createTextNode(labels[result.metric].toLowerCase()));
          card.append(el('span', 'lb-podium-rank', '#' + agent.rank), el('strong', '', agent.name), score); return card;
        }));
      }
      const displayRows = compact ? result.rows.slice(0, 5) : result.rows;
      table.hidden = !displayRows.length;
      showMessage(lastError ? 'The latest update could not be loaded. Showing results from ' + updatedTime() + '. ' + lastError : !displayRows.length ? (controls.search && controls.search.value ? 'No agents match that name.' : 'No appointments recorded for this period and these filters.') : '', lastError ? 'error' : '');
      const fragment = document.createDocumentFragment();
      displayRows.forEach(agent => {
        const row = el('tr'); row.dataset.rank = String(agent.rank);
        const rank = el('td'); rank.append(el('span', 'lb-rank', String(agent.rank)));
        const nameCell = el('td'); const name = el('div', 'lb-agent');
        const avatar = el('span', 'lb-avatar', initials(agent.name)); avatar.setAttribute('aria-hidden', 'true');
        name.append(avatar, el('span', '', agent.name)); nameCell.append(name); row.append(rank, nameCell);
        (compact ? core.metrics.slice(0, 4) : core.metrics).forEach(metric => { const cell = el('td', '', number.format(agent[metric])); if (metric === result.metric) cell.dataset.metric = 'active'; row.append(cell); });
        fragment.append(row);
      });
      find('[data-lb-rows]').replaceChildren(fragment);
      if (compact) {
        const link = root.querySelector('.lb-link-button');
        link.href = 'leaderboard/index.html?period=' + encodeURIComponent(period.value);
      }
    }
    Object.values(controls).filter(Boolean).forEach(control => control.addEventListener(control === controls.search ? 'input' : 'change', render));
    find('[data-lb-refresh]').addEventListener('click', () => load(true));
    return { render, fillFilters };
  });

  let calendarView = null;
  if (calendarRoot) {
    const find = selector => calendarRoot.querySelector(selector);
    let selected = liveToday(), month = selected.slice(0, 7);
    const shiftMonth = amount => {
      const date = new Date(month + '-01T12:00:00Z'); date.setUTCMonth(date.getUTCMonth() + amount);
      month = date.toISOString().slice(0, 7); render();
    };
    function render() {
      find('[data-cal-month]').textContent = new Intl.DateTimeFormat('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(month + '-01T12:00:00Z'));
      find('[data-cal-timezone]').textContent = zoneLabel();
      const message = find('[data-cal-message]');
      find('[data-cal-layout]').hidden = !data;
      message.hidden = !!data && !lastError;
      message.textContent = lastError ? (data ? 'Update delayed. Showing the last loaded schedule.' : lastError) : endpoint ? 'Loading team appointments…' : 'Team appointments will appear when the CRM connection is ready.';
      if (!data) return;
      const first = month + '-01', weekday = (new Date(first + 'T12:00:00Z').getUTCDay() + 6) % 7;
      const end = new Date(month + '-01T12:00:00Z'); end.setUTCMonth(end.getUTCMonth() + 1); end.setUTCDate(0);
      const dayCount = end.getUTCDate(), cells = Math.ceil((weekday + dayCount) / 7) * 7;
      const counts = new Map(); data.calendar.forEach(event => counts.set(event.date, (counts.get(event.date) || 0) + 1));
      const fragment = document.createDocumentFragment();
      for (let i = 0; i < cells; i++) {
        const date = core.shiftDate(first, i - weekday);
        const button = el('button', 'lb-cal-day'); button.type = 'button';
        button.dataset.outside = String(date.slice(0, 7) !== month);
        button.dataset.today = String(date === liveToday()); button.dataset.selected = String(date === selected);
        button.setAttribute('aria-pressed', String(date === selected));
        const count = counts.get(date) || 0;
        button.setAttribute('aria-label', shortDate(date) + ', ' + count + (count === 1 ? ' appointment' : ' appointments'));
        button.append(el('span', 'lb-cal-date', String(Number(date.slice(8)))));
        if (count) { button.append(el('span', 'lb-cal-count', number.format(count)), el('span', 'lb-cal-count-label', count === 1 ? 'appointment' : 'appointments')); }
        button.addEventListener('click', () => { selected = date; month = date.slice(0, 7); render(); });
        fragment.append(button);
      }
      find('[data-cal-days]').replaceChildren(fragment);
      find('[data-cal-day-heading]').textContent = new Intl.DateTimeFormat('en-US', { weekday: 'long', month: 'short', day: 'numeric', timeZone: 'UTC' }).format(new Date(selected + 'T12:00:00Z'));
      const events = data.calendar.filter(event => event.date === selected).sort((a, b) => (a.time || '99:99').localeCompare(b.time || '99:99'));
      find('[data-cal-day-count]').textContent = number.format(events.length) + (events.length === 1 ? ' appointment' : ' appointments');
      const names = new Map(data.agents.map(agent => [agent.id, agent.name]));
      find('[data-cal-events]').replaceChildren(...events.map(event => {
        const card = el('article', 'lb-cal-event');
        const time = event.time ? new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', hour: 'numeric', minute: '2-digit' }).format(new Date('2000-01-01T' + event.time + ':00Z')) : 'Time pending';
        const top = el('div', 'lb-cal-event-top'); top.append(el('strong', '', time), el('span', 'lb-cal-status', event.status));
        card.append(top, el('b', 'lb-cal-agent', names.get(event.agentId)), el('span', 'lb-cal-state', event.state)); return card;
      }));
      if (!events.length) find('[data-cal-events]').append(el('p', 'lb-cal-empty', 'No appointments on this day.'));
    }
    find('[data-cal-prev]').addEventListener('click', () => shiftMonth(-1));
    find('[data-cal-next]').addEventListener('click', () => shiftMonth(1));
    find('[data-cal-today]').addEventListener('click', () => { selected = liveToday(); month = selected.slice(0, 7); render(); });
    calendarView = { render };
  }

  function renderAll() { views.forEach(view => view.render()); if (calendarView) calendarView.render(); updateConnections(); }
  function accept(input) { data = core.validateDataset(input); views.forEach(view => view.fillFilters()); renderAll(); window.dispatchEvent(new CustomEvent('dc:crm', { detail: { data } })); }
  function request() {
    return new Promise((resolve, reject) => {
      const callback = 'dcLb' + Date.now() + '_' + (++sequence);
      const url = new URL(endpoint); url.searchParams.set('action', 'leaderboard'); url.searchParams.set('callback', callback);
      const script = document.createElement('script'); script.src = url.href; script.async = true; script.referrerPolicy = 'no-referrer';
      const cleanup = () => { clearTimeout(timeout); script.remove(); delete window[callback]; };
      const timeout = setTimeout(() => { cleanup(); reject(new Error('The CRM took too long to respond. Try Refresh.')); }, 15000);
      window[callback] = response => { cleanup(); resolve(response); };
      script.onerror = () => { cleanup(); reject(new Error('The CRM connection is unavailable. Check the web app deployment.')); };
      script.onload = () => { if (window[callback]) { cleanup(); reject(new Error('The web app needs the Leaderboard.gs and doGet deployment update.')); } };
      document.head.append(script);
    });
  }
  async function load(force) {
    if (inFlight || !endpoint) { renderAll(); return; }
    if (!/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(endpoint)) {
      lastError = 'The CRM connection needs its Apps Script web app /exec URL.'; renderAll(); return;
    }
    if (!force && data && Date.now() - Date.parse(data.generatedAt) < refreshMs) return;
    lastError = '';
    inFlight = request(); updateConnections();
    try {
      const response = await inFlight;
      accept(response);
      try { sessionStorage.setItem(cacheKey, JSON.stringify(data)); } catch (ignored) { /* Storage can be disabled. */ }
    } catch (error) { lastError = error.message; }
    finally { inFlight = null; renderAll(); }
  }
  try {
    const cached = endpoint && sessionStorage.getItem(cacheKey);
    if (cached) {
      const parsed = JSON.parse(cached);
      if (Date.now() - Date.parse(parsed.generatedAt) < 5 * refreshMs) accept(parsed);
    }
  } catch (ignored) { /* A fresh request replaces invalid cached data. */ }
  renderAll(); load(false);
  setInterval(() => { if (!document.hidden) load(false); }, refreshMs);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) load(false); });
})();
