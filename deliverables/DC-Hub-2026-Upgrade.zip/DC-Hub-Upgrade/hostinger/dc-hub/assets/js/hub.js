/* Digital Citizen | modular front-end. Source content lives in assets/data/*.json. */
(() => {
  'use strict';
  const root = document.body.dataset.root || (location.pathname.includes('/leaderboard/') ? '../' : '');
  const page = document.body.dataset.page || '';
  const $ = (selector, base=document) => base.querySelector(selector);
  const $$ = (selector, base=document) => [...base.querySelectorAll(selector)];
  const mk = (tag, className='', value) => { const node=document.createElement(tag); if(className) node.className=className; if(value!==undefined) node.textContent=value; return node; };
  const number = n => new Intl.NumberFormat('en-US').format(n);
  const safeURL = value => typeof value === 'string' && /^https:\/\/[\w.-]+\//.test(value) ? value : '';
  const allowedScript = name => /^[a-z0-9-]+\.html$/.test(String(name || ''));
  let campaigns=[], resources=[], crm=null;

  function showClock(){
    try {
      const date = new Date();
      const formatted = new Intl.DateTimeFormat('en-US',{timeZone:'America/Mexico_City',hour:'numeric',minute:'2-digit',hour12:true}).format(date);
      $$('[data-mexico-clock]').forEach(el=>el.textContent=formatted);
    } catch (error) { console.warn('Mexico City clock:',error); }
  }
  showClock(); setInterval(showClock,30000);
  const menu = $('.menu-toggle');
  if(menu) menu.addEventListener('click',()=>{const open=document.body.classList.toggle('sidebar-open');menu.setAttribute('aria-expanded',String(open));});
  $$('.sidebar .side-link').forEach(a=>a.addEventListener('click',()=>document.body.classList.remove('sidebar-open')));

  // Only manager identities receive the editing link. Server enforces the actual permission.
  if($$('[data-admin-link]').length) fetch(root+'auth/whoami.php',{credentials:'same-origin',cache:'no-store'})
    .then(r=>r.ok?r.json():null).then(d=>{if(d?.isManager) $$('[data-admin-link]').forEach(a=>a.hidden=false);}).catch(()=>{});

  let modalRequest=0,modalReturnFocus=null;
  const modal=$('#content-modal'), modalTitle=$('#content-modal-title'), modalBody=$('#content-modal-body');
  function openModal(title){if(!modal)return;modalReturnFocus=document.activeElement;modalRequest++;modalTitle.textContent=title;modal.classList.add('open');document.body.classList.add('modal-visible');$('.close',modal)?.focus();}
  function closeModal(){modalRequest++;modalReturnFocus?.focus();modal?.classList.remove('open');document.body.classList.remove('modal-visible');}
  $('.close',modal || document)?.addEventListener('click',closeModal);
  modal?.addEventListener('click',e=>{if(e.target===modal)closeModal();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();if(e.key==='Tab'&&modal?.classList.contains('open')){const nodes=[...modal.querySelectorAll('button,a[href],input,select,textarea,[tabindex="0"]')];const first=nodes[0],last=nodes.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}});
  function infoModal(title,contents){openModal(title);modalBody.replaceChildren(mk('p','editorial-note',contents));}
  async function scriptModal(name,title){
    if(!allowedScript(name))return infoModal('Invalid resource','The requested script is unavailable.');
    openModal(title);const request=modalRequest;modalBody.replaceChildren(mk('p','state-note','Loading script…'));
    try {const r=await fetch(root+'assets/scripts/'+name,{cache:'no-store',credentials:'same-origin'});if(!r.ok)throw new Error('HTTP '+r.status);
      const source=await r.text();if(request!==modalRequest)return;const body=DCContent.parse(source);modalBody.replaceChildren(...body.childNodes);

    }catch(err){if(request!==modalRequest)return;modalBody.replaceChildren(mk('p','state-note','Could not load this script. Check its asset filename and the login session.'));}
  }
  document.addEventListener('click',e=>{const a=e.target.closest('a[href]');if(!a||!/^https:\/\/docs\.google\.com\/forms\//.test(a.href))return;const popup=window.open(a.href,'DC_Qualification','popup=yes,width=800,height=800,resizable=yes,scrollbars=yes');if(popup){e.preventDefault();popup.focus();}});
  const normalize = value => String(value || '').toLowerCase().replace(/[^a-z0-9]/g,'');
  const weekdayISO = (date,offset) => { const d=new Date(date+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+offset);return d.toISOString().slice(0,10); };
  function crmRange(data){
    const today = window.DCLeaderboardCore?.todayInZone('America/Mexico_City') || data.today;
    if(!/^\d{4}-\d{2}-\d{2}$/.test(today))return null;
    const dow=(new Date(today+'T12:00:00Z').getUTCDay()+6)%7;
    return [weekdayISO(today,-dow),weekdayISO(today,6-dow)];
  }
  function campaignMetrics(c){
    if(!crm?.buckets)return null;
    const aliases = new Set([c.name,...(c.crmCampaigns || [])].map(normalize).filter(Boolean));
    const relevant = crm.buckets.filter(b=>aliases.has(normalize(b.campaign)));
    if(!relevant.length)return {mapped:false};
    const range=crmRange(crm);
    const current=relevant.filter(b=>range && b.submissionDate>=range[0] && b.submissionDate<=range[1]);
    return {mapped:true,set:current.reduce((a,b)=>a+b.set,0),confirmed:current.reduce((a,b)=>a+b.confirmed,0),completed:current.reduce((a,b)=>a+b.completed,0)};
  }
  function statText(num,den){return den ? Math.round((num/den)*100)+'%' : '—';}
  function cta(className,label,url){const a=mk('a',className,label);const link=safeURL(url);if(link){a.href=link;a.target='_blank';a.rel='noopener';}else{a.href='#';a.setAttribute('aria-disabled','true');a.addEventListener('click',e=>e.preventDefault());}return a;}
  function makeCampaign(c){
    const card=mk('article','campaign-card');card.dataset.campaignId=c.id;
    const art=mk('div','campaign-art');
    const artPath= /^assets\/visuals\/[a-z0-9-]+\.svg$/.test(c.visual || '') ? root+c.visual : '';
    if(artPath)art.style.backgroundImage=`linear-gradient(0deg,rgba(2,9,17,.70),rgba(2,9,17,.05)),url("${artPath}")`;
    const tag=mk('span','campaign-type',c.category);if(/roof/i.test(c.category))tag.classList.add('roof');
    art.append(tag);
    const body=mk('div','campaign-body');body.append(mk('h3','',c.name),mk('p','campaign-subtitle',c.description));
    const stats=mk('div','campaign-stats');
    const metrics=campaignMetrics(c);
    const cols=[['SET',metrics?.mapped?number(metrics.set):'—'],['CONFIRMED',metrics?.mapped?statText(metrics.confirmed,metrics.set):'—'],['COMPLETED',metrics?.mapped?statText(metrics.completed,metrics.set):'—']];
    cols.forEach(([label,value])=>{const col=mk('div');col.append(mk('strong','',value),mk('span','',label));stats.append(col);});
    const foot=mk('p','campaign-note',!crm?'Waiting for CRM data':metrics?.mapped?'Current reporting week':'CRM campaign label not matched');
    const actions=mk('div','campaign-buttons');
    const script=mk('button','','▤  Script');script.type='button';script.addEventListener('click',()=>scriptModal(c.script,c.name+' · Script'));
    const notes=mk('button','','◈  Market notes');notes.type='button';notes.addEventListener('click',()=>infoModal(c.name+' · Market notes',c.notes || 'No notes yet.'));
    actions.append(script,notes,cta('btn-dark','✓ Submit',c.submitUrl),cta('btn-dark','☎ Dialer',c.dialerUrl));
    body.append(stats,foot,actions);card.append(art,body);return card;
  }
  function renderCampaigns(){
    const search=($('[data-search-campaigns]')?.value || '').trim().toLowerCase(); const category=$('[data-filter-category]')?.value || '';
    const available=campaigns.filter(c=>c.visible!==false).filter(c=>(!category || c.category===category) && (!search || [c.name,c.description,c.region,c.category].join(' ').toLowerCase().includes(search)));
    $$('[data-campaign-list]').forEach(list=>{const limit=Number(list.dataset.limit) || Infinity;list.replaceChildren(...available.slice(0,limit).map(makeCampaign));if(!available.length)list.append(mk('p','state-note','No campaigns match the filter.'));});
    const count=$('[data-campaign-count]');if(count)count.textContent=available.length+' campaigns';
  }
  function renderResources(){
    const search=($('[data-search-resources]')?.value || '').trim().toLowerCase(),type=$('[data-filter-resource]')?.value || '';
    const available=resources.filter(r=>r.visible!==false).filter(r=>(!type || type===r.category) && (!search || [r.title,r.description,r.category].join(' ').toLowerCase().includes(search)));
    $$('[data-resource-list]').forEach(list=>{list.replaceChildren();available.slice(0,Number(list.dataset.limit)||Infinity).forEach(r=>{
      const card=mk('article','resource-card');const icon=mk('span','resource-icon',r.category==='Training'?'◈':'▤');const header=mk('div');header.append(icon,mk('span','resource-category',r.category));
      const button=mk('button','resource-open',r.url?'Open resource ↗':'Open document ↗');button.type='button';button.addEventListener('click',()=>{if(r.url){if(/^https:\/\//.test(r.url))window.open(r.url,'_blank','noopener');else location.href=root+r.url;}else scriptModal(r.script,r.title);});
      card.append(header,mk('h3','',r.title),mk('p','',r.description),button);list.append(card);
    });if(!available.length)list.append(mk('p','state-note','No resources match that filter.'));});
    if($('[data-resource-count]'))$('[data-resource-count]').textContent=available.length+' resources';
  }
  function renderSchedule(data){const node=$('[data-schedule]');if(!node)return;
    node.replaceChildren(mk('p','schedule-timezone',data.timezoneLabel || 'Eastern Time'));
    (data.items || []).forEach(item=>{const slot=mk('div','schedule-item');const time=mk('strong','schedule-time',item.time || '');const detail=mk('div','schedule-detail');detail.append(mk('b','',item.title),mk('small','',item.detail));
      const action=item.action || {};const label=action.label || '';const a=safeURL(action.url)?cta('schedule-button',label,action.url):mk('span','schedule-static',label);slot.append(time,detail,a);node.append(slot);
    });if(!data.items?.length)node.append(mk('p','state-note','Schedule is empty.'));
  }
  function renderTeam(people){const node=$('[data-team]');if(!node)return;node.replaceChildren();people.filter(p=>p.visible!==false).forEach(person=>{const member=mk('article','member-card');const avatar=mk('span','member-avatar',person.name.split(' ').slice(0,2).map(n=>n[0]||'').join('').toUpperCase());const meta=mk('div','member-meta');meta.append(mk('b','',person.name),mk('small','',person.role));const actions=mk('div','member-buttons');if(safeURL(person.roamUrl))actions.append(cta('member-roam','ROAM ↗',person.roamUrl));if(safeURL(person.whatsappUrl))actions.append(cta('member-whatsapp','WHATSAPP ↗',person.whatsappUrl));member.append(avatar,meta,actions);node.append(member);});}
  function renderRollCall(data){const node=$('[data-roll-call]');if(!node)return;node.replaceChildren();(data.rollCalls || []).forEach(item=>{const card=cta('roll-card','',item.url);const content=mk('div');content.append(mk('b','',item.title),mk('small','',item.description));card.append(content,mk('span','roll-open','OPEN ↗'));node.append(card);});}
  async function fromJSON(name,apply){
    try{const response=await fetch(root+'assets/data/'+name+'.json',{cache:'no-store',credentials:'same-origin'});if(!response.ok)throw new Error('HTTP '+response.status);apply(await response.json());}
    catch(error){console.warn('Module '+name+' unavailable:',error);const container=$('[data-'+(name==='campaigns'?'campaign-list':name==='resources'?'resource-list':name==='team'?'team':name==='schedule'?'schedule':'roll-call')+']');if(container)container.replaceChildren(mk('p','state-note','Could not load '+name+'. Check the asset file and your session.'));}
  }
  if($('[data-campaign-list]'))fromJSON('campaigns',data=>{campaigns=Array.isArray(data)?data:[];renderCampaigns();});
  if($('[data-resource-list]'))fromJSON('resources',data=>{resources=Array.isArray(data)?data:[];renderResources();});
  if($('[data-schedule]'))fromJSON('schedule',renderSchedule);
  if($('[data-team]'))fromJSON('team',renderTeam);
  if($('[data-roll-call]') || $('[data-site-tagline]'))fromJSON('site',data=>{
    if($('[data-site-headline]')){const h=$('[data-site-headline]'),parts=String(data.headline||'Operations Hub').split(/\s+/), last=parts.pop()||'Hub';h.replaceChildren(document.createTextNode(parts.join(' ').toUpperCase()),document.createElement('br'));const em=document.createElement('em');em.textContent=last.toUpperCase()+'.';h.append(em);}
    if($('[data-site-tagline]'))$('[data-site-tagline]').textContent=data.tagline || 'Real People. Digital Opportunities.';
    if($('[data-site-subline]'))$('[data-site-subline]').textContent=data.subline || '';
    renderRollCall(data);
  });
  $('[data-search-campaigns]')?.addEventListener('input',renderCampaigns);
  $('[data-filter-category]')?.addEventListener('change',renderCampaigns);
  $('[data-search-resources]')?.addEventListener('input',renderResources);
  $('[data-filter-resource]')?.addEventListener('change',renderResources);

  if($('.lb-page') || $('.leaderboard-home'))fromJSON('leaderboard',data=>{
    if($('#leaderboard-title'))$('#leaderboard-title').textContent=data.title;
    if($('.lb-intro .lb-description'))$('.lb-intro .lb-description').textContent=data.description;
    if($('.lb-bottom-note'))$('.lb-bottom-note').textContent=data.footnote;
    if($('.leaderboard-home .panel-heading h2'))$('.leaderboard-home .panel-heading h2').textContent=data.title;
  });

  // Statistics are never hardcoded: the same validated CRM payload powers the leaderboard and calendar.
  function updateKPIs(data){
    if(!window.DCLeaderboardCore)return;
    const zoneToday=window.DCLeaderboardCore.todayInZone('America/Mexico_City');
    const stats=window.DCLeaderboardCore.standings(data,{period:'week',metric:'set',basis:'submission',today:zoneToday});
    ['set','confirmed','completed'].forEach(key=>$$('[data-kpi="'+key+'"]').forEach(el=>el.textContent=number(stats.totals[key])));
    $$('[data-kpi="agents"]').forEach(el=>el.textContent=number(stats.agentCount));
    if($('[data-confirm-rate]'))$('[data-confirm-rate]').textContent='Confirmation rate '+statText(stats.totals.confirmed,stats.totals.set);
    if($('[data-complete-rate]'))$('[data-complete-rate]').textContent='Completion rate '+statText(stats.totals.completed,stats.totals.set);
  }
  window.addEventListener('dc:crm',event=>{crm=event.detail.data;renderCampaigns();updateKPIs(crm);});
})();
