# Local Earth asset

`hostinger/dc-hub/assets/images/earth-day.jpg` is bundled from the pinned Three.js r180 example asset:
https://raw.githubusercontent.com/mrdoob/three.js/r180/examples/textures/planets/earth_atmos_2048.jpg

Upstream project license is retained in `licenses/threejs.txt`. The download used HTTPS verification. This delivery makes no independent NASA/public-domain provenance claim. SHA-256: `2faa400d1eade3bc44caf6750d1b772bd9bbb6d87362c02bc7c3304e78fa0a9d`.

The globe uses the local texture and small native WebGL shaders; no Three.js library or CDN is loaded at runtime. If texture loading or WebGL fails, the CSS globe and login content remain. Network trails are decoration, not real geolocation or utility coverage.
