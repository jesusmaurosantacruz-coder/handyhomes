"""Read-only XLSX structural audit. Does not export customer or credential values."""
import sys,zipfile,hashlib,json,xml.etree.ElementTree as E
from pathlib import Path
source=Path(sys.argv[1]);out=Path(sys.argv[2])
ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(source) as z:
 strings=[''.join(i.itertext()) for i in E.fromstring(z.read('xl/sharedStrings.xml'))] if 'xl/sharedStrings.xml' in z.namelist() else []
 rel={r.attrib['Id']:r.attrib['Target'] for r in E.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
 tabs=[]
 for s in E.fromstring(z.read('xl/workbook.xml')).findall('m:sheets/m:sheet',ns):
  target=rel[s.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']];name=target.lstrip('/') if target.startswith('/') else 'xl/'+target
  t=E.fromstring(z.read(name));rows=t.findall('m:sheetData/m:row',ns);headers=[]
  if rows:
   for c in rows[0].findall('m:c',ns):
    v=c.find('m:v',ns);value=v.text if v is not None else ''
    if c.attrib.get('t')=='s':value=strings[int(value)]
    if c.attrib.get('t')=='inlineStr':value=''.join(c.find('m:is',ns).itertext())
    headers.append(value)
  tabs.append({'name':s.attrib['name'],'rowElementsIncludingFormattedRows':len(rows),'headers':headers,'formulas':len(t.findall('.//m:f',ns)),'validations':len(t.findall('.//m:dataValidation',ns)),'cachedCellErrors':len([c for c in t.findall('.//m:c',ns) if c.attrib.get('t')=='e'])})
report={'source':source.name,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'tabs':tabs,'scope':'Uploaded Excel export only; no live Google Sheets access, sharing, scripts, triggers or Forms inspected','notes':['Excel truncates Google worksheet titles longer than 31 characters. Use full Google names in intake source mapping.','Row element counts can include blank/formatted rows and are not appointment/user counts.','Preserve existing tabs and calendar/event-reference columns. Team assignments are not inferred.']}
out.write_text(json.dumps(report,indent=2));print('Structural audit saved:',len(tabs),'tabs; no cell records exported')
