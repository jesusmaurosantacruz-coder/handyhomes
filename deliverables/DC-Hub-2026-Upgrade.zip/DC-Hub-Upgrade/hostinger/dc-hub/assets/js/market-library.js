/* Local, versioned market reference. No Workspace API or remote HTML. */
const pending=new Map();
async function json(url){if(!pending.has(url))pending.set(url,fetch(url,{credentials:'same-origin',cache:'no-cache'}).then(r=>{if(!r.ok)throw Error('Market reference unavailable. Please retry.');return r.json();}).catch(e=>{pending.delete(url);throw e;}));return pending.get(url);}
export async function markets(root=''){return (await json(root+'assets/data/markets/manifest.json')).markets;}
export async function market(entry,root=''){if(!/^[a-z0-9-]+\.json$/.test(entry.file))throw Error('Invalid market path');return json(root+'assets/data/markets/'+entry.file+'?v='+encodeURIComponent(entry.version));}
const node=(tag,text)=>{const e=document.createElement(tag);if(text)e.textContent=text;return e;};
function group(parent,title,items){if(!items?.length)return;const details=node('details'),summary=node('summary',title);details.append(summary);const list=node('ul');items.forEach(text=>list.append(node('li',text)));details.append(list);parent.append(details);}
export function renderMarket(data,root=''){
 const article=node('article');article.className='market-reference';article.append(node('h2',data.name),node('p',data.overview.focus),node('p',data.overview.targetAreas));
 group(article,'Power companies & territory',data.powerCompanies.map(x=>x.name+' — '+x.territory));
 if(data.salesHooks.length){const block=node('section');block.append(node('h3','Ready to say'));data.salesHooks.forEach(text=>{const p=node('p',text),copy=node('button','Copy');copy.type='button';copy.onclick=async()=>{try{await navigator.clipboard.writeText(text);copy.textContent='Copied';}catch{copy.textContent='Select text to copy';}};p.append(copy);block.append(p);});article.append(block);}
 data.localIntelligence.forEach(s=>group(article,s.title,s.items));
 group(article,'Products',data.products);group(article,'Financing references',data.financing.map(x=>x.name+' — '+x.note));group(article,'Equipment references',data.equipment.map(x=>x.name+' — '+x.note));
 const map=node('section');map.className='coverage-placeholder';map.append(node('h3','Utility coverage'),node('p',data.coverageGraphic.status));
 if(/^assets\/[\w/-]+\.(?:webp|png)$/i.test(data.coverageGraphic.path||'')){const image=node('img');image.loading='lazy';image.alt=data.coverageGraphic.alt;image.src=root+data.coverageGraphic.path;image.onerror=()=>{image.remove();map.append(node('p','Coverage image unavailable. Verify territory using the utility bill.'));};const a=node('a');a.href=image.src;a.target='_blank';a.rel='noopener';a.append(image);map.append(a);}article.append(map);
 const meta=node('footer');meta.append(node('p','Reviewed '+data.source.lastReviewed+' · '+data.source.verification));data.source.urls.forEach(url=>{if(!/^https:\/\//.test(url))return;const a=node('a','Source ↗');a.href=url;a.target='_blank';a.rel='noopener noreferrer';meta.append(a);});if(data.source.localPath){const a=node('a','Original supplied notes ↗');a.href=root+data.source.localPath;a.target='_blank';a.rel='noopener';meta.append(a);}article.append(meta);return article;
}
