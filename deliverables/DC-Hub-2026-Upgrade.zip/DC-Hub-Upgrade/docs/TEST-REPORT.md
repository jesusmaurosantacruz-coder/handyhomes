> Supplied baseline documentation, retained for historical reference. For the revised read-only 2026 release, deployment steps, role/cache behavior and current validation, use [UPGRADE-2026.md](UPGRADE-2026.md).

# Validation report

The upgraded implementation was tested locally against the supplied source and Excel workbook structure. **No live Google Workspace, Hostinger or Roam deployment was executed.** Local test doubles are explicitly labeled; they are not evidence of production connectivity.

## Completed local checks

| Suite | Result | Scope |
| --- | --- | --- |
| Apps Script backend | 48 passed | Actual unified functions with in-memory Google service doubles |
| Browser/Apache | 40 passed | Actual UI with Workspace responses intercepted; real anonymous PHP/Apache gates checked separately |
| Typing engine | 9 passed | 60/90/120-second calculations, corrections, insertion errors, elapsed bounds |
| PHP content safety | 7 passed | Script text preservation, safe Docs styles/tables/images, executable content removal |
| PHP transport/session | 5 passed | Real signing/session/CSRF functions with test-only HTTP transport double |
| JavaScript / Apps Script syntax | 25 passed | Correct module parsing for the three browser modules |
| PHP syntax | 15 passed | Complete Hostinger folder including the private configuration example |
| Static release checks | Passed | Local references, JSON, synchronized server/browser typing passages, no runtime credential config files |
| Local startup | Passed | Packaged startup script started the pinned PHP/Apache image and returned the login page |

That is **109 functional/security/calculation checks**, plus syntax and static validation. Result files are under `tests/`; screenshots are under `tests/evidence/` and contain synthetic fixtures only.

Backend checks cover all three campaign intake paths, exactly one normalized record/event across retries, original response preservation, source normalization, inactive-user denial, subject binding, four-field calendar redaction, own/team/admin access, stale revisions/fingerprints, partial calendar failures, linked event copies, all-day events, at-most-once automatic Roam sending, exact setter-dropdown updates, team-history preservation, formula-injection handling, signed request tampering/replay, attempt identity/timing/deduplication, migration backup and repeated execution, production-migration guardrails and batched Sheets read/write paths. Spreadsheet date/time cells retain their displayed wall-clock values before conversion to the appointment timezone; approved city-specific timezone mappings override state-level mappings without calendar routing.

Browser checks cover dashboard API values, announcements, appointment confirmation, bounded queues, protected calendar requests, state/campaign analysis, agent/team standings, market Docs/edit links, sheet-driven resources, team administration, the retained campaign station, station Docs selectors, session-derived typing identity, exactly three tests and durations, stopping/submitting at each deadline, mobile layout/navigation and JavaScript errors.

The spreadsheet audit inspected 14 exported worksheets, headers, validation counts and formula presence without exporting customer rows. Three formulas were found in the exported Typing Leaderboard tab, with no cached error cells. This does not verify their live Google Sheets execution. Worksheet row-element counts include formatted blanks and are not counts of appointments or active users.

## Failures found and resolved locally

- Typing initially loaded a module as a classic script; corrected the HTML module declaration and reran the typing/browser checks.
- Mobile navigation covered its own close toggle; corrected stacking/layout and verified opening/closing at 390px.
- All-day support required an explicit preserved metadata field in the schema; added it and verified existing all-day duration preservation.
- A browser detail assertion ran before its response completed; corrected the harness wait rather than changing application behavior.
- The static checker initially parsed browser modules as classic stdin scripts; corrected the checker to derive parsing mode from actual HTML declarations.
- The PHP transport harness initially evaluated a strict declaration after a closing tag; corrected the harness. No production authentication bypass was introduced.

No unexplained failing local checks remain in the executed scope.

## Live acceptance still required

| Workflow | Status |
| --- | --- |
| Real OAuth consent, code exchange, ID-token validation, Hostinger session cookies | Unverified; requires your OAuth client and staging domain |
| Live workbook backup, migration and validation | Unrun; execute on a copy first |
| Real Forms → CRM → intended Calendar → Roam → Hub → authorized update | Unverified; sandbox helper and checklist supplied |
| Calendar permissions, manual destinations, existing IDs/copy formats, DST behavior in your actual markets | Requires sandbox/live inspection |
| Existing calendar sharing and customer privacy outside Hub | Unverified; remove inappropriate sharing before go-live |
| Actual setter dropdown item IDs, form access and trigger ownership across accounts | Requires deployment review |
| Real roster/team assignments and historical team attribution | Pending your assignments; Team 1–3 are placeholders only |
| Live typing saves and the existing sheet-based Typing Leaderboard formulas | Unverified; website standings and result logic tested with doubles |
| Actual Google Docs export/image access and resource changes | Unverified; local rendering and sanitizer tested |
| Real training recordings, codecs, hosting write/upload limits | Requires your approved media and Hostinger validation |
| Production deployment, rollback and new cloud-task restoration | Not performed |

The package is prepared for **staging upload and configuration**, not a claim that a live production upgrade is already operational. See `DEPLOYMENT.md` for exact actions and acceptance steps. Production remains unchanged.

## Reproduce locally

Use the existing checkout; cloud tasks are already isolated. Do not create a worktree unless requested. From the `platform` folder:

```sh
node tests/backend.cjs
node tests/typing-engine.cjs
python3 tools/verify.py
bash tools/start-local.sh
python3 tests/browser.py
```

Browser tests require Python Playwright, `/usr/bin/chromium`, Docker and Node. The current cloud environment provides them. The startup script binds only loopback port 8081; do not create a user-facing localhost preview link. Browser tests intercept authenticated Workspace calls; they cannot replace live OAuth/Workspace acceptance.

PHP tests can be run with the pinned image used by the startup script, mounting this folder at `/platform` and invoking `php /platform/tests/php-security.php` and `php /platform/tests/php-transport.php`. Preserve TLS/CA trust and the platform's Docker proxy configuration for any network work. The transport double exists only in the test harness, never in the deployed application.

`tools/package.py` builds the release ZIP, includes SHA-256 file hashes and verifies every archived file byte-for-byte. Do not package real private configuration, uploaded spreadsheets or production credential files.
