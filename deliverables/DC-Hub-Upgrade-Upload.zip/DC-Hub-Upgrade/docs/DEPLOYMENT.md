# Staging, Google Workspace and production deployment

## 1. Preserve the current system

Download a full backup of the existing Hostinger site, its real configuration, manager-edited JSON/scripts, uploaded media and hosting settings. Keep it outside the public web root. Export the current Apps Script project source and record existing deployments, Script Properties and trigger handlers. Do not paste secrets into chat, Git, browser JavaScript or this package.

Do not replace the live site yet. This upgrade replaces password login with Google identity and needs the following connections before it is usable.

## 2. Prepare a sandbox workbook and project

Create a **new Apps Script project for staging**. Copy all `.gs` files from `apps-script/`, enable the manifest editor and replace `appsscript.json` with the supplied file. Do not combine these files with the old `Code.gs`, API, typing or leaderboard handlers: duplicate `doPost` functions and trigger handlers will conflict.

In Project Settings → Script Properties, set:

| Property | Value / purpose |
| --- | --- |
| `HUB_SOURCE_SPREADSHEET_ID` | `1EB8gX-hT9ohp64YC3qtFjvVaQZuFM7fRHMWEQQTrcb8` — original workbook; copy source only |
| `HUB_SHARED_SECRET` | A newly generated random secret, at least 32 characters; must match PHP's `shared_secret` |
| `HUB_REPORTING_ZONE` | `America/Mexico_City`, or your approved reporting timezone |

Generate a key locally using `php -r 'echo bin2hex(random_bytes(32)), PHP_EOL;'`; store it securely rather than in the project source. `HUB_SPREADSHEET_ID` is set automatically when the sandbox is created.

Run `hubPrepareSandbox()` and authorize the requested Google scopes. It copies the workbook and targets the copy; repeat runs reuse that sandbox. Run `hubMigrate()`, then `hubValidateMigration()`. The migration also creates a pre-migration backup and a JSON report in Drive. Inspect the returned report IDs. The original response sheets are untouched.

The manifest enables the Calendar and Sheets advanced services. Confirm both appear under Services and enable their APIs in the linked Cloud project if Google requests it.

In the **sandbox** USERS tab, ensure your own Google email is present, Active is true and Role is exactly `Admin`. Set Team 1–3 assignments only where known. Blank assignments are safe and grant no team access. An old GOOGLE_SUB binding must match the actual Google account; investigate any mismatch instead of disabling identity checks. Leave historical Original Team blank where it is unknown. Do not rename existing tabs or rearrange columns.

## 3. Configure and validate sandbox integrations

Use a dedicated test Google Calendar, not a production calendar. Add these properties:

| Property | Purpose |
| --- | --- |
| `HUB_SANDBOX_CALENDAR_ID` | Explicit test calendar ID for controlled acceptance |
| `SETTER_CALENDAR_ID` | Set to that same sandbox calendar during testing |
| `INTAKE_TIME_ZONE` | Optional approved fallback IANA zone for submissions that have no zone; leave unset if appointments can span zones and require review |
| `HUB_CREATE_SETTER_COPY` | Optional `YES`; only new intake with an explicitly selected different primary calendar gets a separate setter copy |
| `HUB_ADD_SETTER_GUESTS` | Optional `YES`; guests are added only to new setter-side events |
| `ROAM_TOKEN` | Real token in Script Properties only, if testing notifications |
| `ROAM_CHANNEL_ID` | Dedicated test channel, if notifications are enabled |
| `HUB_SANDBOX_ROAM_CHANNEL_ID` | Same dedicated test channel; required by sandbox acceptance when a token is present |

`hubRunSandboxAcceptance()` is clearly a **write test**: it creates three controlled test records/events in the verified sandbox, exercises idempotent intake twice and checks source preservation. It refuses a conflicting setter calendar or non-sandbox Roam channel. It does not touch existing production appointments. Test records remain in `HUB_TEST_*` tabs for review. If Roam is not configured, the report labels it unverified.

When source Forms do not include a timezone, configure approved market zones in `CRM_SETTINGS` using keys such as `timezone:SOLAR:CA` → `America/Los_Angeles`, or `timezone:SOLAR:TX:DALLAS` → `America/Chicago`. Exact city entries take precedence over statewide entries. Do not use one zone for states/markets spanning multiple zones unless that source is explicitly restricted to that zone. Missing mappings stay visible for review.

Calendar destinations are explicit. State and campaign never route to a closer calendar. Existing closer-side references remain in CRM. Use the already selected `Calendar ID` and event identifiers; related copies use a JSON array of `{ "calendarId": "...", "eventId": "..." }` in Related Calendar Events. Review other legacy formats before conversion. Missing links generate a visible error rather than a replacement event.

Review sharing/ACLs on production calendars separately before go-live. Remove public/domain/group sharing that exposes customer details to unauthorized people. The Hub's shared calendar is an authorized API view, not a public embed.

### Exact setter dropdown mappings

Set `HUB_FORMS` to JSON with one entry per campaign:

```json
[
  {"campaign":"SOLAR","formId":"SOLAR_FORM_ID","setterItemId":123,"affiliateOption":"Affiliate"},
  {"campaign":"ROOFING","formId":"ROOFING_FORM_ID","setterItemId":456,"affiliateOption":"Affiliate"},
  {"campaign":"FIBER","formId":"FIBER_FORM_ID","setterItemId":789,"affiliateOption":"Affiliate"}
]
```

Use test form copies for staging. `hubInspectForms()` lists the actual question titles and IDs without changing them. Set the exact setter dropdown item IDs, not question positions or guessed titles. `hubSyncForms()` edits only those dropdowns. Use `affiliateOption` only when that is the approved external-submission path. Names of inactive internal users remain in historical responses but are removed from future choices.

The long original Roofing/Fiber response tab names were truncated by Excel's export constraints. The code matches their full Google Sheets names with whitespace normalized. If live names differ, update `HUB.sources` once after inspection; do not rename live response sheets merely to match the Excel export.

## 4. Deploy the signed Apps Script endpoint

Deploy → New deployment → Web app. Execute as the workbook owner. For server-to-server access, choose access that permits the Hostinger server to call it without an interactive Google login (normally **Anyone**). This does not expose CRM data: `doGet` returns service metadata only and every POST requires a valid, fresh, signed request plus an active workbook identity. If your Workspace policy forbids this deployment mode, stop and have your administrator approve a supported server access route; do not remove signature verification.

Copy the `/exec` deployment URL. On code changes, update the deployment to a new version. Saving the editor alone does not update the deployed endpoint.

## 5. Configure Google Sign-In

In the Google Cloud project, configure the OAuth consent screen and create an OAuth Client ID of type **Web application**. Use only `openid`, `email` and `profile` scopes for website login; Apps Script owner authorization separately grants Workspace service access.

Register the exact staging redirect URI:

`https://YOUR-DOMAIN/dc-hub-staging/auth/google.php`

Also register the intended production URI, normally:

`https://YOUR-DOMAIN/dc-hub/auth/google.php`

Add test users if the consent screen is in Testing, and confirm Workspace policy allows the intended internal accounts. The authorized Google email must match an active USERS row with one of the four supported roles. Google login alone does not grant Hub access.

## 6. Upload the website to Hostinger staging

Requirements: PHP 8.2+ with cURL, DOM/libxml, JSON, session, OpenSSL and fileinfo; Apache/LiteSpeed honoring `.htaccess`, rewrite rules and `AllowOverride All`; HTTPS. No Composer, npm or database setup is required.

Upload the **contents** of `hostinger/dc-hub/` into `public_html/dc-hub-staging/`, including `.htaccess` and other dotfiles. Do not upload `apps-script`, `tests`, `docs` or `private-config` into the public site. Do not nest `dc-hub` twice.

Copy `hostinger/private-config/dc-hub-config.example.php` to a file named `dc-hub-config.php` **one directory above the document root**. For example, if the document root is `/home/USER/domains/DOMAIN/public_html`, use `/home/USER/domains/DOMAIN/dc-hub-config.php`. Set file permissions to the minimum needed for PHP to read it (typically 0600 or 0640, depending on hosting ownership).

Set its five connection values:

- `google_client_id` and `google_client_secret` from the OAuth web client.
- `google_redirect_uri` to the exact staging URI above.
- `apps_script_url` to the new staging `/exec` URL.
- `shared_secret` to the same secure value as `HUB_SHARED_SECRET`.

If hosting requires a different path, set server environment variable `HUB_CONFIG_FILE` to that absolute path. The application rejects a real configuration file inside the public document root. It does not read the old shared-password `auth/config.php`.

Keep normal TLS verification and trusted CA configuration. Required outbound destinations are `accounts.google.com`, `oauth2.googleapis.com`, `script.google.com`, its `script.googleusercontent.com` content redirect, Google Docs and the Google APIs used by Apps Script. Do not disable TLS checks to fix connectivity.

Restore approved training media and its manifest from the existing site after comparing changes; real media is not bundled. PHP needs write access to local editable scripts/notes/data, `admin/backups` and `training/media`; use ownership and 0750/0755 directories / 0640/0644 files as appropriate, never 0777. Set `upload_max_filesize=50M` and `post_max_size=55M` or greater for the retained media editor.

Opening staging before configuration shows an honest connection-pending state. No default password or production credential is included.

## 7. Staging acceptance

Follow `TEST-REPORT.md`'s live checklist. In particular:

1. Anonymous protected pages redirect; protected APIs and private files are denied.
2. Approved Google accounts can sign in; inactive and unlisted accounts cannot.
3. An Agent sees their own customer details but receives only date/time/campaign/setter for another agent's calendar appointment. Inspect the actual network response.
4. Team Leads can manage only their assigned team. Unassigned membership grants no cross-team access. Moving a user updates current visibility but preserves original team production. Suspension preserves history.
5. Confirm and reschedule a sandbox record. Existing event IDs stay unchanged and each linked copy updates. Test failure/retry with a temporary test-calendar access failure, then restore access.
6. Submit controlled records through all three **test Forms**; inspect source response, CRM, intended calendar and test Roam channel. Repeat handler processing without duplicate records/events/messages.
7. Activate a test representative and run form sync; only exact setter dropdowns change. No historical response is removed.
8. Complete each typing duration. Confirm email/name, recomputed metrics, result status and website leaderboard. Verify the existing sheet-based Typing Leaderboard formulas independently; they are preserved.
9. Edit a permitted market Google Doc and a CRM_HUB_LINKS resource. Refresh and check content, role visibility, links and safe formatting. Dialing Station's Workspace document selectors should reflect the registry.
10. Check dashboard, analytics, rankings, announcements, goals, legacy scripts/forms, meetings/check-ins, and real uploaded audio/video. Inspect browser errors and Hostinger PHP logs.

## 8. Production migration and trigger handover

Only after sandbox validation and staging acceptance:

1. Back up production again. Record active legacy trigger owners; Apps Script can list only triggers owned by the current executing account.
2. Set the staging project's `HUB_SPREADSHEET_ID` to the original workbook ID and `HUB_PRODUCTION_APPROVED` to that exact same ID. `HUB_SANDBOX_VALIDATED` must already be recorded by validation. Run `hubMigrate()`, then `hubValidateMigration()`. The production backup ID is retained separately; no original response rows are reimported.
3. Reconcile existing users' roles, team assignments and known historical Original Team values. No extra internal roles are created. Existing unsupported roles fail closed until reviewed.
4. Restore approved production calendar/form/Docs/Roam property values. Keep manual calendar selection and the required setter/closer separation. Do not leave test calendar or test channel IDs in production properties.
5. Inspect all existing handlers with `hubTriggerInventory()` and the old project's Triggers panel, including triggers owned by other users. During a controlled handover, disable old form-submit/edit/notification/sync triggers so they cannot run alongside the new handlers. Preserve rollback records. Do not blanket-delete unrelated automations.
6. Set `HUB_TRIGGERS_REVIEWED=YES` only after that review, then run `hubInstallTriggers()`. It replaces only this package's three handlers: `hubOnFormSubmit`, `hubOnEdit`, and hourly `hubSyncForms`. Roam has no independent trigger. Existing legacy triggers are not silently deleted by the installer.
7. Deploy the intended Apps Script version and configure the PHP endpoint/shared key. Promote the tested site directory, preserve approved local content/media, and set PHP's OAuth redirect to the exact production URI. Keep the previous site offline outside `public_html`.
8. Repeat the acceptance checks on production with authorized controlled records. Do not announce a working integration solely because a deployment completed.

## Rollback

Restore the previous site tree and its matching private configuration; restore prior Apps Script deployment and the recorded legacy trigger configuration, disabling the new handlers first to avoid duplicate processing. Do not delete Google Forms response history, CRM rows, appointments or typing results created after the cutover.

Migration is additive. Prefer leaving added columns in place while reverting application code. If restoring the full spreadsheet backup is necessary, first preserve all post-backup records and reconcile them explicitly; blindly replacing the workbook loses new production. Calendar and Roam actions are external effects and are not undone by restoring files. Use preserved IDs and the audit log for deliberate reconciliation. Test-calendar fixtures may be removed deliberately after inspection.
