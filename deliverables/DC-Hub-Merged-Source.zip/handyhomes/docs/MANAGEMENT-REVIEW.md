# Content for management review

Source sales copy was preserved; it was not silently edited or independently verified. Before authorizing its use for a territory/offer, verify utility-specific buyback/net-metering rules, rate increases, grid/outage warnings, incentive availability, tax-credit treatment, deadlines/expiration dates, pricing/savings and any implication of provider/utility endorsement.

This especially applies to the existing SoCal and Carolinas hooks (Edison rate/outage claims, California incentives, Duke funding/rate/data-center statements and solar tax-credit statements), and utility/offer statements in Net Metering, Battery Backup and Warm Reschedule. Roofing supplier/warranty statements require current written eligibility/coverage confirmation. Fiber serviceability, prices, contracts and transfer destinations remain provider-specific and unverified.

The supplied warm supplemental notes include the caution to use expiration claims only with a verified local offer date, with the exact alternative wording from the brief. The primary script remains separately sourced from the supplied DOCX. No unsupported offer details or provider endpoints were invented.
