/** MULTIPLE CALENDARS — COMPLETE Code.gs REPLACEMENT (FORMATTED DESCRIPTIONS)

 * Replace the entire previous Code.gs with this file. Do not append it.

 * Enable Services > Google Calendar API (Calendar).

 * After pasting BOTH files, enable Calendar API and run setupDashboard().

 * Use validateSelectedCalendarLink() only for a selected, imported linked row.

 * Imported historical records update only their explicitly linked events.

 */

/**

 * DIGITAL CITIZEN — FORM -> CRM MASTER -> GOOGLE CALENDAR

 * CRM actions write CRM MASTER and linked calendars in the same backend request.

 * Calendar never writes back; direct Sheet edits remain a supported fallback.

 * CRM MASTER is management-owned. Edit appointment date as YYYY-MM-DD and time as HH:mm.

 * Agent calendar only receives limited non-identifying information.

 * Use setupTriggers() once if the two installed triggers are absent.

 */

const DC = {

  spreadsheetId: '1EB8gX-hT9ohp64YC3qtFjvVaQZuFM7fRHMWEQQTrcb8',

  formTab: 'Form Responses 1',

  crmTab: 'CRM MASTER',

  calendarId: '609ca847994fa93712854b225f8fc411259334cb307b4f007bf872ca67402a33@group.calendar.google.com',

  agentCalendarId: 'c00c3076f16ee193fd19c4bf934c5d8683b31cb9ebc3bafc98cf4338a084e8a0@group.calendar.google.com',

  defaultZone: 'America/Chicago',

  durationMinutes: 60,

  zones: ['America/New_York','America/Chicago','America/Denver','America/Los_Angeles','America/Phoenix','America/Anchorage','Pacific/Honolulu']

};

function dcNorm_(v) { return String(v == null ? '' : v).trim().toLowerCase().replace(/\s+/g, ' '); }

function dcText_(v) { return String(v == null ? '' : v).trim(); }

function dcHeaders_(sh) { return sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0]; }

function dcCol_(h,n) { const i=h.findIndex(v=>dcNorm_(v)===dcNorm_(n)); if(i<0) throw Error('Missing CRM header: '+n); return i+1; }

function dcCell_(sh,h,r,n) { return sh.getRange(r,dcCol_(h,n)); }

let dcRowSnapshot_=null;
function dcSnapshotValue_(sh,row,name){
  const snapshot=dcRowSnapshot_,key=dcNorm_(name);
  // These values can change during event creation or synchronization; always read them fresh.
  if(!snapshot||snapshot.sh!==sh||snapshot.row!==row||/^(calendar |agent calendar |last |linked event |crm revision$|updated by$|reschedule count$)/.test(key))return undefined;
  const i=snapshot.idx[key];return i===undefined?undefined:snapshot.values[i];
}
function dcWithRowSnapshot_(sh,h,row,work){
  const previous=dcRowSnapshot_;
  dcRowSnapshot_={sh,row,idx:Object.fromEntries(h.map((k,i)=>[dcNorm_(k),i])),values:sh.getRange(row,1,1,h.length).getDisplayValues()[0]};
  try{return work();}finally{dcRowSnapshot_=previous;}
}
function dcGet_(sh,h,r,n) { const cached=dcSnapshotValue_(sh,r,n);return cached===undefined?dcText_(dcCell_(sh,h,r,n).getDisplayValue()):dcText_(cached); }
function dcMarkInteractiveSave_(){PropertiesService.getScriptProperties().setProperty('DC_LAST_INTERACTIVE_SAVE',String(Date.now()));}
function dcInteractiveSaveRecent_(){return Date.now()-Number(PropertiesService.getScriptProperties().getProperty('DC_LAST_INTERACTIVE_SAVE')||0)<15000;}

function dcSs_() { return SpreadsheetApp.openById(DC.spreadsheetId); }

function dcCalendar_() { const c=CalendarApp.getCalendarById(DC.calendarId); if(!c) throw Error('Calendar inaccessible: check account permission / ID'); return c; }

function dcAgentCalendar_() { const c=CalendarApp.getCalendarById(DC.agentCalendarId); if(!c) throw Error('Agent calendar inaccessible: check sharing permissions / Calendar ID'); return c; }

function dcSafe_(v) { return typeof v==='string' && /^[=+@-]/.test(v) ? "'"+v : v; }

// Single-zone states. Multiple-zone states use the predominant zone, except

// listed ZIP overrides. Unknown states fall back to Central (as requested).

function dcZoneForState_(state,zip) {

  const aliases = {

    ALABAMA:'AL',ALASKA:'AK',ARIZONA:'AZ',ARKANSAS:'AR',CALIFORNIA:'CA',COLORADO:'CO',CONNECTICUT:'CT',DELAWARE:'DE',FLORIDA:'FL',GEORGIA:'GA',HAWAII:'HI',IDAHO:'ID',ILLINOIS:'IL',INDIANA:'IN',IOWA:'IA',KANSAS:'KS',KENTUCKY:'KY',LOUISIANA:'LA',MAINE:'ME',MARYLAND:'MD',MASSACHUSETTS:'MA',MICHIGAN:'MI',MINNESOTA:'MN',MISSISSIPPI:'MS',MISSOURI:'MO',MONTANA:'MT',NEBRASKA:'NE',NEVADA:'NV', 'NEW HAMPSHIRE':'NH','NEW JERSEY':'NJ','NEW MEXICO':'NM','NEW YORK':'NY','NORTH CAROLINA':'NC','NORTH DAKOTA':'ND',OHIO:'OH',OKLAHOMA:'OK',OREGON:'OR',PENNSYLVANIA:'PA','RHODE ISLAND':'RI','SOUTH CAROLINA':'SC','SOUTH DAKOTA':'SD',TENNESSEE:'TN',TEXAS:'TX',UTAH:'UT',VERMONT:'VT',VIRGINIA:'VA',WASHINGTON:'WA','WEST VIRGINIA':'WV',WISCONSIN:'WI',WYOMING:'WY','DISTRICT OF COLUMBIA':'DC'

  };

  let s=dcText_(state).toUpperCase().replace(/\./g,'');

  s=aliases[s]||s;

  const z=dcText_(zip).match(/^\d{5}/);

  const postal=z?z[0]:'';

  // Common cross-zone corrections; not intended as a comprehensive ZIP database.

  if(s==='TX' && /^(798|799)/.test(postal)) return 'America/Denver';

  if(s==='FL' && /^(324|325)/.test(postal)) return 'America/Chicago';

  if(s==='ID' && /^(835|838)/.test(postal)) return 'America/Los_Angeles';

  if(s==='OR' && /^979/.test(postal)) return 'America/Denver';

  const eastern='CT DE DC GA MA MD ME NC NH NJ NY OH PA RI SC VA VT WV';

  const central='AL AR IA IL LA MN MO MS OK WI';

  const mountain='CO MT NM UT WY';

  const pacific='CA NV WA';

  if(eastern.split(' ').includes(s)) return 'America/New_York';

  if(central.split(' ').includes(s)) return 'America/Chicago';

  if(mountain.split(' ').includes(s)) return 'America/Denver';

  if(pacific.split(' ').includes(s)) return 'America/Los_Angeles';

  if(s==='AZ') return 'America/Phoenix';

  if(s==='AK') return 'America/Anchorage';

  if(s==='HI') return 'Pacific/Honolulu';

  // Predominant zone for states split across multiple time zones.

  const mixed={FL:'America/New_York',ID:'America/Denver',IN:'America/New_York',KS:'America/Chicago',KY:'America/New_York',MI:'America/New_York',NE:'America/Chicago',ND:'America/Chicago',OR:'America/Los_Angeles',SD:'America/Chicago',TN:'America/Chicago',TX:'America/Chicago'};

  return mixed[s]||DC.defaultZone;

}

function dcDate_(v,sheetZone) {

  if(v instanceof Date && !isNaN(v)) return Utilities.formatDate(v,sheetZone,'yyyy-MM-dd');

  const s=dcText_(v);

  let m=s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);

  if(m) return `${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`;

  m=s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);

  if(m) return `${m[3]}-${m[1].padStart(2,'0')}-${m[2].padStart(2,'0')}`;

  throw Error('Invalid appointment date: '+s);

}

function dcTime_(v,sheetZone) {

  if(v instanceof Date && !isNaN(v)) return Utilities.formatDate(v,sheetZone,'HH:mm');

  if(typeof v==='number') {

    const minutes=Math.round(((v%1+1)%1)*1440)%1440;

    return `${String(Math.floor(minutes/60)).padStart(2,'0')}:${String(minutes%60).padStart(2,'0')}`;

  }

  const s=dcText_(v).toUpperCase();

  const m=s.match(/^(\d{1,2}):(\d{2})(?::\d{2})?\s*(AM|PM)?$/);

  if(!m) throw Error('Invalid time: '+s+' (enter 14:30)');

  let hh=Number(m[1]); const mm=Number(m[2]);

  if(m[3]) { if(hh<1||hh>12) throw Error('Invalid time: '+s); hh=hh%12+(m[3]==='PM'?12:0); }

  if(hh>23||mm>59) throw Error('Invalid time: '+s);

  return `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}`;

}

function dcSchedule_(sh,h,row) {

  const sheetZone=sh.getParent().getSpreadsheetTimeZone();

  const date=dcDate_(dcCell_(sh,h,row,'Appointment Date').getValue(),sheetZone);

  const time=dcTime_(dcCell_(sh,h,row,'Start Time').getValue(),sheetZone);

  const zone=dcGet_(sh,h,row,'Appointment Time Zone')||DC.defaultZone;

  if(!DC.zones.includes(zone)) throw Error('Unsupported zone in row '+row+': '+zone);

  const wall=date+' '+time;

  const start=Utilities.parseDate(wall,zone,'yyyy-MM-dd HH:mm');

  if(Utilities.formatDate(start,zone,'yyyy-MM-dd HH:mm')!==wall) throw Error('Invalid local date or DST time: '+wall+' '+zone);

  dashValidateSchedule_(date,time,zone);

  return {date,time,zone,start,end:new Date(start.getTime()+DC.durationMinutes*60000)};

}

function dcReadForm_(sheet,row) {

  const h=dcHeaders_(sheet);

  const raw=sheet.getRange(row,1,1,h.length).getValues()[0];

  const shown=sheet.getRange(row,1,1,h.length).getDisplayValues()[0];

  function f(names,typed) {

    for(const name of names) {

      const i=h.findIndex(v=>dcNorm_(v)===dcNorm_(name));

      if(i<0) continue;

      const v=typed?raw[i]:dcText_(shown[i]);

      if(v!=='' && v!==null && v!==undefined) return v;

    }

    return '';

  }

  return {

    timestamp:f(['Timestamp'],true),

    appointmentDate:f(['Appointment Date'],true),

    appointmentTime:f(['Appointment Time'],true),

    // Legacy combined question remains supported for older form versions.

    appointment:f(['Appointment Date and Time'],true),

    campaign:f(['Campaign']),

    first:f(['First Name']),last:f(['Last Name']),spouse:f(['Spouses Name']),

    phone:f(['Phone Number']),

    // "Email" is the homeowner. Never fall back to "Email Address" (agent).

    email:f(['Email','Homeowner Email','Customer Email']),

    fullAddress:f(['Full Address']),street:f(['Street Address']),

    city:f(['City']),state:f(['State']),zip:f(['Zip Code','ZIP Code']),

    homeowner:f(['You are the homeowner at (address), correct?']),

    highest:f(['How much was the highest electric bill you got this year?']),

    lowest:f(['And what was the lowest electric bill?']),

    improvements:f(['Have you made any improvements to the efficiency of the home? ( Insulation / AC / Windows)']),

    delivery:f(['Do you get your bill online or in the mail?']),

    utility:f(['And who is the service provider (electric company)']),

    roof:f(['Roof Condition **Age of Roof**']),

    credit:f(['Do you have a Credit Score of 650 or more?']),

    approximateCredit:f(['Approximate Credit Score']),notes:f(['Notes']),

    confirmation:f(['We will confirm your appointment an hour or two before, will text or call be a better way to reach you?']),

    reason:f(['One last question, ___ what is the main reason you would like to have this appointment with us?']),

    setter:f(['Setter Name']),stage:f(['Setter Stage Name']),recording:f(['Call Recording'])

  };

}

// Capture the separate date and time fields without converting homeowner-local

// wall time into the spreadsheet's timezone. Legacy combined fields still work.

function dcFormSchedule_(f,sheetZone,sourceRow) {

  if(f.appointmentDate!=='' && f.appointmentTime!=='') {

    const date=dcDate_(f.appointmentDate,sheetZone);

    const time=dcTime_(f.appointmentTime,sheetZone);

    return {date,time,original:date+' '+time};

  }

  if(f.appointment instanceof Date && !isNaN(f.appointment.getTime())) {

    const date=Utilities.formatDate(f.appointment,sheetZone,'yyyy-MM-dd');

    const time=Utilities.formatDate(f.appointment,sheetZone,'HH:mm');

    return {date,time,original:date+' '+time};

  }

  const m=dcText_(f.appointment).match(/^(\d{4}-\d{1,2}-\d{1,2})[ T](\d{1,2}:\d{2})(?::\d{2})?$/);

  if(m) {

    const date=dcDate_(m[1],sheetZone),time=dcTime_(m[2],sheetZone);

    return {date,time,original:date+' '+time};

  }

  throw Error('Appointment Date/Time missing or invalid in form row '+sourceRow);

}

function dcAddress_(f) {

  const arr=[f.street,f.city,f.state,f.zip].filter(Boolean);

  return arr.length<2 && f.fullAddress ? f.fullAddress : (arr.join(', ')||f.fullAddress);

}

function dcTitle_(sh,h,row) {

  const name=[dcGet_(sh,h,row,'First Name'),dcGet_(sh,h,row,'Last Name')].filter(Boolean).join(' ')||'Solar Appointment';

  return name+' - '+(dcGet_(sh,h,row,'Appointment Status')||'Scheduled');

}

function dcFirstLine_(s) {return `Appointment Date and Time: ${s.date} ${s.time} (${s.zone})`;}

function dcDescription_(f,s) {

  return [dcFirstLine_(s), 'First Name: '+f.first,'Last Name: '+f.last,"Spouse's Name: "+f.spouse,

    'Phone Number: '+f.phone,'Email: '+f.email,'Full Address: '+dcAddress_(f),

    'Highest Electric Bill: '+f.highest,'Lowest Electric Bill: '+f.lowest,

    'Energy Efficiency Improvements: '+f.improvements,'Bill Online or Mail: '+f.delivery,

    'Service Provider: '+f.utility,'Roof Condition: '+f.roof,'Credit Score 650 or More: '+f.credit,

    'Notes: '+f.notes,'Appointment Confirmation (Call or Text): '+f.confirmation,

    'Main Reason for Appointment: '+f.reason,'Setter Stage Name: '+f.stage].join('\n');

}

// Primary management calendar description: only the fields shown to the appointment recipient.
// Blank entries separate information groups without exposing internal CRM metadata.
function dcCrmDescription_(crm,h,row,s) {
  const g=n=>dcGet_(crm,h,row,n);
  return [
    dcFirstLine_(s),
    'Lead ID: '+g('Lead ID'),
    '',
    'First Name: '+g('First Name'),
    'Last Name: '+g('Last Name'),
    'Spouse / Co-Decision Maker: '+g('Spouse / Co-Decision Maker'),
    '',
    'Phone Number: '+g('Phone Number'),
    'Customer Email: '+g('Email'),
    '',
    'Address: '+[g('Street Address'),g('City'),g('State'),g('ZIP Code')].filter(Boolean).join(', '),
    '',
    'Utility Provider: '+g('Utility Provider'),
    'Highest Electric Bill: '+g('Highest Electric Bill'),
    'Lowest Electric Bill: '+g('Lowest Electric Bill'),
    '',
    'Credit Qualification: '+g('Credit Qualification'),
    'Approximate Credit Score: '+g('Approximate Credit Score'),
    '',
    'Roof Condition: '+g('Roof Condition'),
    'Energy Improvements: '+g('Energy Improvements'),
    '',
    'Preferred Confirmation Method: '+g('Preferred Confirmation Method'),
    '',
    'Appointment Reason: '+g('Appointment Reason'),
    '',
    'Notes: '+g('Qualification Notes')
  ].join('\n');
}

// Optional one-time update for an existing FORM-created calendar appointment.
// Select its row in CRM MASTER, then run this function from Apps Script.
// Imported partner events are intentionally excluded so their historical notes remain intact.
function refreshSelectedAppointmentDescription() {
  const crm=dcSs_().getSheetByName(DC.crmTab);
  if(!crm) throw Error('CRM MASTER tab missing');
  const selection=SpreadsheetApp.getActiveRange();
  if(!selection || selection.getSheet().getSheetId()!==crm.getSheetId() || selection.getRow()<2)
    throw Error('Select an appointment row in CRM MASTER first');
  const row=selection.getRow();
  const h=dcHeaders_(crm);
  if(dcGetOptional_(crm,h,row,'Calendar API Event ID'))
    throw Error('This is an imported partner event. Its original description is preserved.');
  const eventId=dcGet_(crm,h,row,'Calendar Event ID');
  if(!eventId) throw Error('This CRM row is not linked to a calendar event');
  const calendar=dcCalendarForRow_(crm,h,row);
  const event=calendar.getEventById(eventId);
  if(!event) throw Error('The linked calendar event could not be found');
  const description=dcCrmDescription_(crm,h,row,dcSchedule_(crm,h,row));
  if(event.getDescription()!==description) event.setDescription(description);
  Logger.log('Updated description for '+dcGet_(crm,h,row,'Lead ID'));
}

function dcLinkedForm_(crm,h,row) {

  const key=dcGet_(crm,h,row,'Form Submission Key');

  const m=key.match(/:form-row:(\d+)$/); if(!m) return null;

  const source=crm.getParent().getSheetByName(DC.formTab);

  const n=Number(m[1]); return source&&n>=2&&n<=source.getLastRow()?dcReadForm_(source,n):null;

}

// Permanent, readable homeowner ID: DC-JS-7564, optional -02 suffix.

// Submission keys are ONLY for import deduplication and never become Lead IDs.

function dcLeadBase_(first,last,phone) {

  const a=dcText_(first).normalize('NFD').replace(/[\u0300-\u036f]/g,'').match(/[A-Za-z]/);

  const b=dcText_(last).normalize('NFD').replace(/[\u0300-\u036f]/g,'').match(/[A-Za-z]/);

  const digits=dcText_(phone).replace(/\D/g,'');

  if(!a || !b || digits.length<4) return '';

  return 'DC-'+a[0].toUpperCase()+b[0].toUpperCase()+'-'+digits.slice(-4);

}

function dcSameLead_(first,last,phone,existingFirst,existingLast,existingPhone) {

  const normName=x=>dcText_(x).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z]/g,'');

  const normPhone=x=>dcText_(x).replace(/\D/g,'');

  const p1=normPhone(phone),p2=normPhone(existingPhone);

  return p1.length>=7 && p1===p2 &&

    normName(first)===normName(existingFirst) && normName(last)===normName(existingLast);

}

function dcGenerateLeadId_(crm,h,first,last,phone,excludeRow) {

  const base=dcLeadBase_(first,last,phone);

  const lastRow=crm.getLastRow();

  const seen=new Set();

  if(lastRow>=2) {

    const ids=crm.getRange(2,dcCol_(h,'Lead ID'),lastRow-1,1).getDisplayValues();

    const firstNames=crm.getRange(2,dcCol_(h,'First Name'),lastRow-1,1).getDisplayValues();

    const lastNames=crm.getRange(2,dcCol_(h,'Last Name'),lastRow-1,1).getDisplayValues();

    const phones=crm.getRange(2,dcCol_(h,'Phone Number'),lastRow-1,1).getDisplayValues();

    for(let i=0;i<ids.length;i++) {

      if(i+2===excludeRow) continue;

      const id=dcText_(ids[i][0]);

      if(!id) continue;

      seen.add(id);

      if(dcSameLead_(first,last,phone,firstNames[i][0],lastNames[i][0],phones[i][0])) return id;

    }

  }

  // Incomplete identifiers get a flagged unique fallback, not a misleading ID.

  if(!base) {

    let fallback;

    do {fallback='DC-REVIEW-'+Utilities.getUuid().slice(0,6).toUpperCase();}

    while(seen.has(fallback));

    return fallback;

  }

  if(!seen.has(base)) return base;

  let n=2;

  while(seen.has(base+'-'+String(n).padStart(2,'0'))) n++;

  return base+'-'+String(n).padStart(2,'0');

}

// AGENT TRACKER CALENDAR: deliberately limited information only.

// An independent event ID prevents duplicate events on normal CRM edits.

function dcAgentTitle_(crm,h,row) {

  const lead=dcGet_(crm,h,row,'Lead ID')||'Unassigned Lead';

  const agent=dcGet_(crm,h,row,'Setter Name')||'Unassigned Agent';

  const status=dcGet_(crm,h,row,'Appointment Status')||'Scheduled';

  return lead+' - '+agent+' - '+status;

}

function dcOriginalAppointment_(crm,h,row) {

  const cell=dcCell_(crm,h,row,'Original Appointment Date and Time');

  const value=cell.getValue();

  if(value instanceof Date && !isNaN(value.getTime())) {

    return Utilities.formatDate(value,crm.getParent().getSpreadsheetTimeZone(),'yyyy-MM-dd HH:mm');

  }

  return dcText_(cell.getDisplayValue());

}

function dcAgentDescription_(crm,h,row) {

  return [

    'Lead ID: '+dcGet_(crm,h,row,'Lead ID'),

    'Original Appointment Date: '+dcOriginalAppointment_(crm,h,row),

    'Preferred Confirmation Method: '+dcGet_(crm,h,row,'Preferred Confirmation Method'),

    // Free-text qualification notes stay on the management calendar.

    'Credit Qualification: '+dcGet_(crm,h,row,'Credit Qualification'),

    'Highest Electric Bill: '+dcGet_(crm,h,row,'Highest Electric Bill'),

    'Utility Provider: '+dcGet_(crm,h,row,'Utility Provider'),

    'Appointment Setter: '+dcGet_(crm,h,row,'Setter Name'),

    'City: '+dcGet_(crm,h,row,'City'),

    'State: '+dcGet_(crm,h,row,'State')

  ].join('\n');

}

function dcAgentSync_(crm,h,row) {

  // Imported historical events do not create an extra agent event.

  if(dcGetOptional_(crm,h,row,'Calendar API Event ID') && !dcGet_(crm,h,row,'Agent Calendar Event ID')) return;

  // Only mirror appointments already associated with an original Calendar event.

  if(!dcGet_(crm,h,row,'Calendar Event ID')) return;

  const idCell=dcCell_(crm,h,row,'Agent Calendar Event ID');

  const eventId=dcText_(idCell.getDisplayValue());

  const calendar=dcAgentCalendar_();

  const schedule=dcSchedule_(crm,h,row);

  const title=dcAgentTitle_(crm,h,row);

  const description=dcAgentDescription_(crm,h,row);

  if(eventId) {

    const event=calendar.getEventById(eventId);

    if(!event) throw Error('Agent Calendar Event ID not found, CRM row '+row+': '+eventId);

    if(event.getTitle()!==title) event.setTitle(title);

    if(event.getStartTime().getTime()!==schedule.start.getTime() ||

       event.getEndTime().getTime()!==schedule.end.getTime()) event.setTime(schedule.start,schedule.end);

    if(event.getDescription()!==description) event.setDescription(description);

    // Never copy address, phone, email, homeowner identity, or internal notes.

    if(event.getLocation()) event.setLocation('');

  } else {

    const created=dcCreateFormEvent_(crm,h,row,DC.agentCalendarId,'agent',title,description,'',schedule);

    idCell.setValue(created.iCalUID);

    SpreadsheetApp.flush();

  }



  Logger.log('Agent tracker synchronized for CRM row '+row);

}

// INSTALLABLE spreadsheet On form submit trigger.

function onFormSubmit(e) {
  if (!e || !e.range) {
    throw Error('onFormSubmit must be invoked by the spreadsheet trigger');
  }

  if (e.range.getSheet().getName() !== DC.formTab) return;

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);

  try {
    dcImport_(e.range.getSheet(), e.range.getRow());
  } finally {
    lock.releaseLock();
  }

  try {
    sendRoamAppointmentNotification(e);
  } catch (error) {
    console.error('Roam notification failed:', error);
  }
}


function dcImport_(source,sourceRow) {

  const ss=dcSs_(),crm=ss.getSheetByName(DC.crmTab);

  if(!crm) throw Error('CRM MASTER tab missing');

  const h=dashEnsureMetadata_(crm);

  const f=dcReadForm_(source,sourceRow),key=ss.getId()+':form-row:'+sourceRow;

  let row=0;

  const last=crm.getLastRow();

  if(last>1) {

    const keys=crm.getRange(2,dcCol_(h,'Form Submission Key'),last-1,1).getDisplayValues();

    const index=keys.findIndex(x=>dcText_(x[0])===key);

    if(index>=0) row=index+2;

  }

  if(!row) {

        const stz=ss.getSpreadsheetTimeZone();

    const {date,time,original}=dcFormSchedule_(f,stz,sourceRow);

    if(!f.first || !f.last || !f.phone) throw Error('Missing name or phone in form row '+sourceRow);

    if(!f.state) throw Error('Missing state (needed for appointment timezone) in form row '+sourceRow);

const v={

      'Record Type':'Appointment','Campaign':'','Appointment Status':'Scheduled',

      'CRM Revision':0,'Calendar Sync Status':'Pending','Reschedule Count':0,

      'Confirmation Status':'Not Started','Follow-Up Status':'Pending','Disposition':'Pending Outcome',

      'Appointment Date':date,'Start Time':time,

      'Appointment Time Zone':dcZoneForState_(f.state,f.zip),

      'First Name':f.first,'Last Name':f.last,'Phone Number':f.phone,

      'Street Address':f.street||f.fullAddress,'City':f.city,'State':f.state,'ZIP Code':f.zip,

      'Spouse / Co-Decision Maker':f.spouse,'Email':f.email,'Homeowner Confirmed':f.homeowner,

      'Utility Provider':f.utility,'Highest Electric Bill':f.highest,'Lowest Electric Bill':f.lowest,

      'Energy Improvements':f.improvements,'Bill Delivery Method':f.delivery,'Roof Condition':f.roof,

      'Credit Qualification':f.credit,'Approximate Credit Score':f.approximateCredit,

      'Qualification Notes':f.notes,'Appointment Reason':f.reason,

      'Preferred Confirmation Method':f.confirmation,'Setter Name':f.setter,'Call Recording':f.recording,

      'Original Appointment Date and Time':original,'Submission Timestamp':f.timestamp,

      'Created At':new Date(),'Last Updated':new Date(),'Form Submission Key':key,

      'Lead ID':dcGenerateLeadId_(crm,h,f.first,f.last,f.phone,0)

    };

    row=crm.getLastRow()+1;

    if(row>crm.getMaxRows()) crm.insertRowsAfter(crm.getMaxRows(),row-crm.getMaxRows());

    crm.getRange(row,1,1,h.length).setValues([h.map(k=>Object.prototype.hasOwnProperty.call(v,k)?dcSafe_(v[k]):'')]);

    dcCell_(crm,h,row,'Appointment Date').setNumberFormat('@');

    dcCell_(crm,h,row,'Start Time').setNumberFormat('@');

    SpreadsheetApp.flush();

  }

  // The dashboard, form trigger, and retry job all use this same sync path.

  const result=dashSync_(crm,h,row);

  if(result.errors.length) Logger.log(result.message);

  dcCell_(crm,h,row,'Last Updated').setValue(new Date());

}



// INSTALLABLE spreadsheet On edit trigger. Only CRM -> Calendar.

function onCrmEdit(e) {

  if(!e||!e.range||e.range.getSheet().getName()!==DC.crmTab) return;

  const sh=e.range.getSheet(),h=dcHeaders_(sh);

  // Any manager-edited appointment field can affect the corresponding event.

  // Operational status/qualification edits are mirrored to descriptions too.

  const ignored=new Set(['Calendar Event ID','Agent Calendar Event ID','Last Updated','Updated By','Created At','Form Submission Key']);

  const touched=h.slice(e.range.getColumn()-1,e.range.getLastColumn()).some(x=>!ignored.has(x));

  if(!touched) return;

  const lock=LockService.getScriptLock();lock.waitLock(30000);

  try {for(let r=Math.max(2,e.range.getRow());r<=e.range.getLastRow();r++) {

    try {

      if(dcGetOptional_(sh,h,r,'Record Type').toLowerCase()!=='appointment') continue;

      dashEnsureMetadata_(sh);

      const updatedHeaders=dcHeaders_(sh);

      const revision=Number(dcGetOptional_(sh,updatedHeaders,r,'CRM Revision')||0)+1;

      dcSetOptional_(sh,updatedHeaders,r,'CRM Revision',revision);

      dashSync_(sh,updatedHeaders,r);

    } catch(err) {

      dcSetOptional_(sh,h,r,'Calendar Sync Status','ERROR: '+err.message);

      Logger.log('CRM row '+r+': '+err.message);

    }

  }}

  finally {lock.releaseLock();}

}

function dcLegacySync_(crm,h,row) {

  const id=dcGet_(crm,h,row,'Calendar Event ID');

  if(!id) {Logger.log('Row '+row+' has no linked Calendar Event ID; skipped to avoid duplicate');return;}

  const event=dcCalendarForRow_(crm,h,row).getEventById(id);

  if(!event) throw Error('Calendar Event ID not found for CRM row '+row+': '+id);

  const s=dcSchedule_(crm,h,row),title=dcTitle_(crm,h,row);

  if(event.getTitle()!==title) event.setTitle(title);

  if(event.getStartTime().getTime()!==s.start.getTime() || event.getEndTime().getTime()!==s.end.getTime())

    event.setTime(s.start,s.end);

  const description=dcCrmDescription_(crm,h,row,s);

  if(event.getDescription()!==description) event.setDescription(description);

  const location=[dcGet_(crm,h,row,'Street Address'),dcGet_(crm,h,row,'City'),dcGet_(crm,h,row,'State'),dcGet_(crm,h,row,'ZIP Code')].filter(Boolean).join(', ');

  if(event.getLocation()!==location) event.setLocation(location);

  dcCell_(crm,h,row,'Last Updated').setValue(new Date());

  Logger.log('Updated Calendar from CRM row '+row);

}

// Optional. Only run if either installable trigger is missing.

function setupTriggers() {

  const ss=dcSs_(),existing=ScriptApp.getProjectTriggers();

  for(const [name,type] of [['onFormSubmit',ScriptApp.EventType.ON_FORM_SUBMIT],['onCrmEdit',ScriptApp.EventType.ON_EDIT]]) {

    if(existing.some(t=>t.getHandlerFunction()===name&&t.getEventType()===type&&t.getTriggerSourceId()===ss.getId())) continue;

    const b=ScriptApp.newTrigger(name).forSpreadsheet(ss);

    if(type===ScriptApp.EventType.ON_EDIT)b.onEdit().create();else b.onFormSubmit().create();

  }

  if(!existing.some(t=>t.getHandlerFunction()==='retryPendingCalendarSync'))

    ScriptApp.newTrigger('retryPendingCalendarSync').timeBased().everyMinutes(5).create();

  Logger.log('Form, CRM edit and five-minute retry triggers checked.');

}

// Test an EXISTING linked CRM row. Change the row before running.

function testCalendarSync() {

  const crm=dcSs_().getSheetByName(DC.crmTab);

  const h=dcHeaders_(crm);

  dcSync_(crm,h,42);

  dcAgentSync_(crm,h,42);

}

// OPTIONAL BACKFILL: adds agent tracker events for previously imported

// appointments that already have a primary Calendar Event ID.

// Run only after reviewing the agent calendar for pre-existing duplicates.

function backfillAgentCalendar() {

  const crm=dcSs_().getSheetByName(DC.crmTab),h=dcHeaders_(crm);

  const lock=LockService.getScriptLock();lock.waitLock(30000);

  try {

    for(let row=2;row<=crm.getLastRow();row++) {

      if(dcGet_(crm,h,row,'Calendar Event ID') &&

         !dcGet_(crm,h,row,'Agent Calendar Event ID')) {

        try {dcAgentSync_(crm,h,row);} catch(err) {Logger.log('Row '+row+': '+err.message);}

      }

    }

  } finally {lock.releaseLock();}

}

// ONE-TIME REPAIR: Correct IDs created by the random UUID version.

// Leaves all pre-existing readable IDs and submission keys unchanged.

// Run once manually, after backing up CRM MASTER.

function repairRandomLeadIds() {

  const crm=dcSs_().getSheetByName(DC.crmTab),h=dcHeaders_(crm);

  const lock=LockService.getScriptLock();lock.waitLock(30000);

  try {

    const count=crm.getLastRow();

    const bad=[];

    for(let r=2;r<=count;r++) {

      const id=dcGet_(crm,h,r,'Lead ID');

      if(/^DC-FORM-[0-9A-F]{12}$/i.test(id)) bad.push(r);

    }

    for(const r of bad) {

      const id=dcGenerateLeadId_(crm,h,

        dcGet_(crm,h,r,'First Name'),dcGet_(crm,h,r,'Last Name'),

        dcGet_(crm,h,r,'Phone Number'),r);

      dcCell_(crm,h,r,'Lead ID').setValue(id);

      // Rewrite the agent event title/description only if its event already exists.

      if(dcGet_(crm,h,r,'Agent Calendar Event ID')) {

        try {dcAgentSync_(crm,h,r);} 

        catch(e) {Logger.log('Agent calendar row '+r+': '+e.message);}

      }

      Logger.log('Repaired row '+r+' -> '+id);

    }

    Logger.log('Repaired '+bad.length+' generated Lead IDs');

  } finally {lock.releaseLock();}

}

// MULTIPLE-CALENDAR SUPPORT — imported records use verified REST event IDs.

// Calendar API IDs and CalendarApp iCalUIDs are deliberately separate.

// Enable Services > Google Calendar API (identifier Calendar) before using.

const DC_ALLOWED_CALENDARS = ["ea930fb13ea199cf1f181a7101e848281e8be9d0383a154e2ac8701edd067ccb@group.calendar.google.com", "7e35f9c72888f1554ca0636472e23afaa03a2fffa0c4f0fff67e2d8e40c5d9e1@group.calendar.google.com", "42a099e4d5e7eb842bfa1479cded10a2dc307a744c82b9859d658c8f24ef028c@group.calendar.google.com", "609ca847994fa93712854b225f8fc411259334cb307b4f007bf872ca67402a33@group.calendar.google.com", "73b2b2e4e77bbb533e9aa43e788ff196fe6f01da971cbff761436002634ea070@group.calendar.google.com", "937e80280d3cf07b1086576c961dfed1f3d46313f10b2bf1f6eaf1760a891783@group.calendar.google.com", "7e86d8960f68d8f845384a5f2f7eb4bae576b766b4bc147bdc4daa5d809c4f36@group.calendar.google.com", "1b15bfb8be79cd47b90f7534677d318d415719a9738997feea1f390943e86597@group.calendar.google.com"];

const DC_LINK_FIELDS=['Appointment Date','Start Time','Appointment Time Zone','Street Address','City','State','ZIP Code'];

function dcGetOptional_(sh,h,row,name) {

  const i=h.indexOf(name);if(i<0)return '';
  const cached=dcSnapshotValue_(sh,row,name);return cached===undefined?dcText_(sh.getRange(row,i+1).getDisplayValue()):dcText_(cached);

}

function dcSetOptional_(sh,h,row,name,value) {

  const i=h.indexOf(name); if(i>=0) sh.getRange(row,i+1).setValue(value);

}

function dcCalendarForRow_(crm,h,row) {

  const id=dcGetOptional_(crm,h,row,'Calendar ID')||DC.calendarId;

  if(!DC_ALLOWED_CALENDARS.includes(id)) throw Error('Calendar ID is outside the selected calendars');

  const cal=CalendarApp.getCalendarById(id);

  if(!cal) throw Error('Linked calendar is inaccessible');

  return cal;

}

function dcLinkSnapshot_(crm,h,row) {

  const result={}; DC_LINK_FIELDS.forEach(k=>result[k]=dcGetOptional_(crm,h,row,k));return result;

}

function dcSync_(crm,h,row) {

  const apiId=dcGetOptional_(crm,h,row,'Calendar API Event ID');

  if(apiId) return dcApiSync_(crm,h,row,apiId);

  if(!dcGet_(crm,h,row,'Calendar Event ID')) {

    Logger.log('Unlinked CRM row '+row+' skipped. No event created.');return;

  }

  return dcLegacySync_(crm,h,row);

}

function dcLinkedApiEvent_(crm,h,row,apiId) {

  if(typeof Calendar==='undefined') throw Error('Enable Services > Google Calendar API first');

  const calId=dcGetOptional_(crm,h,row,'Calendar ID');

  if(!calId || !DC_ALLOWED_CALENDARS.includes(calId)) throw Error('Missing or unapproved Calendar ID');

  if(dcGetOptional_(crm,h,row,'Calendar Match Status')!=='Linked') throw Error('Calendar link requires review');

  const event=Calendar.Events.get(calId,apiId);

  if(!event || event.status==='cancelled') throw Error('Linked event is unavailable or cancelled; no replacement created');

  // Independent phone or name check protects against an edited/wrong ID.

  const clean=x=>String(x||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');

  const name=clean(dcGet_(crm,h,row,'First Name')+' '+dcGet_(crm,h,row,'Last Name'));

  const title=clean(event.summary||'');

  const phone=dcGet_(crm,h,row,'Phone Number').replace(/\D/g,'').slice(-10);

  const numbers=(event.description||'').replace(/\D/g,'');

  if(!(name && title.includes(name)) && !(phone.length===10 && numbers.includes(phone))) {

    throw Error('Linked event identity differs from the CRM. Review its link first.');

  }

  return {event,calId};

}

function dcApiSync_(crm,h,row,apiId) {

  const {event,calId}=dcLinkedApiEvent_(crm,h,row,apiId);

  const raw=dcGetOptional_(crm,h,row,'Calendar Sync Baseline');

  if(!raw) throw Error('Missing import baseline; validate the link before editing');

  let before; try {before=JSON.parse(raw);} catch(e) {throw Error('Invalid Calendar Sync Baseline');}

  const now=dcLinkSnapshot_(crm,h,row);

  const changed=k=>String(before[k]||'')!==String(now[k]||'');

  const patch={};

  if(['Appointment Date','Start Time','Appointment Time Zone'].some(changed)) {

    if(event.start.date && !now['Start Time']) {

      const date=dcDate_(now['Appointment Date'],crm.getParent().getSpreadsheetTimeZone());

      const days=Math.max(1,Math.round((Date.parse(event.end.date)-Date.parse(event.start.date))/86400000));

      patch.start={date};patch.end={date:new Date(Date.parse(date+'T00:00:00Z')+days*86400000).toISOString().slice(0,10)};

    } else {

      const schedule=dcSchedule_(crm,h,row);

      const duration=event.start.dateTime ? Date.parse(event.end.dateTime)-Date.parse(event.start.dateTime) : DC.durationMinutes*60000;

      if(!(duration>0)) throw Error('Invalid existing event duration');

      patch.start={dateTime:schedule.start.toISOString(),timeZone:schedule.zone};

      patch.end={dateTime:new Date(schedule.start.getTime()+duration).toISOString(),timeZone:schedule.zone};

    }

  }

  if(['Street Address','City','State','ZIP Code'].some(changed)) {

    patch.location=['Street Address','City','State','ZIP Code'].map(k=>now[k]).filter(Boolean).join(', ');

  }

  // Show the CRM appointment status after the customer name.
  const title=dcTitle_(crm,h,row);
  if(event.summary!==title) patch.summary=title;

  // Keep original partner notes and historical outcomes.

  const marker='\n\n[DC CRM MASTER]';

  const original=(event.description||'').split(marker)[0];

  const status=dcGet_(crm,h,row,'Appointment Status');

  const detail=['Lead ID: '+dcGet_(crm,h,row,'Lead ID'),

    'Name: '+[dcGet_(crm,h,row,'First Name'),dcGet_(crm,h,row,'Last Name')].filter(Boolean).join(' '),

    'Appointment Status: '+status,

    'CRM Schedule: '+now['Appointment Date']+' '+now['Start Time']+' '+now['Appointment Time Zone'],

    'Phone: '+dcGet_(crm,h,row,'Phone Number'),

    'Email: '+dcGet_(crm,h,row,'Email'),

    'Campaign: '+dcGet_(crm,h,row,'Campaign'),

    'Partner / Company: '+dcGet_(crm,h,row,'Partner / Company'),

    'Confirmation: '+dcGet_(crm,h,row,'Confirmation Status'),

    'Confirmation Instructions: '+dcGetOptional_(crm,h,row,'Confirmation Instructions'),

    'Spouse / Co-Decision Maker: '+dcGet_(crm,h,row,'Spouse / Co-Decision Maker'),

    'Utility Provider: '+dcGet_(crm,h,row,'Utility Provider'),

    'Highest Electric Bill: '+dcGet_(crm,h,row,'Highest Electric Bill'),

    'Lowest Electric Bill: '+dcGet_(crm,h,row,'Lowest Electric Bill'),

    'Credit Qualification: '+dcGet_(crm,h,row,'Credit Qualification'),

    'Approximate Credit Score: '+dcGet_(crm,h,row,'Approximate Credit Score'),

    'Roof Condition: '+dcGet_(crm,h,row,'Roof Condition'),

    'Energy Improvements: '+dcGet_(crm,h,row,'Energy Improvements'),

    'Qualification Notes: '+dcGet_(crm,h,row,'Qualification Notes'),

    'Outcome Notes: '+dcGet_(crm,h,row,'Appointment Outcome Notes'),

    'Internal Notes: '+dcGet_(crm,h,row,'Internal Notes')].join('\n');

  const description=original+marker+'\n'+detail;

  if(description!==event.description) patch.description=description;

  // Cancelled is an operational status: keep the original event for history.

  // Review cases and unmatched rows never create or delete calendar events.

  if(Object.keys(patch).length) Calendar.Events.patch(patch,calId,apiId,{sendUpdates:'none'});

  if(event.iCalUID) dcCell_(crm,h,row,'Calendar Event ID').setValue(event.iCalUID);

  dcSetOptional_(crm,h,row,'Calendar Sync Baseline',JSON.stringify(now));

  const resultStart=patch.start||event.start,resultEnd=patch.end||event.end;

  dcSetOptional_(crm,h,row,'Linked Event Start',resultStart.dateTime||resultStart.date);

  dcSetOptional_(crm,h,row,'Linked Event End',resultEnd.dateTime||resultEnd.date);

  dcSetOptional_(crm,h,row,'Calendar Sync Status','Synced '+new Date().toISOString());

  dcCell_(crm,h,row,'Last Updated').setValue(new Date());

}

// Read-only verification of one existing linked row. Creates/updates no event.

// Select that row in CRM MASTER, then run validateSelectedCalendarLink().

function validateSelectedCalendarLink() {

  const crm=dcSs_().getSheetByName(DC.crmTab),h=dcHeaders_(crm);

  const active=SpreadsheetApp.getActiveSpreadsheet().getActiveRange();

  if(!active || active.getSheet().getName()!==DC.crmTab || active.getRow()<2) throw Error('Select a CRM MASTER record first');

  const row=active.getRow(),apiId=dcGetOptional_(crm,h,row,'Calendar API Event ID');

  if(!apiId) throw Error('Select a Linked imported record with a Calendar API Event ID');

  const {event,calId}=dcLinkedApiEvent_(crm,h,row,apiId);

  Logger.log(JSON.stringify({row,calendar:calId,eventId:event.id,title:event.summary,start:event.start,end:event.end}));

  if(event.iCalUID) dcCell_(crm,h,row,'Calendar Event ID').setValue(event.iCalUID);

  dcSetOptional_(crm,h,row,'Calendar Sync Status','Link validated; edit trigger ready');

}



// Stable Calendar API IDs make a retry safe even if an event was created before

// its iCalUID could be saved to the spreadsheet. Imported rows never enter here.

function dcCreateFormEvent_(crm,h,row,calendarId,kind,title,description,location,schedule) {

  if(typeof Calendar==='undefined') throw Error('Enable Services > Google Calendar API first');

  const key=dcGet_(crm,h,row,'Form Submission Key');

  if(!key || !/:form-row:\d+$/.test(key)) throw Error('Only linked form submissions can create an event');

  const bytes=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,key+':'+kind,Utilities.Charset.UTF_8);

  const id='dc'+bytes.map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');

  const owns=event=>{

    const meta=event.extendedProperties&&event.extendedProperties.private||{};

    if(event.status==='cancelled') throw Error('Original event was deleted in Calendar; review it before retrying');

    if(meta.dcSubmissionKey!==key||meta.dcEventKind!==kind) throw Error('Calendar event ID ownership mismatch');

    if(!event.iCalUID) throw Error('Calendar returned no event UID');

    return event;

  };

  let existing;

  try {existing=Calendar.Events.get(calendarId,id);} catch(e) {

    if(!/404|not found/i.test(String(e.message||e))) throw e;

  }

  if(existing) return owns(existing);

  const resource={id,summary:title,description,location,

    start:{dateTime:schedule.start.toISOString(),timeZone:schedule.zone},

    end:{dateTime:schedule.end.toISOString(),timeZone:schedule.zone},

    extendedProperties:{private:{dcSubmissionKey:key,dcEventKind:kind}}};

  try {return owns(Calendar.Events.insert(resource,calendarId,{sendUpdates:'none'}));}

  catch(e) {

    // On a timeout or conflict, recover the same deterministic event only.

    try {return owns(Calendar.Events.get(calendarId,id));} catch(recovery) {throw e;}

  }

}



function dcEnsureFormPrimary_(crm,h,row) {

  if(dcGet_(crm,h,row,'Calendar Event ID')||dcGetOptional_(crm,h,row,'Calendar API Event ID')) return;

  const key=dcGet_(crm,h,row,'Form Submission Key');

  if(!key||!/:form-row:\d+$/.test(key)) return;

  const schedule=dcSchedule_(crm,h,row);

  const location=['Street Address','City','State','ZIP Code'].map(k=>dcGet_(crm,h,row,k)).filter(Boolean).join(', ');

  const event=dcCreateFormEvent_(crm,h,row,DC.calendarId,'primary',dcTitle_(crm,h,row),dcCrmDescription_(crm,h,row,schedule),location,schedule);

  dcCell_(crm,h,row,'Calendar Event ID').setValue(event.iCalUID);

  SpreadsheetApp.flush();

}



// Bounded retries: at most 10 queued appointment rows per five-minute run.

function retryPendingCalendarSync() {
  if(dcInteractiveSaveRecent_())return;
  const sh=dashSheet_(),h=dcHeaders_(sh),g=dashRows_();
  const queued=g.records.filter(r=>['Pending','Error'].includes(dashSyncStatus_(dashCell_(r.values,g.idx,'Calendar Sync Status'))));
  const props=PropertiesService.getScriptProperties(),cursor=Number(props.getProperty('DC_RETRY_CURSOR')||0);
  const ordered=queued.filter(r=>r.row>cursor).concat(queued.filter(r=>r.row<=cursor)),started=Date.now();
  for(const record of ordered.slice(0,5)){
    if(dcInteractiveSaveRecent_()||Date.now()-started>90000)break;
    const lock=LockService.getScriptLock();if(!lock.tryLock(100))break;
    try{
      const fresh=sh.getRange(record.row,1,1,h.length).getDisplayValues()[0];
      const current={row:record.row,values:fresh};
      // A moved or already-synchronized row is never replayed from the old queue snapshot.
      if(dashKey_(current,g.idx)!==dashKey_(record,g.idx))continue;
      if(!['Pending','Error'].includes(dashSyncStatus_(dashCell_(fresh,g.idx,'Calendar Sync Status'))))continue;
      dashSync_(sh,h,record.row);SpreadsheetApp.flush();
      props.setProperty('DC_RETRY_CURSOR',String(record.row));
    }finally{lock.releaseLock();}
  }
}

/** Run once to add CRM status to EXISTING linked appointment titles.
 * Title-only updates: no appointment creation, schedule changes, or guest notifications.
 * Large lists continue automatically in batches. Other triggers stay in place.
 */
function refreshAppointmentTitles() {
  if(typeof Calendar==='undefined')throw Error('Enable Services > Google Calendar API first');
  const lock=LockService.getScriptLock();lock.waitLock(30000);
  try{
    dcClearTitleRefreshTriggers_();
    PropertiesService.getScriptProperties().setProperty('DC_TITLE_REFRESH_PAUSED','0');
    PropertiesService.getScriptProperties().setProperty('DC_TITLE_REFRESH',JSON.stringify({nextRow:2,updated:0,unchanged:0,skipped:0,errors:0,done:false}));
  }finally{lock.releaseLock();}
  dcRefreshAppointmentTitleBatch();
  return appointmentTitleRefreshStatus();
}

function dcClearTitleRefreshTriggers_(){
  ScriptApp.getProjectTriggers().filter(t=>t.getHandlerFunction()==='dcRefreshAppointmentTitleBatch').forEach(t=>ScriptApp.deleteTrigger(t));
}

function dcRefreshOneAppointmentTitle_(crm,h,row){
  if(dcGetOptional_(crm,h,row,'Record Type').toLowerCase()!=='appointment'||!dcGetOptional_(crm,h,row,'Lead ID'))return 'skipped';
  const apiId=dcGetOptional_(crm,h,row,'Calendar API Event ID'),legacyId=dcGetOptional_(crm,h,row,'Calendar Event ID');
  if(!apiId&&!legacyId)return 'skipped';
  let event,calId;
  if(apiId){({event,calId}=dcLinkedApiEvent_(crm,h,row,apiId));}
  else{
    calId=dcGetOptional_(crm,h,row,'Calendar ID')||DC.calendarId;
    if(!DC_ALLOWED_CALENDARS.includes(calId))throw Error('Calendar ID outside selected calendars');
    const result=Calendar.Events.list(calId,{iCalUID:legacyId,showDeleted:false,maxResults:10});
    const matches=(result.items||[]).filter(e=>e.status!=='cancelled');
    if(matches.length!==1||matches[0].recurrence)throw Error('Calendar event link requires review');
    event=matches[0];
    const clean=x=>String(x||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
    const name=clean(dcGet_(crm,h,row,'First Name')+' '+dcGet_(crm,h,row,'Last Name'));
    const phone=dcGet_(crm,h,row,'Phone Number').replace(/\D/g,'').slice(-10);
    if(!(name&&clean(event.summary).includes(name))&&!(phone.length===10&&String(event.description||'').replace(/\D/g,'').includes(phone)))throw Error('Calendar event identity differs from CRM');
  }
  const title=dcTitle_(crm,h,row);if(event.summary===title)return 'unchanged';
  Calendar.Events.patch({summary:title},calId,event.id||apiId,{sendUpdates:'none'});return 'updated';
}

function dcRefreshAppointmentTitleBatch(){
  dcClearTitleRefreshTriggers_();
  const props=PropertiesService.getScriptProperties();
  if(props.getProperty('DC_TITLE_REFRESH_PAUSED')==='1')return;
  const raw=props.getProperty('DC_TITLE_REFRESH');if(!raw)return;
  const progress=JSON.parse(raw);if(progress.done)return;
  const crm=dcSs_().getSheetByName(DC.crmTab);if(!crm)throw Error('CRM MASTER tab missing');
  const h=dcHeaders_(crm),last=crm.getLastRow(),started=Date.now();let examined=0;
  while(progress.nextRow<=last&&examined<20&&Date.now()-started<60000){
    if(props.getProperty('DC_TITLE_REFRESH_PAUSED')==='1'||dcInteractiveSaveRecent_())break;
    const lock=LockService.getScriptLock();if(!lock.tryLock(100))break;
    const row=progress.nextRow;
    try{
      const outcome=dcWithRowSnapshot_(crm,h,row,()=>dcRefreshOneAppointmentTitle_(crm,h,row));progress[outcome]++;
    }catch(e){progress.errors++;progress.lastError='CRM row '+row+': '+e.message;Logger.log(progress.lastError);}
    finally{lock.releaseLock();}
    progress.nextRow++;examined++;
  }
  progress.done=progress.nextRow>last;
  props.setProperty('DC_TITLE_REFRESH',JSON.stringify(progress));
  if(!progress.done&&props.getProperty('DC_TITLE_REFRESH_PAUSED')!=='1')ScriptApp.newTrigger('dcRefreshAppointmentTitleBatch').timeBased().after(60000).create();
  Logger.log(JSON.stringify(progress));
}

/** Run once after installing this performance update.
 * Pauses the bulk title backfill. Individual appointment status/title sync stays enabled.
 */
function enableResponsiveCrm(){
  const props=PropertiesService.getScriptProperties();
  props.setProperty('DC_TITLE_REFRESH_PAUSED','1');
  dcClearTitleRefreshTriggers_();
  Logger.log('Bulk title backfill paused. Interactive appointment updates and calendar retry stay enabled.');
  return {titleBackfillPaused:true};
}

function appointmentTitleRefreshStatus(){
  const raw=PropertiesService.getScriptProperties().getProperty('DC_TITLE_REFRESH');
  const status=raw?JSON.parse(raw):{started:false};Logger.log(JSON.stringify(status));return status;
}