#!/usr/bin/env bash
set -euo pipefail
platform_root="$(cd "$(dirname "$0")/.." && pwd)"
runtime_dir="${TMPDIR:-/tmp}/dc-hub-upgrade-runtime"
mkdir -p "$runtime_dir"
cat > "$runtime_dir/apache.conf" <<'CONF'
<Directory /var/www/html>
Options -Indexes +FollowSymLinks
AllowOverride All
Require all granted
</Directory>
ServerName localhost
CONF
cat /etc/ssl/certs/ca-certificates.crt > "$runtime_dir/ca-bundle.pem"
if [ -n "${CODEX_PROXY_CERT:-}" ] && [ -f "$CODEX_PROXY_CERT" ]; then cat "$CODEX_PROXY_CERT" >> "$runtime_dir/ca-bundle.pem"; fi
cat > "$runtime_dir/php.ini" <<'INI'
curl.cainfo=/run/hub-ca.pem
openssl.cafile=/run/hub-ca.pem
upload_max_filesize=50M
post_max_size=55M
INI
env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH docker --host=unix:///var/run/docker.sock info >/dev/null
if docker container inspect dc-hub-upgrade-qa >/dev/null 2>&1; then docker stop dc-hub-upgrade-qa >/dev/null; docker rm dc-hub-upgrade-qa >/dev/null; fi
hub_config_args=()
if [ -n "${HUB_CONFIG_FILE:-}" ]; then
  [ -f "$HUB_CONFIG_FILE" ] || { echo 'HUB_CONFIG_FILE must name an existing private file.' >&2; exit 1; }
  hub_config_args=(-e HUB_CONFIG_FILE=/run/hub-config.php -v "$HUB_CONFIG_FILE:/run/hub-config.php:ro")
fi
docker run -d --name dc-hub-upgrade-qa "${hub_config_args[@]}" -p 127.0.0.1:8081:80 \
 -e "APACHE_RUN_USER=#$(id -u)" -e "APACHE_RUN_GROUP=#$(id -g)" \
 -v "$platform_root/hostinger/dc-hub:/var/www/html/dc-hub" \
 -v "$runtime_dir/apache.conf:/etc/apache2/conf-enabled/dc-hub.conf:ro" \
 -v "$runtime_dir/ca-bundle.pem:/run/hub-ca.pem:ro" \
 -v "$runtime_dir/php.ini:/usr/local/etc/php/conf.d/hub.ini:ro" \
 php@sha256:11093ce0630a495ce9436647d2939b5ca44b411d2a04917afe8b2d051ae2d2ed \
 sh -c 'a2enmod rewrite >/dev/null && apache2-foreground'
python3 - <<'PY'
import time,urllib.request
for i in range(30):
 try:
  response=urllib.request.urlopen('http://127.0.0.1:8081/dc-hub/login.php',timeout=3)
  assert response.status==200
  print('Local PHP login response verified. Live Google setup remains separate.')
  break
 except (OSError,AssertionError):
  if i==29:raise
  time.sleep(1)
PY
