# Hostinger resource-library fix

The empty resource page and the “Read live market notes” dropdown match the older Google-backed browser component. The corrected source already has local content; mixed/cached assets can keep the older component visible after an upload. This patch fixes that dependency directly rather than requiring Sheets resource rows.

## Result

- PHP renders the current local resource catalog into the authenticated Resources page. All eight current scripts, the eight uploaded market references and retained references are available directly from Hostinger.
- The resource page no longer waits for a Google Sheets resource list. A failed identity refresh cannot erase the already-authorized local cards, and the server-rendered list also works with JavaScript disabled.
- JavaScript/CSS and module dependencies have content-hashed filenames. Updated page URLs request the corrected files rather than reusing an older operations or market-notes module.
- The Dialing Station uses the uploaded local market JSON. The older Google Docs dropdown is absent from the current station module.
- Existing authentication, resource permission checks and private-data gates remain enforced. The new pure library helper is denied as a direct HTTP route. Names/descriptions are escaped; external/traversal catalog paths are rejected.

This is a library/cache fix. The appointment Google Form itself is unchanged in this patch; replacing it with a native Hostinger form is pending the user's submission-storage choice. Existing customer data, Sheets/Calendar integration, login, campaigns, source Forms and production private configuration are not migrated by this patch.

## Upload the patch

1. Back up the live Hub directory and private config.
2. Open the `dc-hub` directory inside `DC-Hub-Hostinger-Library-Fix.zip`. Upload its **contents into the existing live Hub directory**—the same directory that already contains the live index.html, auth/, assets/ and resources/. Overwrite matching patch files. Do not create a second nested dc-hub/dc-hub directory.
3. The patch includes the actual script/market files and local catalog, not only page code. It does not overwrite campaigns.json, private config, uploads or manager-edited media. Keep existing local data/content backups before replacing scripts/market notes with the user's current uploads.
4. Purge the Hostinger/LiteSpeed site cache once, then reload with Ctrl+Shift+R. Opening `resources/index.html?refresh=hostinger-library` also requests a fresh page URL.
5. Confirm that Resources contains Solar Value Builders, Battery Backup, Net Metering, Fiber, Roofing, Warm Reschedule, Solar One-Liners, Script Logic and New Jersey notes. Open each local link. The station's market selector should show the geographic market labels, without a “Read live market notes” dropdown.
6. The current build hash is in assets/data/build.json and the page's dc-hub-release meta tag. Authenticated HTML responses also send X-DC-Hub-Release. These are diagnostic version markers, not credentials.

No new Apps Script deployment, spreadsheet resource setup or production migration is required for this library patch. Existing authentication must already be configured and the signed-in user must have the resources permission.

## Local validation

- 8 PHP library checks: actual catalog, eight current scripts, New Jersey, local-only links, existing file paths, escaping, malformed catalog handling and traversal rejection.
- 20 actual local Apache/PHP checks, including server resource rendering, direct helper denial, auth/role/CSRF/private-cache gates and blocked CRM write operations.
- 7 browser fallback/cache checks: no-JavaScript resources, unavailable identity refresh, versioned entry/helper URLs, stale empty catalog isolation, no Workspace resource calls and no stale-module errors.
- 31 uploaded-content browser checks still pass with versioned assets; 73 content-fidelity checks and 11 market schema checks remain applicable. No live Hostinger or OAuth verification has been performed without the website URL/access.

For future source edits, regenerate shell pages as needed, then run `python3 tools/build_assets.py` before packaging. It versions dependencies, updates page asset references and preserves canonical editable source. It removes only obsolete generated files recorded in the prior build manifest whose bytes still match their recorded digest; modified/unrecognized files are not removed. Run `python3 tools/verify.py` after building.
