"""Static source checks and preservation manifest, without printing configuration."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import hashlib,json,subprocess,zipfile,re
ROOT=Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
class Links(HTMLParser):
 def __init__(self):super().__init__();self.paths=[]
 def handle_starttag(self,tag,attrs):
  for k,v in attrs:
   if k in ['href','src'] and v:self.paths.append(v)
missing=[];js=0;jsons=0
for p in ROOT.rglob('*'):
 if any(x in p.parts for x in ['.git','backups','__pycache__']) or not p.is_file():continue
 if p.suffix=='.json':json.loads(p.read_text());jsons+=1
 if p.suffix in ['.js','.gs','.cjs']:
  subprocess.run(['node','--check',str(p)] if p.suffix!='.gs' else ['node','--check'],input=p.read_text() if p.suffix=='.gs' else None,text=True,check=True,stdout=subprocess.DEVNULL);js+=1
 if p.suffix=='.html':
  h=Links();h.feed(p.read_text())
  for u in h.paths:
   parsed=urlsplit(u)
   if parsed.scheme or parsed.netloc or not parsed.path:continue
   target=(p.parent/unquote(parsed.path)).resolve()
   if not target.exists():missing.append({'file':str(p.relative_to(ROOT)),'target':u})
  for script in re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>',p.read_text(),re.S):
   if script.strip():subprocess.run(['node','--check'],input=script,text=True,check=True,stdout=subprocess.DEVNULL);js+=1
campaigns=json.loads((ROOT/'assets/data/campaigns.json').read_text())
for c in campaigns:
 for folder,key in [('scripts','script'),('market-notes','marketNotes')]:
  if not (ROOT/'assets'/folder/c[key]).is_file():missing.append({'campaign':c['id'],'target':c[key]})
for r in json.loads((ROOT/'assets/data/resources.json').read_text()):
 if r.get('script') and not (ROOT/'assets/scripts'/r['script']).is_file():missing.append({'resource':r['id'],'target':r['script']})
archive=next(Path('/workspace/attachments').glob('bd5b807f*/*.zip')) if Path('/workspace/attachments').exists() else None
if archive:
 entries=[]
 with zipfile.ZipFile(archive) as z:
  baseline=set()
  for name in z.namelist():
   if name.endswith('/'):continue
   baseline.add(name);target=ROOT/name
   status='preserved' if target.exists() and sha(target.read_bytes())==sha(z.read(name)) else 'modified' if target.exists() else 'missing'
   entries.append({'file':name,'status':status,'baselineSha256':sha(z.read(name)),**({'finalSha256':sha(target.read_bytes())} if target.exists() else {})})
  for p in ROOT.rglob('*'):
   if p.is_file() and not any(x in p.parts for x in ['.git','__pycache__']) and str(p.relative_to(ROOT)) not in baseline:entries.append({'file':str(p.relative_to(ROOT)),'status':'added'})
 (ROOT/'docs/CHANGELOG.json').write_text(json.dumps(entries,indent=2)+'\n')
 assert not any(x['status']=='missing' for x in entries), 'Baseline file lost'
report={'jsonFiles':jsons,'javascriptAndAppsScriptChecks':js,'missingReferences':missing,'campaignMappings':len(campaigns)}
(ROOT/'docs/STATIC-QA.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));assert not missing
