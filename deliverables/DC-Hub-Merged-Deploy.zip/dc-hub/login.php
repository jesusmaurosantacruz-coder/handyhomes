<?php
declare(strict_types=1);
require_once __DIR__ . '/auth/session.php';
header('Cache-Control: no-store, max-age=0');
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('X-Robots-Tag: noindex, nofollow, noarchive');
dc_begin_session();
if (dc_is_authenticated()) {
    header('Location: ./', true, 303);
    exit;
}

$error = false;
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    $submittedToken = (string)($_POST['csrf'] ?? '');
    $lockedUntil = (int)($_SESSION['dc_locked_until'] ?? 0);

    if (strlen($email) <= 254 && strlen($password) <= 512
        && dc_csrf_valid($submittedToken) && time() >= $lockedUntil) {
        $config = dc_config();
        $user = $config['users'][$email] ?? null;
        // Always check the hash, even on an unknown email.
        $passwordCorrect = password_verify($password, $config['password_hash']);
        if ($user !== null && $passwordCorrect) {
            session_regenerate_id(true);
            unset($_SESSION['dc_editor_unlocked_at'],$_SESSION['dc_csrf']);
            $_SESSION['dc_user_id'] = $user['id'];
            $_SESSION['dc_user_name'] = $user['name'];
            $_SESSION['dc_user_email'] = $email;
            $_SESSION['dc_last_active'] = time();
            unset($_SESSION['dc_failed'], $_SESSION['dc_locked_until']);
            header('Location: ./', true, 303);
            exit;
        }
        $_SESSION['dc_failed'] = (int)($_SESSION['dc_failed'] ?? 0) + 1;
        if ($_SESSION['dc_failed'] >= 7) {
            $_SESSION['dc_locked_until'] = time() + 600;
            $_SESSION['dc_failed'] = 0;
        }
    }
    $error = true;
}
function esc(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#030a0a">
  <meta name="robots" content="noindex,nofollow">
  <title>Agent Access | Digital Citizen</title>
  <link rel="icon" type="image/png" href="assets/favicon.png">
  <link rel="stylesheet" href="assets/css/login.css?v=20261023a">
</head>
<body>
  <div class="background-glow" aria-hidden="true"></div>
  <div class="noise" aria-hidden="true"></div>
  <div class="grid-haze" aria-hidden="true"></div>
  <div class="screen-shell">
    <header class="masthead">
      <a class="brand" href="login.php" aria-label="Digital Citizen Agent Access">
        <img src="assets/dc-logo.png" alt="">
        <span><strong>DIGITAL CITIZEN</strong><small>WORKFORCE NETWORK</small></span>
      </a>
      <div class="signal-label"><span class="signal-led"></span> NETWORK STATUS <strong>ACTIVE</strong></div>
    </header>
    <main class="stage">
      <div class="visual" aria-hidden="true">
        <div class="visual-overline">GLOBAL CONNECTION PROTOCOL <span>DC.001</span></div>
        <div class="orb-halo"></div>
        <canvas id="globe"></canvas>
        <div class="orbit-copy orbit-copy-top"><span class="pulse"></span> CONNECTION ESTABLISHED</div>
        <div class="orbit-copy orbit-copy-bottom">REAL PEOPLE <i>/</i> DIGITAL OPPORTUNITIES</div>
      </div>
      <section class="entry">
        <div class="entry-glow" aria-hidden="true"></div>
        <div class="entry-inner">
          <div class="entry-kicker"><span class="short-line"></span> PRIVATE WORKSPACE</div>
          <h1>Access the<br><em>network.</em></h1>
          <p class="intro">Real People. Digital Opportunities.</p>
          <form method="post" action="login.php" autocomplete="on">
            <input type="hidden" name="csrf" value="<?= esc(dc_token()) ?>">
            <div class="field"><label for="email">AGENT EMAIL</label><input id="email" name="email" type="text" inputmode="email" autocapitalize="none" spellcheck="false" autocomplete="username" value="<?= esc($email) ?>" placeholder="Enter your registered email" maxlength="254" required autofocus></div>
            <div class="field"><label for="password">PASSWORD</label><div class="password-wrap"><input id="password" name="password" type="password" autocomplete="current-password" placeholder="Enter your password" required><button class="eye" type="button" id="toggle-password" aria-label="Show password" aria-pressed="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg></button></div></div>
            <?php if ($error): ?><div class="error" role="alert">Access denied. Check your email and password, or try again later.</div><?php endif; ?>
            <button class="enter" type="submit"><span>ENTER WORKSPACE</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 12h15m-6-6 6 6-6 6"/></svg></button>
          </form>
          <div class="entry-foot"><span class="lock-icon" aria-hidden="true">◈</span> RESTRICTED TO AUTHORIZED DIGITAL CITIZEN PERSONNEL</div>
        </div>
      </section>
    </main>
    <footer class="footer"><span>© <?= date('Y') ?> DIGITAL CITIZEN</span><span><span class="mini-led"></span> GLOBAL NETWORK / ONLINE</span><span>ENCRYPTED SESSION <span class="footer-dash">/</span> VERSION 01</span></footer>
  </div>
  <script src="assets/js/login-globe.js?v=20261023a" defer></script>
</body>
</html>
