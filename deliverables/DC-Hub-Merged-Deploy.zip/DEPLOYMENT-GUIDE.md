# Hostinger deployment and rollback

## Before uploading

1. Back up the complete live `public_html/dc-hub` directory **and** its production `auth/config.php`, any `auth/typing-config.php`, uploads, manager-edited content, and hosting configuration. Store a downloadable recovery copy outside the public web root. Do not upload a ZIP containing credentials to a public URL.
2. Use a staging subdirectory first, e.g. `public_html/dc-hub-staging`. Extract the deployable ZIP so that `index.html`, `login.php`, `.htaccess`, `auth/`, `leaderboard/`, etc. sit directly inside that directory. Avoid `dc-hub/dc-hub/` nesting. The ZIP contains one `dc-hub/` root. Rename that extracted folder for staging as appropriate.
3. The full release includes the original leaderboard, calendar, authentication and resources. Do not deploy the 27-file Release 4 ZIP alone: it is a partial candidate, despite its old README describing it as complete. `/dc-hub/leaderboard/index.html` must physically exist and route through the auth gate.
4. Copy your existing production `auth/config.php` into staging without editing its users, hashes or idle policy. The package intentionally excludes that credential file. For a brand-new installation, configure `auth/config.example.php` securely; it contains no users or default passwords. Do not use the local QA fixture credentials on a public host.
5. Reconcile manager-customized JSON/scripts with the supplied merge before promotion. The file manifest compares the supplied baseline, not later live changes. Keep `leaderboard/assets/js/config.js` pointed at your approved CRM endpoint. Do not replace any live CRM API, PHP proxy or Apps Script with the reference scripts automatically.

## Hosting requirements

- PHP 8.2+ (validated locally with 8.3); extensions DOM/libxml, JSON, session, fileinfo and cURL. Apache-compatible rewrites/`.htaccess` and `AllowOverride All`; Hostinger LiteSpeed must honor the same rules.
- HTTPS on the deployed site. Preserve platform/server CA trust and TLS validation for outbound Google requests.
- PHP worker needs read access to application files and credential config, and write access to `assets/data/`, `assets/scripts/`, `assets/market-notes/`, `admin/backups/`, and `training/media/` for authorized edits/uploads. Usually directories 0750/0755 and files 0640/0644 with the hosting PHP user as owner/group; confirm against your account. Never solve permissions with 0777.
- Uploads: application limit 50 MiB; set `upload_max_filesize=50M`, `post_max_size=55M` or higher in Hostinger's PHP settings, and sufficient execution time/storage. Proxy/web-server limits can be lower. Large libraries require storage/bandwidth planning. Begin with MP3 and broadly supported H.264/AAC MP4. Resume position is device-local.
- `training/media/.htaccess` denies direct access. Only authenticated `training/stream.php?id=...` can stream visible manifest entries, with byte ranges. Do not remove this rule. Hidden/removed items become inaccessible through the streaming endpoint; files remain on disk for deliberate offline cleanup.
- `source-documents/`, `integrations/`, `docs/`, `tests/`, `tools/` are source-package materials and excluded from the runtime ZIP. Root rules deny them if accidentally uploaded. Do not put credentials or deliverable archives in public_html.

## Staging acceptance

Test anonymous page redirects, JSON/script/notes 401 responses, manager API 403 responses, and direct `auth/config.php` / `training/media/...` denial. If `.htaccess` is ignored, stop deployment. Missing rewrite support now denies requests rather than serving protected HTML directly.

Log in with real approved accounts; confirm agent versus manager behavior, one-hour editor unlock, logout, and idle expiry. Visit Home, Campaigns, Calendar, Leaderboard, Resources, Dialing Station and all Training pages. Check Script Logic, One-Liners, roll calls, contacts and Arena meetings. Select every enabled campaign; check form URLs, white reader, original emphasis, focus mode, scrolling and Maps. The original hidden Pennsylvania Roofing campaign stays hidden; a general Roofing campaign is added and visible.

Test the popup and new-tab fallback for both supplied Google Forms. With management authorization, use a clearly identified test submission and verify the resulting CRM/calendar behavior in the real service. Local QA did **not** submit forms or verify production appointments. Verify the CRM endpoint deployment and access rights. An honest unavailable state is expected if a service is not configured/reachable.

Configure typing per INTEGRATIONS.md, then submit a real approved test and confirm its identifier in the sheet, retry once to check deduplication, and check manager results. Upload an approved test MP3/MP4, configure its manifest entry, confirm playback/seek and anonymous denial, then remove/hide the test item. No actual recordings are bundled.

## Promotion and rollback

Promote the tested staging tree with a controlled directory swap or hosting deployment, preserving real credentials, approved content and media. Keep the previous directory offline outside the public root. Clear hosting/browser caches as needed (updated asset versions are supplied). Re-run access checks on the actual `/dc-hub/` URL.

On regression, restore the previous full tree and its configuration/content/media from backup. Do not delete or reset Google Sheets/CRM/calendar data. Hub content edits make backups under private `admin/backups/`; restoring a content file is separate from rolling back Google data. Keep the deployment archive hash with the change record.
