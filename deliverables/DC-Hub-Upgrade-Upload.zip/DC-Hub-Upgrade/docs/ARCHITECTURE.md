# Architecture and logic decisions

## Foundation and provenance

The repository initially contained delivery archives only. `hostinger/dc-hub` preserves the supplied PHP/Apache foundation, assets, campaign scripts, Dialing Station, training library, media protections and rich-text editor. The later `_dc-hub (3).zip` supplied by the user takes precedence for matching runtime files. Production credential files from those uploads are excluded.

Eagle Eyes appointment functionality is integrated into Hub rather than deployed as a second application. The supplied operations API referred to missing calendar helpers and used a caller-supplied `manager` role; the unified API replaces that trust model. The intake script's campaign-specific calendar properties are deliberately not reused for routing. The two supplied leaderboard texts were byte-identical and are consolidated. The latest typing package supplies the three exact passages and selections; the previous 25-lesson curriculum is replaced.

## Modules

The website uses existing PHP 8.2+ / Apache and browser JavaScript, with no application database, Node build, CDN framework or paid dependency. Shared design tokens live in `assets/css/operations.css`. `operations.js` renders dashboard, appointments, protected calendar, analytics, standings, resources, market notes and administration. Existing Dialing Station and media library remain dedicated tools. Workspace selectors in the station allow Google Docs scripts and market notes while preserving local campaign content.

Apps Script files separate configuration/storage, authorization, API dispatch, appointments/analytics, calendar synchronization, intake/forms, Roam, typing, resources/admin, migration and diagnostics. There is one `doPost`, one form-submit handler, and one edit handler.

## Identity and authorization

Google OAuth authorization-code flow uses state, PKCE and nonce. Google validates the ID-token signature through its HTTPS token-info service; PHP verifies audience, issuer, expiry, verified email and nonce. The user's Google subject and email are stored in a server-side session, never supplied by an appointment request. Existing shared-password login is replaced.

PHP signs each Apps Script envelope with HMAC-SHA256, a random nonce and a short timestamp. Apps Script rejects tampering, replay and expired requests, then reads the user's active status, role and permissions from the workbook. Every protected PHP request rechecks membership; disabling a user denies subsequent requests. Existing `GOOGLE_SUB` bindings, where present, must match. No API trusts a role or email supplied by browser JSON.

Only Intern, Agent, Team Lead and Admin are internal roles. Affiliate is a submission classification. Recognized former/inactive users retain internal historical attribution. Ambiguous historical identities are marked Review instead of being silently reassigned.

Agents receive full permitted customer data for their own appointments. Team Leads receive it for their current team and their own records. Admins receive it across the organization. Other-setter shared calendar responses contain exactly date, time, campaign and setter, with no customer fields, record ID or restricted-details placeholder. Search excludes unauthorized customer records. Intern appointment access is disabled by default. Backend checks apply even if UI controls are manipulated.

## Teams and history

`CRM_TEAMS` initially contains Team 1–3. `USERS.Team` controls current membership. `Current Team` controls team-lead access and is refreshed after admin changes, user edits and scheduled form synchronization. `Original Team` is retained for historical reporting. Moving or suspending users never deletes production or changes original attribution. Blank team assignments confer no team-lead access.

The migration does not invent historical team membership. Existing rows with no Original Team remain unassigned until reviewed. New appointments snapshot the matched user's team. Existing setter identities and calendar references are preserved.

## Workbook compatibility and migration

Canonical equivalents are resolved through `HUB.aliases`. Existing names, header order, original response tabs, formulas and historical rows are preserved. If two equivalent tabs exist, migration stops rather than guessing which one is authoritative. Missing fields are appended, permissions seeded only when absent, and new configuration tabs added only when no equivalent exists. Existing user/team assignments are not guessed.

Migration first requires a sandbox copy, makes a retained backup, records its ID, assigns IDs only to rows missing them, and produces an audit report in Drive. Validation checks row preservation, original configuration/response cells, unique IDs and existing calendar references. It does not exercise live integrations. Repeated migration does not duplicate data, tabs or calendar events. Original data and uploaded workbook contents are not embedded in the deployment package.

## Calendar logic

State and campaign never select destinations. An explicitly recorded Calendar ID is used; otherwise the explicitly configured setter calendar is the destination for new intake. Missing destination or timezone is reported for review, not guessed. Missing date/time, unsupported linked-reference formats and missing events also produce visible synchronization errors.

Existing linked events are resolved and patched in place; missing existing events are not recreated. Event copies use the IDs in `Related Calendar Events` and `Agent Calendar Event ID`. All-day dates and timed event durations are preserved. New event IDs are deterministic per source row/calendar, making retries safe after a lost response. `HUB_CREATE_SETTER_COPY=YES` enables a separate setter copy for newly imported records whose explicitly selected primary calendar differs from the setter calendar. Existing records are not given new copies automatically.

Optional setter guests require `HUB_ADD_SETTER_GUESTS=YES` and are added only to newly created setter-side events. New events contain campaign, setter and internal appointment ID, not customer details. Hub never embeds a public Google Calendar. Existing calendar sharing must be reviewed separately before go-live; backend redaction cannot fix an already public calendar.

Appointment writes use revision plus full-record fingerprint checks and a lock. Audit entries precede the write. CRM saving and Calendar synchronization are reported separately, with a retry action for failures. No revenue is inferred from appointment counts. Qualified Sit is recorded only when that disposition exists.

## Notifications and forms

One intake handler normalizes all three source forms. It preserves original responses and campaign-specific fields. The source sheet ID and response row form its idempotency key. Existing response rows are not reimported by migration.

Roam credentials remain in Script Properties. Notifications omit customer PII. A persisted sending marker prevents automatic duplicate sends after ambiguous HTTP outcomes. Such cases remain Review until an operator checks the channel; this favors avoiding duplicates over blindly retrying an uncertain send. No independent Roam trigger is installed.

Form synchronization uses exact configured form IDs and setter dropdown item IDs. Only active internal representatives are listed; an optional explicitly configured affiliate choice remains available. It never changes unrelated questions or historical responses. An edit trigger, explicit admin action and hourly synchronization cover manual and API-driven roster changes.

## Typing

Exactly three durations (60/90/120 seconds) and three supplied passages (Battery Backup, Script Logic, Net Metering). Each starts at its beginning. User name/email come from the Google session. A server-issued attempt binds identity, test and duration; results are deduplicated by attempt ID. The timer uses `performance.now()`, stops input at the configured deadline and measures actual elapsed time.

Gross WPM = final entered characters / 5 / elapsed minutes. Net WPM = max(0, (final entered characters / 5 − uncorrected mismatches) / elapsed minutes). Accuracy = correct insertion attempts / all insertion attempts. A corrected mistake remains in insertion-error statistics; backspace itself is not an error. The server recomputes WPM and final mismatches from submitted text, rejects early incomplete attempts and implausible speeds, and derives identity independently. Client-observed keystroke history is not a tamperproof proctoring system. Passing accuracy is 90%.

`Typing Test` stores results. The website's dedicated leaderboard reads those records. Existing `Typing Leaderboard` sheet formulas are preserved rather than overwritten; its layout may need separate live verification.

## Performance and content

Dashboard and appointment responses contain bounded date-window results. Metadata columns are projected in batch via the Sheets advanced service; only authorized selected rows are expanded for details. The client never downloads the full historical CRM. Configuration is reused within each execution, while current authorization is checked per request. All-time reporting aggregates narrow metadata on the server.

Google Docs HTML is exported with owner authorization and sanitized in PHP, preserving safe headings, tables, emphasis, class-derived text styles, HTTPS links and Google-hosted images. No private credential is sent to the browser. Sheets resource URLs are HTTPS-only and role-filtered. Existing local script/media editing remains Admin-only; ordinary links, market documents, announcements and goals are maintained in the workbook.
