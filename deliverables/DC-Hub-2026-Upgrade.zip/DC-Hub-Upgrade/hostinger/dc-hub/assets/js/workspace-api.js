/* Cache only inside this JS realm: never disk, localStorage, or another account. */
export function workspaceAPI(root,csrf){const cache=new Map();const read=new Set(['bootstrap','appointments','detail','analytics','resources','typingLeaderboard']);
 return async function api(action,params={}){const key=JSON.stringify([action,params]),now=Date.now(),hit=cache.get(key);if(read.has(action)&&hit&&hit.until>now)return hit.promise;
 const promise=fetch(root+'api/hub.php',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({action,params})}).then(async r=>{const d=await r.json();if(!r.ok||!d.ok)throw Error(d.error||'Workspace request failed');return d.data;}).catch(e=>{cache.delete(key);throw e;});
 if(read.has(action))cache.set(key,{promise,until:now+15000});else cache.clear();return promise;};
}
