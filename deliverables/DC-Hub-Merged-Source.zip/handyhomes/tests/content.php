<?php
require_once __DIR__.'/../auth/content.php';
$count=0;
foreach(glob(__DIR__.'/../assets/scripts/*.html') as $file){
 $raw=file_get_contents($file);$safe=dc_clean_html($raw);
 // Compare exact decoded document text; DOM serializing whitespace/entities must not lose copy.
 $text=static function($html){$d=new DOMDocument();@$d->loadHTML('<?xml encoding="UTF-8"><html><body>'.$html.'</body></html>',LIBXML_NONET);return $d->getElementsByTagName('body')->item(0)->textContent;};
 if($text($raw)!==$text($safe))throw new RuntimeException('Text lost: '.basename($file));
 if(substr_count($raw,'background-color:')!==substr_count($safe,'background-color:'))throw new RuntimeException('Highlights lost: '.basename($file));
 $count++;
}
$tests=[
 'color:rgb(0, 0, 255);background-color:rgb(255, 255, 0)'=>'color:#0000ff;background-color:#ffff00',
 'color:rgb(999,0,0);position:fixed;behavior:url(x);background-image:url(x)'=>'',
 'text-decoration-line:underline'=>'text-decoration-line:underline',
 'font-weight:bold;font-size:13pt;line-height:1.18'=>'font-weight:bold;font-size:13pt;line-height:1.18',
];
foreach($tests as $input=>$expected)if(dc_clean_style($input)!==$expected)throw new RuntimeException('CSS allowlist mismatch');
$dirty='<p onclick="alert(1)" style="position:fixed;color:#ff0000"><a href="java&#115;cript:alert(1)">x</a><svg onload="alert(1)"></svg><script>alert(1)</script></p>';
$safe=dc_clean_html($dirty);foreach(['onclick','javascript','<svg','<script','position:'] as $bad)if(str_contains($safe,$bad))throw new RuntimeException('Unsafe content survived');
echo "$count script text/highlight roundtrips and 5 sanitizer cases passed\n";
