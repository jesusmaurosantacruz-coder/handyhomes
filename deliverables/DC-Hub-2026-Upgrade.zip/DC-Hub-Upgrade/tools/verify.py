"""Static release checks. Browser modules are checked with module parsing semantics."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
import subprocess,json
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'hostinger/dc-hub'
errors=[];modules=set()
class Links(HTMLParser):
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  for key in ['href','src']:
   value=a.get(key)
   if not value:continue
   parsed=urlsplit(value)
   if parsed.scheme or parsed.netloc or not parsed.path:continue
   target=(self.file.parent/unquote(parsed.path)).resolve()
   if not target.exists():errors.append({'file':str(self.file.relative_to(ROOT)),'missing':value})
   if tag=='script' and a.get('type')=='module':modules.add(target)
for p in SITE.rglob('*.html'):
 parser=Links();parser.file=p;parser.feed(p.read_text())
syntax=0
for p in [*ROOT.glob('apps-script/*.gs'),*SITE.rglob('*.js')]:
 cmd=['node','--check']
 if p.resolve() in modules or p.name in ['market-library.js','resource-library.js','workspace-api.js','calendar-view.js']:cmd+=['--input-type=module']
 r=subprocess.run(cmd,input=p.read_text(),text=True,capture_output=True)
 if r.returncode:errors.append({'file':str(p.relative_to(ROOT)),'error':r.stderr})
 syntax+=1
for p in ROOT.rglob('*.json'):json.loads(p.read_text())
credential_files=[str(p.relative_to(SITE)) for p in SITE.rglob('*') if p.is_file() and p.name in ['config.php','typing-config.php','dc-hub-config.php']]
if credential_files:errors.append({'credentialFiles':credential_files})
if list(SITE.rglob('*.xlsx')) or list(SITE.rglob('*.zip')):errors.append({'privateArchive':'Unexpected workbook/archive in runtime'})
passages=json.loads((SITE/'training/typing/passages.json').read_text());gas=(ROOT/'apps-script/Passages.gs').read_text();gas_json=gas[gas.index('const HUB_PASSAGES = ')+len('const HUB_PASSAGES = '):].strip().removesuffix(';')
if passages!=json.loads(gas_json):errors.append({'typing':'Website/server passages differ'})
report={'syntaxChecks':syntax,'moduleScripts':len(modules),'errors':errors,'runtimeCredentialFiles':credential_files,'typingPassagesSynchronized':True,'liveWorkspaceModified':False}
(ROOT/'tests/static-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
raise SystemExit(bool(errors))
