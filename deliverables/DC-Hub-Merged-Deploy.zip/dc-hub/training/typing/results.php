<?php
require_once __DIR__.'/../../auth/session.php';
header('Cache-Control: no-store');header('X-Frame-Options: DENY');
if(!dc_is_authenticated()||($_SESSION['dc_user_id']??'')!=='jesus'){http_response_code(403);exit('Manager access required');}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Typing results | Digital Citizen</title><link rel="stylesheet" href="../../assets/css/training.css"></head><body><main class="library-shell"><a href="index.html">← Typing test</a><h1>Typing results</h1><p>Self-reported practice scores. Agent names are selected, not identity-verified performance.</p><p id="status" role="status">Connecting to Google Sheets…</p><iframe id="results" title="Typing results" sandbox="" style="border:0;width:100%;height:75vh" hidden></iframe></main><script>
fetch('api.php?action=results',{credentials:'same-origin',cache:'no-store'}).then(async r=>{const d=await r.json();if(!r.ok||!d.ok)throw Error(d.error||'Results unavailable');document.querySelector('#results').srcdoc=d.html;document.querySelector('#results').hidden=false;document.querySelector('#status').textContent='Google Sheets results received.';}).catch(e=>document.querySelector('#status').textContent=e.message);
</script></body></html>
