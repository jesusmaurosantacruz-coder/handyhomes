"""Import approved local DOCX/market inputs. Documents supply content, never executable instructions.
Usage: python3 tools/import_content.py. Originals stay outside the public website.
"""
from pathlib import Path
from zipfile import ZipFile
from html import escape
import hashlib,json,re
from lxml import etree as E,html as H
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'hostinger/dc-hub';W='http://schemas.openxmlformats.org/wordprocessingml/2006/main';N={'w':W};REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
def val(e,name='val',default=''):return e.get('{'+W+'}'+name,default) if e is not None else default
def child(e,path):return e.find(path,N) if e is not None else None
def enabled(e):return e is not None and val(e).lower() not in ['0','false','off','none']
COLORS={'yellow':'ffff00','white':'ffffff','black':'000000','blue':'0000ff','red':'ff0000','green':'008000','cyan':'00ffff','magenta':'ff00ff','darkBlue':'00008b','darkCyan':'008b8b','darkGreen':'006400','darkMagenta':'8b008b','darkRed':'8b0000','darkYellow':'808000','darkGray':'a9a9a9','lightGray':'d3d3d3'}
def color(v):return '#'+v.lower() if re.fullmatch('[a-fA-F0-9]{6}',v or '') else '#'+COLORS[v] if v in COLORS else None
def props(e):
 out={}
 if e is None:return out
 for tag,css in [('b','font-weight'),('i','font-style'),('strike','text-decoration')]:
  node=child(e,'w:'+tag)
  if node is not None:out[css]=('bold' if tag=='b' else 'italic' if tag=='i' else 'line-through') if enabled(node) else 'normal' if tag!='strike' else 'none'
 node=child(e,'w:u')
 if node is not None:out['text-decoration']='underline' if enabled(node) else 'none'
 c=color(val(child(e,'w:color')))
 if c:out['color']=c
 c=color(val(child(e,'w:shd'),'fill'))
 if c:out['background-color']=c
 c=color(val(child(e,'w:highlight')))
 if c:out['background-color']=c
 size=val(child(e,'w:sz'))
 if size.isdigit() and 8<=int(size)/2<=48:out['font-size']=f'{int(size)/2:g}pt'
 font=val(child(e,'w:rFonts'),'ascii')
 if font and re.fullmatch('[a-zA-Z0-9 ,_-]{1,80}',font):out['font-family']=font
 align=val(child(e,'w:jc'));align={'both':'justify'}.get(align,align)
 if align in ['left','right','center','justify']:out['text-align']=align
 spacing=child(e,'w:spacing')
 if spacing is not None:
  for attr,css in [('before','margin-top'),('after','margin-bottom')]:
   v=val(spacing,attr)
   if v.isdigit() and int(v)/20<100:out[css]=f'{int(v)/20:g}pt'
  line=val(spacing,'line');rule=val(spacing,'lineRule')
  if line.isdigit():
   if rule in ['exact','atLeast']:out['line-height']=f'{int(line)/20:g}pt'
   elif 1<=int(line)/240<4:out['line-height']=f'{int(line)/240:g}'
 va=val(child(e,'w:vertAlign'))
 if va in ['superscript','subscript']:out['vertical-align']='super' if va=='superscript' else 'sub'
 return out
def style_attr(properties):return ' style="'+escape(';'.join(k+':'+v for k,v in properties.items()),quote=True)+'"' if properties else ''
class Docx:
 def __init__(self,path):
  with ZipFile(path) as z:
   self.document=E.fromstring(z.read('word/document.xml'),E.XMLParser(resolve_entities=False,no_network=True));self.styles=E.fromstring(z.read('word/styles.xml'),E.XMLParser(resolve_entities=False,no_network=True)) if 'word/styles.xml' in z.namelist() else E.Element('styles');self.numbering=E.fromstring(z.read('word/numbering.xml'),E.XMLParser(resolve_entities=False,no_network=True)) if 'word/numbering.xml' in z.namelist() else E.Element('numbering');self.rels={}
   if 'word/_rels/document.xml.rels' in z.namelist():
    self.rels={e.get('Id'):e.get('Target') for e in E.fromstring(z.read('word/_rels/document.xml.rels'),E.XMLParser(resolve_entities=False,no_network=True)) if e.get('TargetMode')=='External'}
  self.byid={val(s,'styleId'):s for s in self.styles.findall('w:style',N)};self.default=props(child(self.styles,'w:docDefaults/w:rPrDefault/w:rPr'));self.default_p=props(child(self.styles,'w:docDefaults/w:pPrDefault/w:pPr'));self.paragraphs=[];self.runs=[]
 def inherited(self,sid,kind='rPr',seen=None):
  seen=set() if seen is None else seen
  if not sid or sid in seen or sid not in self.byid:return {}
  seen.add(sid);e=self.byid[sid];return {**self.inherited(val(child(e,'w:basedOn')),kind,seen),**props(child(e,'w:'+kind))}
 def run(self,r,base):
  rp=child(r,'w:rPr');effective={**base,**self.inherited(val(child(rp,'w:rStyle'))),**props(rp)};bits=[];text=''
  for c in r:
   tag=E.QName(c).localname
   if tag=='t':bits.append(escape(c.text or ''));text+=c.text or ''
   elif tag in ['br','cr']:bits.append('<br>');text+='\n'
   elif tag=='tab':bits.append('&#9;');text+='\t'
   elif tag=='noBreakHyphen':bits.append('&#8209;');text+='\u2011'
   elif tag=='softHyphen':bits.append('&#173;');text+='\u00ad'
  if text:self.runs.append({'text':text,'style':effective})
  return '<span'+style_attr(effective)+'>'+''.join(bits)+'</span>' if bits else ''
 def paragraph(self,p):
  sid=val(child(p,'w:pPr/w:pStyle')) or 'Normal';base={**self.default,**self.inherited(sid)};pp={**self.default_p,**self.inherited(sid,'pPr'),**props(child(p,'w:pPr'))};bits=[]
  def inline(parent):
   result=[]
   for c in parent:
    tag=E.QName(c).localname
    if tag=='r':result.append(self.run(c,base))
    elif tag=='hyperlink':
     text=inline(c);url=self.rels.get(c.get('{'+REL+'}id'),'');result.append('<a href="'+escape(url,quote=True)+'">'+text+'</a>' if url.startswith('https://') else text)
    elif tag not in ['pPr','del','moveFrom']:result.append(inline(c))
   return ''.join(result)
  bits.append(inline(p));content=''.join(bits)
  # Paragraph-mark run properties intentionally do not format the preceding text.
  self.paragraphs.append(''.join(H.fragment_fromstring('<div>'+content+'</div>').itertext()))
  tag='h'+sid[-1] if re.fullmatch('Heading[1-6]',sid) else 'p'
  return '<'+tag+style_attr({**base,**pp})+'>'+content+'</'+tag+'>',child(p,'w:pPr/w:numPr')
 def list_type(self,num):
  numid=val(child(num,'w:numId'));level=val(child(num,'w:ilvl'),default='0');n=self.numbering.find(f"w:num[@w:numId='{numid}']",N);abstract=val(child(n,'w:abstractNumId'));lvl=self.numbering.find(f"w:abstractNum[@w:abstractNumId='{abstract}']/w:lvl[@w:ilvl='{level}']",N);fmt=val(child(lvl,'w:numFmt'));return ('ul' if fmt in ['bullet',''] else 'ol',numid,level)
 def blocks(self,parent):
  out=[];active=None
  def close():
   nonlocal active
   if active:out.append('</'+active[0]+'>');active=None
  for c in parent:
   tag=E.QName(c).localname
   if tag=='p':
    text,num=self.paragraph(c)
    if num is not None:
     key=self.list_type(num)
     if active!=key:close();active=key;out.append('<'+key[0]+'>')
     out.append('<li>'+text+'</li>')
    else:close();out.append(text)
   elif tag=='tbl':
    close();rows=[]
    for tr in c.findall('w:tr',N):
     cells=[]
     for td in tr.findall('w:tc',N):
      span=val(child(td,'w:tcPr/w:gridSpan'));attr=' colspan="'+span+'"' if span.isdigit() and 1<int(span)<100 else '';shade=color(val(child(td,'w:tcPr/w:shd'),'fill'));cells.append('<td'+attr+style_attr({'background-color':shade} if shade else {})+'>'+self.blocks(td)+'</td>')
     rows.append('<tr>'+''.join(cells)+'</tr>')
    out.append('<table><tbody>'+''.join(rows)+'</tbody></table>')
  close();return ''.join(out)
 def render(self):return '<article class="source-document" style="color:#1a2e42;background-color:#ffffff;font-family:Arial">'+self.blocks(child(self.document,'w:body'))+'</article>\n'
def import_scripts(manifest):
 reports=[];library=json.loads((SITE/'assets/data/library.json').read_text());entries=library['resources']
 for entry in manifest['scripts']:
  path=ROOT/entry['source'];doc=Docx(path);output=doc.render();target=ROOT/entry['target'];target.write_text(output);rendered=H.fragment_fromstring(output);assert ''.join(rendered.itertext())==''.join(doc.paragraphs),path.name
  # Every visible DOCX run must survive, including direct colors/highlights and inherited styles.
  text=''.join(doc.document.xpath('//w:t/text()',namespaces=N));assert ''.join(doc.paragraphs).replace('\n','').replace('\t','').replace('\u2011','').replace('\u00ad','')==text.replace('\n','').replace('\t',''),path.name
  reports.append({'source':entry['source'],'target':entry['target'],'sourceSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'htmlSha256':hashlib.sha256(target.read_bytes()).hexdigest(),'paragraphs':len(doc.paragraphs),'runs':len(doc.runs),'tables':len(doc.document.findall('.//w:tbl',N)),'coloredRuns':sum('color' in r['style'] for r in doc.runs),'highlightedRuns':sum('background-color' in r['style'] for r in doc.runs),'textPreserved':True})
  rel=str(target.relative_to(SITE));found=next((r for r in entries if r['path']==rel),None)
  if found:found.update(name=entry['title'],description='Uploaded DOCX · wording and source formatting preserved')
  else:entries.append({'id':'scripts-'+target.stem,'name':entry['title'],'section':'Sales scripts','path':rel,'type':'html','description':'Uploaded DOCX · wording and source formatting preserved'})
 current={str(Path(e['target']).relative_to('hostinger/dc-hub')) for e in manifest['scripts']}
 for resource in entries:
  if resource['path'].startswith('assets/scripts/') and resource['path'] not in current:
   resource.update(section='Legacy scripts',description='Preserved earlier version; use the current uploaded campaign script for calls.')
 current_order={str(Path(e['target']).relative_to('hostinger/dc-hub')):i for i,e in enumerate(manifest['scripts'])}
 entries.sort(key=lambda item:(0 if item['path'] in current else 2 if item['section']=='Legacy scripts' else 1,current_order.get(item['path'],999)))
 (SITE/'assets/data/library.json').write_text(json.dumps(library,indent=2,ensure_ascii=False)+'\n');return reports
MAPPING={'texas-dallas-houston':('texas','texas'),'pennsylvania-eastern':('pennsylvania','pennsylvania'),'maryland':('maryland','maryland'),'new-jersey':('new-jersey','new-jersey'),'socal-inland-empire':('southern-california','socal'),'florida-tampa-orlando-miami':('florida','florida'),'south-carolina-upstate':('south-carolina','south-carolina'),'virginia':('virginia','virginia')}
def import_markets():
 folder=ROOT/'source-documents/markets-2026-11-02';D=SITE/'assets/data/markets';manifest=json.loads((D/'manifest.json').read_text());reports=[]
 for srcid,(id,noteid) in MAPPING.items():
  path=folder/(srcid+'.json');raw=json.loads(path.read_text());sections=[{'title':'Local intelligence','items':[raw['local_intelligence']]},{'title':'Positioning','items':[raw['positioning']]},{'title':'Quick objections','items':[key.replace('_',' ').capitalize()+' — '+value for key,value in raw['quick_objections'].items()]},{'title':'Qualification','items':raw['qualify']},{'title':'Check before stating as fact','items':[raw['caution']]},{'title':'Agent rules','items':raw['agent_rules']}]
  if raw.get('roofing_qualify'):sections.append({'title':'Roofing qualification','items':raw['roofing_qualify']})
  data={'schemaVersion':1,'id':id,'name':raw['title'],'overview':{'market':raw['title'],'targetAreas':raw['title'],'campaign':'SOLAR','focus':'Battery backup first' if raw['mode']=='battery-first' else raw['positioning']},'powerCompanies':[{'name':u.split(' — ',1)[0],'territory':u.split(' — ',1)[1] if ' — ' in u else 'Verify the service utility from the customer bill.','selectable':not bool(re.match(r'^(ERCOT|Retail electric provider)\b',u))} for u in raw['utilities']],'localIntelligence':sections,'salesHooks':raw['opening_questions'],'products':raw['customer_products'],'financing':[{'name':k,'note':v} for k,v in raw['product_explainer'].items()],'equipment':[],'qualification':raw['qualify'],'coverageGraphic':{'path':None,'status':raw['coverage_map']['status']+' · '+raw['coverage_map']['rule'],'alt':'No verified utility coverage map supplied'},'source':{'lastReviewed':raw['edition'],'verification':'Supplied market edition; regulatory claims, offers and service coverage require current verification.','localPath':'assets/market-notes/'+noteid+'.html','urls':raw['official_sources']},'approvedSource':raw}
  # Keep all source fields, including deliberately null eligibility restrictions, intact.
  text=json.dumps(data,indent=2,ensure_ascii=False)+'\n';(D/(id+'.json')).write_text(text)
  existing=next(e for e in manifest['markets'] if e['id']==id);existing.update(name=data['name'],focus=data['overview']['focus'],version=hashlib.sha256(text.encode()).hexdigest()[:12])
  # The old direct Market Notes links must show the same updated source, not stale notes.
  def section(title,items):return '<section><h3>'+escape(title)+'</h3><ul>'+''.join('<li>'+escape(str(x))+'</li>' for x in items)+'</ul></section>'
  content='<article class="source-document"><h2>'+escape(raw['title'])+'</h2><p>'+escape(raw['positioning'])+'</p>'+section('Power companies',raw['utilities'])+section('Opening questions',raw['opening_questions'])+''.join(section(s['title'],s['items']) for s in sections)+section('Customer products',raw['customer_products'])+section('Product reference',[k+' — '+v for k,v in raw['product_explainer'].items()])+section('Sources',raw['official_sources'])+'</article>\n'
  (SITE/'assets/market-notes'/(noteid+'.html')).write_text(content)
  data['source']['sha256']=hashlib.sha256(content.encode()).hexdigest();text=json.dumps(data,indent=2,ensure_ascii=False)+'\n';(D/(id+'.json')).write_text(text);existing['version']=hashlib.sha256(text.encode()).hexdigest()[:12]
  reports.append({'source':str(path.relative_to(ROOT)),'sourceSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'target':str((D/(id+'.json')).relative_to(ROOT)),'allSourceFieldsPreserved':True,'adminConfigurationUnset':all(v is None or v==[] for v in raw['admin_config'].values())})
 (D/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
 # Include the newly supplied NJ notes in the resource library.
 libpath=SITE/'assets/data/library.json';lib=json.loads(libpath.read_text());rel='assets/market-notes/new-jersey.html'
 if not any(e['path']==rel for e in lib['resources']):lib['resources'].append({'id':'market-notes-new-jersey','name':'New Jersey Market Notes','section':'Market notes','path':rel,'type':'html','description':'Uploaded market edition · November 2, 2026'})
 for e in lib['resources']:
  if e['section']=='Market notes' and e['path'].split('/')[-1].removesuffix('.html') in [v[1] for v in MAPPING.values()]:e['description']='Uploaded market edition · November 2, 2026'
 libpath.write_text(json.dumps(lib,indent=2,ensure_ascii=False)+'\n');return reports
if __name__=='__main__':
 manifest=json.loads((ROOT/'source-documents/content-manifest.json').read_text());report={'edition':manifest['edition'],'scripts':import_scripts(manifest),'markets':import_markets(),'scope':'Content import only; no production deployment, live source verification or automation changes'};(ROOT/'docs/CONTENT-IMPORT-2026-11-02.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print('Imported',len(report['scripts']),'DOCX scripts and',len(report['markets']),'market files')
