<?php
// Service-double transport only in this test process. Production has no bypass switch.
$site=realpath(__DIR__.'/../hostinger/dc-hub');
$_SERVER['DOCUMENT_ROOT']=$site;
$config=tempnam('/tmp','hub-config-test-');
file_put_contents($config,"<?php return ['apps_script_url'=>'https://script.google.com/macros/s/fixture/exec','shared_secret'=>'fixture-only-shared-secret-000000000000000000000','session_idle_seconds'=>3600];");
putenv('HUB_CONFIG_FILE='.$config);
$captured=[];$inactive=false;$transport_calls=0;
function dc_http(string $url,?array $post=null): array {global $captured,$inactive,$transport_calls;$transport_calls++;$captured=$post;return $inactive?['ok'=>false,'error'=>'Inactive user']:['ok'=>true,'data'=>['name'=>'Fixture Agent','role'=>'Agent','permissions'=>['typing']]];}
$source=file_get_contents($site.'/auth/session.php');
$source=str_replace('function dc_http(', 'function dc_http_network(', $source);
eval(substr($source,5));
$checks=[];function verify_transport($name,$ok){global $checks;if(!$ok)throw new RuntimeException($name);$checks[]=$name;}
dc_begin_session();$_SESSION=['dc_user_id'=>'verified-google-subject','dc_user_email'=>'agent@example.test','dc_last_active'=>time()];
dc_rpc('appointments',['actor'=>['email'=>'attacker@example.test','role'=>'Admin']]);
$body=json_decode($captured['body'],true);
verify_transport('Server identity is independent of browser params',$body['actor']['email']==='agent@example.test'&&$body['actor']['sub']==='verified-google-subject'&&!isset($body['actor']['role']));
verify_transport('Signed envelope uses HMAC SHA256',hash_equals(base64_encode(hash_hmac('sha256',$captured['body'],dc_config()['shared_secret'],true)),$captured['signature']));
verify_transport('Envelope has fresh timestamp and random nonce',abs(time()-$body['timestamp'])<2&&preg_match('/^[a-f0-9]{48}$/D',$body['nonce']));
verify_transport('CSRF accepts only session token',dc_csrf_valid(dc_token())&&!dc_csrf_valid('attacker-token'));
$before_calls=$transport_calls;dc_read_rpc('appointments',['from'=>'2026-11-02']);dc_read_rpc('appointments',['from'=>'2026-11-02']);verify_transport('Repeated reads reuse only the current session context',$transport_calls===$before_calls+1);
$_SESSION['dc_profile']=['role'=>'Team Lead','permissions'=>['appointments']];dc_read_rpc('appointments',['from'=>'2026-11-02']);verify_transport('Permission context change invalidates cached response',$transport_calls===$before_calls+2);
$_SESSION['dc_user_email']='other@example.test';dc_read_rpc('appointments',['from'=>'2026-11-02']);verify_transport('Different authenticated identity cannot reuse cached response',$transport_calls===$before_calls+3);
$_SESSION['dc_user_email']='agent@example.test';
$inactive=true;verify_transport('Protected request rechecks current membership and denies inactive user',dc_is_authenticated()===false);
unlink($config);
file_put_contents(__DIR__.'/php-transport-results.json',json_encode(['passed'=>count($checks),'checks'=>$checks,'scope'=>'Real PHP signing/session logic with a test-only transport double'],JSON_PRETTY_PRINT));foreach($checks as $name)echo 'PASS '.$name."\n";
