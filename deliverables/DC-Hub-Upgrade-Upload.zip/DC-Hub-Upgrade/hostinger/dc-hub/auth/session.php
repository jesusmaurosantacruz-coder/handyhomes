<?php
declare(strict_types=1);
function dc_config(): array {
 static $c=null;if($c!==null)return $c;
 $file=getenv('HUB_CONFIG_FILE')?:dirname((string)($_SERVER['DOCUMENT_ROOT']??__DIR__.'/../..')).'/dc-hub-config.php';
 if(!is_file($file))throw new RuntimeException('Secure server configuration is missing.');
 $real=realpath($file);$public=realpath((string)($_SERVER['DOCUMENT_ROOT']??__DIR__.'/..'));
 if($public&&str_starts_with($real,$public.DIRECTORY_SEPARATOR))throw new RuntimeException('Configuration must be outside the public web root.');
 $c=require $real;if(!is_array($c))throw new RuntimeException('Invalid server configuration.');return $c;
}
function dc_begin_session(): void {if(session_status()===PHP_SESSION_ACTIVE)return;ini_set('session.use_strict_mode','1');ini_set('session.use_only_cookies','1');$secure=!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off';session_name('DC_HUB_V3');session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);session_start();}
function dc_token(): string {dc_begin_session();return $_SESSION['dc_csrf']??=bin2hex(random_bytes(24));}
function dc_csrf_valid(string $candidate): bool {return hash_equals(dc_token(),$candidate);}
function dc_http(string $url,?array $post=null): array {
 $h=curl_init($url);$body='';curl_setopt_array($h,[CURLOPT_RETURNTRANSFER=>false,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>45,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>3,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_REDIR_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_WRITEFUNCTION=>static function($h,$chunk)use(&$body){if(strlen($body)+strlen($chunk)>3000000)return 0;$body.=$chunk;return strlen($chunk);}]);
 if($post!==null)curl_setopt_array($h,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($post,JSON_THROW_ON_ERROR),CURLOPT_HTTPHEADER=>['Content-Type: application/json']]);
 $ok=curl_exec($h);$status=curl_getinfo($h,CURLINFO_RESPONSE_CODE);curl_close($h);if($ok===false||$status<200||$status>=300)throw new RuntimeException('Integration request failed. Check server configuration and service access.');$data=json_decode($body,true,512,JSON_THROW_ON_ERROR);if(!is_array($data))throw new RuntimeException('Invalid integration response.');return $data;
}
function dc_rpc(string $action,array $params=[],?array $actor=null): array {
 $c=dc_config();$url=(string)($c['apps_script_url']??'');$secret=(string)($c['shared_secret']??'');if(!preg_match('~^https://script\.google\.com/macros/s/[\w-]+/exec$~D',$url)||strlen($secret)<32)throw new RuntimeException('Google Workspace connection is not configured.');
 $actor??=['email'=>$_SESSION['dc_user_email']??'','sub'=>$_SESSION['dc_user_id']??''];$body=json_encode(['timestamp'=>time(),'nonce'=>bin2hex(random_bytes(24)),'action'=>$action,'params'=>$params,'actor'=>$actor],JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);$r=dc_http($url,['body'=>$body,'signature'=>base64_encode(hash_hmac('sha256',$body,$secret,true))]);if(!($r['ok']??false))throw new RuntimeException((string)($r['error']??'Integration failed.'));return $r['data']??[];
}
function dc_is_authenticated(): bool {
 static $checked=null;if($checked!==null)return $checked;dc_begin_session();if(empty($_SESSION['dc_user_id'])||empty($_SESSION['dc_user_email'])||time()-(int)($_SESSION['dc_last_active']??0)>=(int)(dc_config()['session_idle_seconds']??3600))return $checked=false;
 try{$profile=dc_rpc('profile');$_SESSION['dc_profile']=$profile;$_SESSION['dc_user_name']=$profile['name'];$_SESSION['dc_last_active']=time();return $checked=true;}catch(Throwable $e){return $checked=false;}
}
function dc_role(): string {return (string)($_SESSION['dc_profile']['role']??'');}
function dc_permission(string $action): bool {return in_array($action,$_SESSION['dc_profile']['permissions']??[],true);}
function dc_reply(array $data,int $status=200): never {http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: private, no-store');header('X-Content-Type-Options: nosniff');echo json_encode($data,JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
