/**
 * DIGITAL CITIZEN — READ-ONLY AGENT LEADERBOARD
 * Add as a NEW script file in the existing CRM Apps Script project.
 * Replace only the existing doGet with the supplied small replacement.
 * This file defines no doGet/doPost and writes nothing to Sheets or Calendar.
 * Customer fields are never returned. The calendar embed is not exposed.
 */
const DC_LEADERBOARD = Object.freeze({
  sheetName: 'CRM MASTER',
  calendarId: 'c00c3076f16ee193fd19c4bf934c5d8683b31cb9ebc3bafc98cf4338a084e8a0@group.calendar.google.com',
  reportingTimezone: 'America/Mexico_City',
  cacheSeconds: 60,
  schemaVersion: 1
});

function dcLeaderboardResponse_(e) {
  const p = e && e.parameter || {};
  if (String(p.action || '') !== 'leaderboard') return null;
  const callback = String(p.callback || '');
  if (callback && !/^dcLb[A-Za-z0-9_]{1,70}$/.test(callback)) {
    return dcLbOutput_({ok: false, error: 'Invalid leaderboard callback.'}, '');
  }
  try {
    return dcLbOutput_(dcLeaderboardData_(), callback);
  } catch (error) {
    console.error('Leaderboard error: ' + String(error && error.message || error));
    const safe = error && error.dcLeaderboardSafe ? String(error.message) : 'The leaderboard could not read the CRM. Run verifyLeaderboard() in Apps Script to check the connection.';
    return dcLbOutput_({ok: false, error: safe}, callback);
  }
}

function dcLbOutput_(data, callback) {
  const json = JSON.stringify(data).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  return ContentService.createTextOutput(callback ? callback + '(' + json + ');' : json)
    .setMimeType(callback ? ContentService.MimeType.JAVASCRIPT : ContentService.MimeType.JSON);
}

function dcLbError_(message) {
  const error = new Error(message);
  error.dcLeaderboardSafe = true;
  throw error;
}

function dcLbSource_() {
  const config = typeof DC !== 'undefined' && DC ? DC : {};
  const spreadsheetId = String(config.spreadsheetId || PropertiesService.getScriptProperties().getProperty('CRM_SPREADSHEET_ID') || '').trim();
  if (!spreadsheetId) dcLbError_('Add Leaderboard.gs to the existing CRM Apps Script project so it can use DC.spreadsheetId.');
  return {
    spreadsheetId: spreadsheetId,
    mainCalendarId: String(config.calendarId || ''),
    agentCalendarId: String(config.agentCalendarId || DC_LEADERBOARD.calendarId)
  };
}

function dcLbCacheKey_(source) {
  const scope = [source.spreadsheetId, source.mainCalendarId, source.agentCalendarId, DC_LEADERBOARD.calendarId, DC_LEADERBOARD.reportingTimezone, DC_LEADERBOARD.schemaVersion].join('|');
  return 'dc-lb-v1:' + Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, scope, Utilities.Charset.UTF_8)).slice(0,32);
}

function dcLeaderboardData_() {
  const source = dcLbSource_();
  const cache = CacheService.getScriptCache();
  const key = dcLbCacheKey_(source);
  const stored = cache.get(key);
  if (stored) {
    try { return JSON.parse(stored); } catch (ignored) { /* Rebuild a corrupt cache. */ }
  }
  const ss = SpreadsheetApp.openById(source.spreadsheetId);
  const sheet = ss.getSheetByName(DC_LEADERBOARD.sheetName);
  if (!sheet) dcLbError_('CRM MASTER was not found in the CRM spreadsheet.');
  const lastRow = sheet.getLastRow(), lastColumn = sheet.getLastColumn();
  if (!lastRow || !lastColumn) dcLbError_('CRM MASTER needs its header row.');
  // One sheet read. No Calendar API calls or event descriptions are needed.
  const grid = sheet.getRange(1,1,lastRow,lastColumn).getValues();
  const data = dcLbAggregate_(grid, source, ss.getSpreadsheetTimeZone(), new Date());
  const serialized = JSON.stringify(data);
  // CacheService allows 100 KB per entry. Larger datasets still return normally.
  if (Utilities.newBlob(serialized).getBytes().length < 95000) cache.put(key,serialized,DC_LEADERBOARD.cacheSeconds);
  return data;
}

function dcLbNorm_(value) {
  return String(value === null || value === undefined ? '' : value).trim().replace(/\s+/g,' ').toLowerCase();
}

function dcLbState_(value) {
  const names = ['Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut','Delaware','District of Columbia','Florida','Georgia','Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana','Maine','Maryland','Massachusetts','Michigan','Minnesota','Mississippi','Missouri','Montana','Nebraska','Nevada','New Hampshire','New Jersey','New Mexico','New York','North Carolina','North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania','Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont','Virginia','Washington','West Virginia','Wisconsin','Wyoming'];
  const codes = 'AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY'.split(' ');
  const normalized = dcLbNorm_(value).replace(/\./g,'');
  const index = names.findIndex(name => dcLbNorm_(name) === normalized);
  return index >= 0 ? codes[index] : normalized ? normalized.toUpperCase() : 'Unspecified';
}

function dcLbDayValid_(day) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return '';
  const date = new Date(day + 'T12:00:00Z');
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0,10) === day ? day : '';
}

function dcLbDate_(value, sourceTimezone, appointmentDate) {
  if (value instanceof Date) return Number.isFinite(value.getTime()) ? Utilities.formatDate(value, appointmentDate ? sourceTimezone : DC_LEADERBOARD.reportingTimezone,'yyyy-MM-dd') : '';
  const text = String(value || '').trim();
  if (!text) return '';
  if (/^\d{4}-\d{2}-\d{2}$/.test(text)) return dcLbDayValid_(text);
  if (/^\d{4}-\d{2}-\d{2}T.*(?:Z|[+-]\d{2}:?\d{2})$/.test(text)) {
    const date = new Date(text);
    return Number.isFinite(date.getTime()) ? Utilities.formatDate(date,DC_LEADERBOARD.reportingTimezone,'yyyy-MM-dd') : '';
  }
  const match = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i);
  if (match) {
    const day = match[3] + '-' + match[1].padStart(2,'0') + '-' + match[2].padStart(2,'0');
    if (!dcLbDayValid_(day)) return '';
    if (!match[4] || appointmentDate) return day;
    let hour = Number(match[4]);
    if (match[7]) { if (hour < 1 || hour > 12) return ''; hour = hour % 12 + (match[7].toUpperCase() === 'PM' ? 12 : 0); }
    if (hour > 23 || Number(match[5]) > 59 || Number(match[6] || 0) > 59) return '';
    try {
      const date = Utilities.parseDate(day+' '+String(hour).padStart(2,'0')+':'+match[5]+':'+(match[6] || '00'),sourceTimezone,'yyyy-MM-dd HH:mm:ss');
      return Utilities.formatDate(date,DC_LEADERBOARD.reportingTimezone,'yyyy-MM-dd');
    } catch (ignored) { return ''; }
  }
  const isoWall = text.match(/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2})(?::\d{2})?$/);
  if (isoWall && dcLbDayValid_(isoWall[1])) {
    try { return Utilities.formatDate(Utilities.parseDate(isoWall[1]+' '+isoWall[2],sourceTimezone,'yyyy-MM-dd HH:mm'),DC_LEADERBOARD.reportingTimezone,'yyyy-MM-dd'); } catch (ignored) { return ''; }
  }
  return '';
}

function dcLbInCalendar_(get, source) {
  const target = DC_LEADERBOARD.calendarId;
  const rowAgentCalendar = String(get('Agent Calendar ID') || '').trim();
  const agentEvent = String(get('Agent Calendar Event ID') || '').trim();
  if (agentEvent && (rowAgentCalendar || source.agentCalendarId) === target) return true;
  const rowCalendar = String(get('Calendar ID') || '').trim();
  const mainEvent = String(get('Calendar API Event ID') || get('Calendar Event ID') || '').trim();
  return !!mainEvent && (rowCalendar || source.mainCalendarId) === target;
}

function dcLbTime_(value, sourceTimezone) {
  if (value instanceof Date) return Utilities.formatDate(value,sourceTimezone,'HH:mm');
  const match = String(value || '').trim().match(/^(\d{1,2}):(\d{2})(?::\d{2})?\s*(AM|PM)?$/i);
  if (!match) return '';
  let hour = Number(match[1]);
  if (match[3]) { if (hour < 1 || hour > 12) return ''; hour = hour % 12 + (match[3].toUpperCase() === 'PM' ? 12 : 0); }
  return hour <= 23 && Number(match[2]) <= 59 ? String(hour).padStart(2,'0')+':'+match[2] : '';
}

function dcLbCalendarWhen_(record) {
  if (!record.appointmentDate) return null;
  if (!record.time) return {date:record.appointmentDate,time:''};
  try {
    const instant = Utilities.parseDate(record.appointmentDate+' '+record.time,record.timezone,'yyyy-MM-dd HH:mm');
    return {date:Utilities.formatDate(instant,DC_LEADERBOARD.reportingTimezone,'yyyy-MM-dd'),time:Utilities.formatDate(instant,DC_LEADERBOARD.reportingTimezone,'HH:mm')};
  } catch (ignored) { return {date:record.appointmentDate,time:'',timePending:true}; }
}

function dcLbAggregate_(grid, source, sourceTimezone, now) {
  const header = grid[0] || [];
  const index = {};
  header.forEach((name,i) => { index[dcLbNorm_(name)] = i; });
  for (const name of ['Record Type','Setter Name','Appointment Date']) {
    if (index[dcLbNorm_(name)] === undefined) dcLbError_('CRM MASTER is missing the '+name+' column.');
  }
  if (index['agent calendar event id'] === undefined && index['calendar api event id'] === undefined && index['calendar event id'] === undefined) {
    dcLbError_('CRM MASTER needs its Calendar event-link columns for this leaderboard.');
  }
  const records = new Map();
  let unassigned = 0;
  for (let r = 1; r < grid.length; r++) {
    const row = grid[r];
    const get = name => index[dcLbNorm_(name)] === undefined ? '' : row[index[dcLbNorm_(name)]];
    if (dcLbNorm_(get('Record Type')) !== 'appointment' || !dcLbInCalendar_(get,source)) continue;
    const name = String(get('Setter Name') || '').trim().replace(/\s+/g,' ');
    const email = dcLbNorm_(get('Setter Email'));
    const submissionDate = dcLbDate_(get('Submission Timestamp'),sourceTimezone,false);
    const appointmentDate = dcLbDate_(get('Appointment Date'),sourceTimezone,true);
    const formKey = String(get('Form Submission Key') || '').trim();
    const event = String(get('Agent Calendar Event ID') || get('Calendar API Event ID') || get('Calendar Event ID') || '').trim();
    // Stable submission/event identity prevents duplicated imported rows inflating ranks.
    const identity = formKey ? 'form:'+formKey : event ? 'event:'+event : 'row:'+r;
    const dcConfig = typeof DC !== 'undefined' && DC ? DC : {};
    const record = { name: name, nameKey: dcLbNorm_(name), email: email, submissionDate: submissionDate, appointmentDate: appointmentDate,
      time: dcLbTime_(get('Start Time'),sourceTimezone), timezone: String(get('Appointment Time Zone') || dcConfig.defaultZone || sourceTimezone),
      campaign: String(get('Campaign') || 'Unspecified').trim(), state: dcLbState_(get('State')),
      status: dcLbNorm_(get('Appointment Status')).replace(/[-_]+/g,' '),
      confirmation: dcLbNorm_(get('Confirmation Status')), disposition: dcLbNorm_(get('Disposition')),
      updated: get('Last Updated') instanceof Date ? get('Last Updated').getTime() : r, row: r };
    const previous = records.get(identity);
    if (!previous || record.updated >= previous.updated) records.set(identity,record);
  }
  const nameEmails = new Map();
  records.forEach(record => {
    if (record.name && record.email) {
      if (!nameEmails.has(record.nameKey)) nameEmails.set(record.nameKey,new Set());
      nameEmails.get(record.nameKey).add(record.email);
    }
  });
  const agentsByKey = new Map(), buckets = new Map(), calendar = [];
  const metrics = ['set','confirmed','completed','closedWon','noShows'];
  records.forEach(record => {
    if (!record.name || ['unassigned','unassigned agent'].includes(record.nameKey)) { unassigned++; return; }
    const candidates = nameEmails.get(record.nameKey);
    const email = record.email || (candidates && candidates.size === 1 ? [...candidates][0] : '');
    const agentKey = email ? 'email:'+email : 'name:'+record.nameKey;
    if (!agentsByKey.has(agentKey)) agentsByKey.set(agentKey,{id: 'a'+agentsByKey.size, name: record.name, row: record.row});
    const agent = agentsByKey.get(agentKey);
    if (record.row >= agent.row) { agent.name = record.name; agent.row = record.row; }
    const bucketKey = JSON.stringify([agent.id,record.submissionDate,record.appointmentDate,record.campaign,record.state]);
    if (!buckets.has(bucketKey)) {
      const bucket = {agentId: agent.id,submissionDate: record.submissionDate,appointmentDate: record.appointmentDate,campaign: record.campaign,state: record.state};
      metrics.forEach(metric => { bucket[metric] = 0; });
      buckets.set(bucketKey,bucket);
    }
    const bucket = buckets.get(bucketKey);
    bucket.set++;
    if ((record.status === 'confirmed' || record.confirmation === 'confirmed') && !['cancelled','canceled','dnq','no show'].includes(record.status)) bucket.confirmed++;
    if (record.status === 'completed') bucket.completed++;
    if (record.disposition === 'closed won') bucket.closedWon++;
    if (record.status === 'no show') bucket.noShows++;
    const when = dcLbCalendarWhen_(record);
    if (when) {
      const statuses = {'scheduled':'Scheduled','confirmed':'Confirmed','completed':'Completed','no show':'No Show','rescheduled':'Rescheduled','cancelled':'Cancelled','canceled':'Cancelled','dnq':'DNQ'};
      calendar.push({agentId:agent.id,date:when.date,time:when.time,state:record.state,campaign:record.campaign,status:statuses[record.status] || 'Pending'});
    }
  });
  // Explicit whitelist: no emails, customer names, phones, addresses, notes,
  // calendar IDs, event IDs, spreadsheet IDs, or individual CRM records.
  return {
    ok: true, schemaVersion: DC_LEADERBOARD.schemaVersion,
    generatedAt: now.toISOString(), today: Utilities.formatDate(now,DC_LEADERBOARD.reportingTimezone,'yyyy-MM-dd'),
    timezone: DC_LEADERBOARD.reportingTimezone,
    agents: [...agentsByKey.values()].map(agent => ({id:agent.id,name:agent.name})),
    buckets: [...buckets.values()], calendar: calendar, unassigned: unassigned
  };
}

function verifyLeaderboard() {
  const data = dcLeaderboardData_();
  const count = data.buckets.reduce((sum,bucket) => sum + bucket.set,0);
  console.log('Leaderboard ready: '+data.agents.length+' agents, '+count+' linked CRM appointments. Reporting timezone: '+data.timezone+'.');
  return {ok: true, agents: data.agents.length, appointments: count, unassigned: data.unassigned};
}
