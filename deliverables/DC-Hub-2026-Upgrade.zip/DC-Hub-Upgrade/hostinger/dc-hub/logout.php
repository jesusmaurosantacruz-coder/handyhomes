<?php
declare(strict_types=1);
require_once __DIR__ . '/auth/session.php';
dc_begin_session();
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', [
        'expires' => time() - 42000,
        'path' => $params['path'],
        'domain' => $params['domain'],
        'secure' => $params['secure'],
        'httponly' => $params['httponly'],
        'samesite' => 'Lax',
    ]);
}
session_destroy();
header('Cache-Control: no-store, max-age=0');
header('Location: login.php', true, 303);
exit;
