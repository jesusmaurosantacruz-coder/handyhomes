<?php
/** Privileged, path-whitelisted asset editor. No CRM customer data enters this API. */
declare(strict_types=1);
require_once __DIR__ . '/../auth/session.php';
require_once __DIR__ . '/../auth/content.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');
function respond(int $status,array $data): void {http_response_code($status);echo json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);exit;}
if (!dc_is_authenticated() || (dc_role()!=='Admin'||!dc_permission('administration'))) respond(403,['ok'=>false,'error'=>'Manager unlock required.']);
$root=realpath(__DIR__.'/..');
$modules=['campaigns','resources','schedule','team','site','leaderboard','typing','media'];
function script_path(string $name): ?string {
    if (!preg_match('~^[a-z0-9-]{1,80}\.html$~D',$name)) return null;
    return __DIR__.'/../assets/scripts/'.$name;
}
function market_note_path(string $name): ?string {
    if (!preg_match('~^[a-z0-9-]{1,80}\.html$~D',$name)) return null;
    return __DIR__.'/../assets/market-notes/'.$name;
}
function clean_note_html(string $html): string {return dc_clean_html($html);}
function resource_url($url): bool {
    return is_string($url) && ($url!=='' && str_starts_with($url,'https://') && web_url($url) || in_array($url,['index.html','campaigns/index.html','resources/index.html','calendar/index.html','leaderboard/index.html','dialing-station/index.html','training/typing/index.html','training/audio/index.html','training/videos/index.html'],true));
}
function asset_path(string $name): string{return __DIR__.'/../assets/data/'.$name.'.json';}
function save_asset(string $file,string $content): void {
    $backup=__DIR__.'/backups';
    if (!is_dir($backup)) mkdir($backup,0750,true);
    if (is_file($file)) {
        $backupFile=$backup.'/'.basename($file).'.'.date('Ymd-His').'.'.bin2hex(random_bytes(3)).'.bak';
        if (!copy($file,$backupFile)) throw new RuntimeException('Cannot create backup. Check file permissions.');
    }
    $temp=tempnam(dirname($file),'.dc-');
    if ($temp===false) throw new RuntimeException('Cannot create temporary file.');
    if (file_put_contents($temp,$content,LOCK_EX)===false || !rename($temp,$file)) { @unlink($temp); throw new RuntimeException('Cannot write asset. Check Hostinger file permissions.'); }
    @chmod($file,0640);
}
function text_field($value,int $max=5000): bool{return is_string($value) && strlen($value)<=$max && strpos($value,"\0")===false;}
function web_url($value): bool{return text_field($value,2048) && ($value==='' || (str_starts_with($value,'https://') && filter_var($value,FILTER_VALIDATE_URL)!==false));}
function validate_module(string $name,$data): bool {
    if ($name==='site') {
        if(!is_array($data))return false;
        foreach(['brand','headline','tagline','subline','timezone'] as $key) if(!text_field($data[$key]??null,300))return false;
        if(($data['timezone']??'')!=='America/Mexico_City')return false;
        if(!isset($data['rollCalls']) || !is_array($data['rollCalls']) || count($data['rollCalls'])>15)return false;
        foreach($data['rollCalls'] as $r) if(!is_array($r) || !text_field($r['title']??null,150) || !text_field($r['description']??null,300) || !web_url($r['url']??null))return false;
        return true;
    }
    if($name==='typing') {
        if(!is_array($data)||!is_array($data['agents']??null)||count($data['agents'])>150)return false;
        foreach($data['agents'] as $agent)if(!text_field($agent,120)||trim($agent)==='')return false;
        return count(array_unique($data['agents']))===count($data['agents']);
    }
    if($name==='media') {
        if(!is_array($data)||count($data)>500)return false;
        $ids=[];
        foreach($data as $item){
            if(!is_array($item)||!preg_match('/^[a-z0-9-]{1,70}$/D',(string)($item['id']??''))||in_array($item['id'],$ids,true))return false;
            $ids[]=$item['id'];
            foreach(['title','description','category','difficulty'] as $f)if(!text_field($item[$f]??'',1000))return false;
            if(!is_bool($item['visible']??null)||!in_array($item['type']??'',['audio','video'],true))return false;
            $filename=$item['file']??'';
            if(!is_string($filename)||!preg_match('/^[a-z0-9-]+\.(mp3|mp4)$/D',$filename)||!is_file(__DIR__.'/../training/media/'.$filename))return false;
            if(pathinfo($filename,PATHINFO_EXTENSION)!==($item['type']==='audio'?'mp3':'mp4'))return false;
        }
        return true;
    }
    if ($name==='leaderboard')return is_array($data) && text_field($data['title']??null,130) && text_field($data['description']??null,350) && text_field($data['footnote']??null,400);
    if ($name==='schedule') {
        if(!is_array($data) || !text_field($data['title']??null,100) || !text_field($data['timezoneBadge']??null,50) || !text_field($data['timezoneLabel']??null,130) || !isset($data['items']) || !is_array($data['items']) || count($data['items'])>30)return false;
        foreach($data['items'] as $item)if(!is_array($item) || !text_field($item['time']??null,60) || !text_field($item['title']??null,100) || !text_field($item['detail']??null,350) || !is_array($item['action']??null) || !text_field($item['action']['label']??null,100) || !web_url($item['action']['url']??''))return false;
        return true;
    }
    if(!is_array($data) || count($data)>80)return false;
    $ids=[];
    foreach($data as $item){
        if(!is_array($item)|| !preg_match('/^[a-z0-9-]{1,70}$/D',(string)($item['id']??'')) || in_array($item['id'],$ids,true))return false;
        $ids[]=$item['id'];
        if(!isset($item['visible']) || !is_bool($item['visible']))return false;
        if($name==='campaigns') {
            foreach(['name','category','description','region','visual','script','notes'] as $field)if(!text_field($item[$field]??null,$field==='notes'?6000:800))return false;
            if(!preg_match('~^assets/visuals/[a-z0-9-]+\.svg$~D',$item['visual']) || !script_path($item['script']) || !is_file(script_path($item['script'])))return false;
            if(!market_note_path($item['marketNotes']??'')||!is_file(market_note_path($item['marketNotes'])))return false;
            if(!in_array($item['type']??'', ['solar','roofing','fiber'],true)||!text_field($item['formLabel']??null,200))return false;
            foreach(['submitUrl','dialerUrl'] as $f)if(!web_url($item[$f]??null))return false;
            if(!is_array($item['crmCampaigns']??null) || count($item['crmCampaigns'])>30)return false;
            foreach($item['crmCampaigns'] as $alias) if(!text_field($alias,120))return false;
        } elseif($name==='resources'){
            foreach(['title','description','category'] as $field)if(!text_field($item[$field]??null,600))return false;
            if(!empty($item['url'])){if(!resource_url($item['url']))return false;}elseif(!script_path($item['script']??'')||!is_file(script_path($item['script'])))return false;
        }elseif($name==='team'){
            foreach(['name','role'] as $field)if(!text_field($item[$field]??null,300))return false;
            if(!web_url($item['roamUrl']??null) || !web_url($item['whatsappUrl']??null))return false;
        }else return false;
    }
    return true;
}
$mode=(string)($_GET['mode']??'module');
$name=(string)($_GET['name']??'');
if($_SERVER['REQUEST_METHOD']==='GET') {
    if($mode==='marketnotes') {
        $names=array_map('basename',glob(__DIR__.'/../assets/market-notes/*.html')?:[]);
        sort($names);respond(200,['ok'=>true,'files'=>$names]);
    }
    if($mode==='marketnote'){
        $file=market_note_path($name);
        if(!$file||!is_file($file))respond(404,['ok'=>false,'error'=>'Market Note not found.']);
        respond(200,['ok'=>true,'data'=>file_get_contents($file)]);
    }
    if($mode==='scripts') {
        $names=array_map('basename',glob(__DIR__.'/../assets/scripts/*.html')?:[]);
        sort($names);respond(200,['ok'=>true,'files'=>$names]);
    }
    if($mode==='script'){
        $file=script_path($name);
        if(!$file||!is_file($file))respond(404,['ok'=>false,'error'=>'Script not found.']);
        respond(200,['ok'=>true,'data'=>file_get_contents($file)]);
    }
    if($mode==='module'&&in_array($name,$modules,true)){
        $raw=@file_get_contents(asset_path($name));
        if($raw===false)respond(404,['ok'=>false,'error'=>'Module not found.']);
        respond(200,['ok'=>true,'data'=>json_decode($raw,true,512,JSON_THROW_ON_ERROR)]);
    }
    respond(404,['ok'=>false,'error'=>'Unknown editor target.']);
}
if($_SERVER['REQUEST_METHOD']!=='POST')respond(405,['ok'=>false,'error'=>'Unsupported method.']);
if(!dc_csrf_valid((string)($_SERVER['HTTP_X_CSRF_TOKEN']??'')))respond(403,['ok'=>false,'error'=>'Session verification failed.']);
$raw=file_get_contents('php://input');if(!is_string($raw)||strlen($raw)>210000)respond(413,['ok'=>false,'error'=>'Asset too large.']);
try{$post=json_decode($raw,true,512,JSON_THROW_ON_ERROR);}catch(Throwable $e){respond(400,['ok'=>false,'error'=>'Invalid JSON request.']);}
if(!is_array($post))respond(400,['ok'=>false,'error'=>'Invalid request.']);
$mode=(string)($post['mode']??'');$name=(string)($post['name']??'');
try{
    if($mode==='module'&&in_array($name,$modules,true)){
        $value=$post['data']??null;
        if(!validate_module($name,$value))respond(422,['ok'=>false,'error'=>'Invalid module fields. Check required values and HTTPS links.']);
        $out=json_encode($value,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n";
        save_asset(asset_path($name),$out);
        respond(200,['ok'=>true,'message'=>'Saved '.$name.'.json']);
    }
    if($mode==='marketnote') {
        $file=market_note_path($name);$content=$post['data']??null;
        if(!$file||!text_field($content,140000))respond(422,['ok'=>false,'error'=>'Invalid market note file or content.']);
        save_asset($file,clean_note_html($content)."\n");
        respond(200,['ok'=>true,'message'=>'Saved Market Notes '.$name]);
    }
    if($mode==='script') {
        $file=script_path($name);$content=$post['data']??null;
        if(!$file||!text_field($content,140000))respond(422,['ok'=>false,'error'=>'Invalid script name or content.']);
        // HTML snippets only. No JavaScript, inline event attributes, links or embeds.
        $safe=dc_clean_html($content);
        save_asset($file,$safe."\n");
        respond(200,['ok'=>true,'message'=>'Saved '.$name]);
    }
    respond(404,['ok'=>false,'error'=>'Unknown editor target.']);
}catch(Throwable $e){respond(500,['ok'=>false,'error'=>$e->getMessage()]);}
