# DC HUB | Market Notes — Deployment package (November 2, 2026)

Eight agent-ready market JSON files, designed for direct static serving from Hostinger. No Google Sheets request is required to load these notes.

## Recommended deployment
1. Upload the eight `.json` files to `public_html/dc-hub/assets/data/markets/`.
2. Populate the navigation from `index.json`. Fetch a market's JSON only when the agent opens it. Cache the response in memory.
3. Use `opening_questions`, `utilities`, `local_intelligence`, `quick_objections`, and `qualify` as the compact live-dial layout. Hide `product_explainer`, `official_sources`, and `agent_rules` behind expandable reference sections.
4. `admin_config` values are deliberately unset until management confirms actual clients' campaign restrictions; never publish a fabricated eligibility or financing claim.
5. Coverage maps are deliberately not approximated as ZIP polygons. Add independently sourced utility coverage maps as separate optimized WebP/SVG assets, with utility-bill verification always visible.

## Interpretation
- Texas and Florida are **battery-first** according to the active sales strategy. This is positioning, not an assertion that solar net metering is unavailable in Florida.
- The others prioritize solar bill economics or net-metering discussions, but California's newer investor-owned utility tariff is **net billing**, not classic retail-credit net metering.
- Pennsylvania includes a distinct roofing path.
- Suppliers and payment products listed are reference vocabulary, **not** assertions of actual stock or campaign approval.

## Review scope
Built from the user's connected market docs, previously supplied campaign direction, and official references where available. Utility coverage lines are orientation aids, not geofenced eligibility maps. Regulatory claims, offers, finance programs, and local conditions require a live check before an agent makes a specific promise. Existing Google Docs have not been overwritten.
