# Digital Citizen Hub upgrade

This folder contains the upgraded PHP/Apache website, consolidated Apps Script project, additive workbook migration, tests and deployment instructions. It uses the supplied Hub, Eagle Eyes API patterns, Apps Scripts, workbook structure and latest three-mode typing package.

**Upload `hostinger/dc-hub/` to a staging directory first.** The website needs its Google OAuth and Apps Script connection configured before users can sign in. Uploading website files alone does not update Google Workspace or make the application operational.

Folder contents:

- `hostinger/dc-hub/`: website files; no build or npm install required.
- `hostinger/private-config/dc-hub-config.example.php`: server configuration template. The real file belongs **outside `public_html`**.
- `apps-script/`: the complete replacement Apps Script project, including `appsscript.json`.
- `docs/DEPLOYMENT.md`: staged installation, Google authorization, migration, trigger setup and rollback.
- `docs/ARCHITECTURE.md`: data, permission, team and calendar decisions.
- `docs/TEST-REPORT.md`: local results and remaining live acceptance checks.
- `tests/`: executable tests and screenshots, with synthetic records only.
- `tools/`: local verification and packaging utilities.

Team 1, Team 2 and Team 3 are created without guessed assignments. Existing workbook names (`CRM MASTER`, `USERS`, `ROLE_PERMISSIONS`, `PRODUCTION_GOALS`, `CRM_HUB_LINKS`, `Typing Test`) are retained. No production website, spreadsheet, form, calendar, trigger or Roam channel was modified during implementation.

Start with `docs/DEPLOYMENT.md`. Do not replace the current live site until the sandbox and staging acceptance checks pass.
