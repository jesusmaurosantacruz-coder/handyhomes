# Integration status and configuration

## Existing CRM, leaderboard and calendar

Retained: `leaderboard/assets/js/config.js`, leaderboard/core/client, calendar page, shared dashboard CRM events and original campaign IDs/CRM aliases. These use the existing Apps Script `/exec` URL already present in the original archive. Numbers are not fabricated when it is unavailable. Local route and application checks passed; production data, access rights, script deployment, and existing external Hostinger CRM proxy were not verified. No credentials or appointment data were changed.

`integrations/Code.gs`, `Dashboard.gs`, and `Leaderboard.gs` are the three earlier supplied scripts, preserved as reference files in the **source ZIP only**. They share a CRM project; do not paste the typing endpoint into that project because its doGet/doPost would conflict. No reference script was installed or executed against Google. Updating these scripts requires a separate reviewed deployment with appropriate Sheet/Calendar permissions.

## Forms, Maps and meetings

Solar uses the original supplied PreQual URL. Roofing uses the exact provided form ID (`1FAIpQLSdKRfPAGKno46JtuLu3PUGigKg0hJan-wdkAJO_h7D8ez_0Eg`); the station adds `embedded=true` to the iframe. Popup requests are 800×800, subject to browser window rules; a visible new-tab link is available when blocked. The Hub does not handle or modify Google Form submissions. The preserved morning roll-call URL is an `/edit` link; management should supply a verified responder URL if agents lack access. It was not guessed or replaced.

Maps uses a real `https://www.google.com/maps/search/?api=1&query=...` destination, encoded from the agent's input. It opens separately, preserving Hub state. There is no simulated embedded map or claimed Maps API authorization.

Both schedule meetings and the dashboard resource use the exact provided Roam Arena. Guest entry and meeting permissions were not verified. Original direct team contacts, CallTools and VICIdial destinations are retained.

Fiber retains the Release 4 script, market notes and local handoff checklist. No Fiber DOCX or final provider URL was supplied. The manager may configure a verified HTTPS destination under the campaign's Submission link; the local checklist remains available. The Hub never sends its checklist values to an invented endpoint or stores them locally.

## Daily typing → Google Sheets

The supplied HTML's 25 lessons, roster defaults, daily America/Merida rotation starting 2026-10-29, WPM, accuracy, full-text completion, 90% threshold, local streaks and keyboard behavior remain. Local browser tests completed a real lesson using input events. These are self-reported practice scores, not tamper-proof identity or productivity measurements. Roster choice does not authenticate that named agent.

The previous `leaderboardWebApp` browser placeholder is deliberately unused. **Configure the server fields below**, never a browser key. Local progress works with no backend, and the UI explicitly says Sheets is not connected. A failed/opaque request cannot produce a successful-delivery message.

1. In Solar PreQual Form 2027 (the spreadsheet ID in the supplied `integrations/Typing.gs`), retain/create `Typing Assets` and `Typing Test` without clearing existing data. `Typing Assets`: column A display name, column B Active checkbox. `Typing Test` headers: Timestamp, Date, Agent, Lesson, Title, WPM, Accuracy, Seconds, Status, ID, Submitted by, Provenance. The first ten columns retain the supplied schema; the last two add provenance. The optional leaderboard is computed from these results.
2. Create a **separate standalone Apps Script project**, paste `integrations/Typing.gs`, and set Script Property **`TYPING_API_KEY`** to a strong random shared secret. The modified endpoint protects result actions with that property; its public GET does not expose the roster/results. Run `checkTypingSetup()` as an authorized Sheet owner to check tabs/roster; it does not clear data.
3. Deploy a Web app executing as the authorized owner. If deployment access is Anyone so that PHP can call it, the shared key is still required for data actions. Keep the deployment's `/exec` URL. No deployment is supplied or verified here.
4. Copy `auth/typing-config.example.php` to **`auth/typing-config.php`** on Hostinger and set private array fields **`url`** (the exact HTTPS `/exec` URL) and **`key`** (same secret). Alternatively securely set **`DC_TYPING_WEB_APP_URL`** and **`DC_TYPING_API_KEY`** in the PHP process environment. The config filename is denied by `.htaccess` and excluded from archives/Git. Never put key values in chat, HTML, JS, or documentation.
5. Edit the Hub's approved names under Manager → Typing roster. Keep these consistent with active names in `Typing Assets`; both validation layers must agree. There is no automatic roster synchronization claim. Sheet owners can maintain `Typing Assets`; Hub managers maintain the agent-facing approved list without code changes.
6. Authenticated `training/typing/api.php?action=config` supplies the local roster, configuration status and session CSRF token. Results use same-origin POST + CSRF, server validation and server-to-Google HTTPS. The Apps Script validates key, active roster, daily lesson, bounded WPM/accuracy/time and attempt ID, then locks and deduplicates by result ID before append. Formula-leading text is escaped. Proxy delivery is only reported when Google returns a valid `{ok:true}` response.
7. Failed submissions keep the identifier locally and offer a retry; a same-day retry reuses that identifier (the backend intentionally rejects a result for a different daily lesson). A later new practice attempt gets its own identifier. Only a qualified full passage adds local completion/streak. Sheet status marks <90% as Retry. Self-reported scores can still be manipulated by a client.
8. Once configured, managers see a results link on the typing page. `results.php` and the proxy's results action check the manager identity server-side; returned results HTML is sandboxed. Test real delivery, duplicate acknowledgment and sheet provenance before treating it as operational.

Backend logic passed service-double tests; live Apps Script deployment, Google authorization and PHP-to-Google delivery remain outstanding. The URL/key are intentionally absent from the delivery.

## Script maintenance

No live Google Docs sync is implemented. Supplied DOCX files are stored in the source package. `python3 tools/import_docx.py "source.docx" "assets/scripts/approved-name.html"` imports WordprocessingML into scoped HTML and checks source text order. It retains run colors, bold/italic/underline, highlight/shading, sizes, paragraph spacing/line breaks, styles and tables. Re-importing intentionally replaces that asset; back it up before doing so. Managers can instead use the secured visual editor with color/highlight controls and advanced HTML as an optional tool. Server allowlists retain safe formatting and remove executable markup/CSS.
