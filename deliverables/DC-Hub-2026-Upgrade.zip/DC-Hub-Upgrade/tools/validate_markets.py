from pathlib import Path
import hashlib,json
from jsonschema import Draft202012Validator,FormatChecker
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'hostinger/dc-hub';D=SITE/'assets/data/markets'
schema=json.loads((D/'schema.json').read_text());validator=Draft202012Validator(schema,format_checker=FormatChecker());manifest=json.loads((D/'manifest.json').read_text());ids=[]
for entry in manifest['markets']:
 path=D/entry['file'];data=json.loads(path.read_text());validator.validate(data);assert data['id']==entry['id'];ids.append(data['id']);assert entry['version']==hashlib.sha256(path.read_bytes()).hexdigest()[:12]
 if data['id'] in ['texas','florida']:assert 'Battery' in data['overview']['focus']
 if data['source'].get('sha256'):assert hashlib.sha256((SITE/data['source']['localPath']).read_bytes()).hexdigest()==data['source']['sha256']
 if data['coverageGraphic']['path']:assert (SITE/data['coverageGraphic']['path']).is_file()
assert len(ids)==len(set(ids))
assert set(['new-jersey','maryland','virginia','pennsylvania','south-carolina','southern-california','florida','texas']).issubset(ids)
report={'markets':len(ids),'schema':'passed','versions':'passed','sourceProvenance':'passed','requiredMarkets':'passed','verifiedCoverageMaps':0}
(ROOT/'tests/market-results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
