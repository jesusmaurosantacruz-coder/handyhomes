<?php
// Copy to auth/typing-config.php on the server, or inject these environment variables.
// Keep the actual file private. Never put the key in browser HTML/JS.
return [
    'url' => getenv('DC_TYPING_WEB_APP_URL') ?: '',
    'key' => getenv('DC_TYPING_API_KEY') ?: '',
];
