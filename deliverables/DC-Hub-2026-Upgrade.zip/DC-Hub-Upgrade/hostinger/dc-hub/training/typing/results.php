<?php require_once __DIR__.'/../../auth/session.php'; if(!dc_is_authenticated()){header('Location: ../../login.php',true,303);exit;} header('Location: index.html',true,303);
