function hubJson_(o){return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);}
function doGet(){return hubJson_({ok:true,service:'Digital Citizen Hub',version:'3.0',data:'Authenticated server POST required'});}
function doPost(e){try{if(!e||!e.postData||e.postData.contents.length>90000)throw Error('Invalid request');const b=hubVerifyEnvelope_(JSON.parse(e.postData.contents));const u=hubUser_(b.actor.email,b.actor.sub),p=b.params||{};let data;
 switch(b.action){
 case 'profile':data=hubPublicUser_(u);break;
 case 'bootstrap':data={user:hubPublicUser_(u),resources:hubCan_(u,'resources')?hubResources_(u):[],announcements:hubAnnouncements_(u),goals:hubGoals_(u),teams:hubRows_('teams').filter(r=>hubActive_(r.Active)).map(r=>r.Team)};break;
 case 'appointments':hubRequire_(u,p.calendar?'calendar':'appointments');data=hubAppointments_(u,p);break;
 case 'detail':hubRequire_(u,'appointments');data=hubDetail_(u,p.id);break;
 case 'analytics':hubRequire_(u,'analytics');data=hubAnalytics_(u,p);break;
 case 'resources':hubRequire_(u,'resources');data=hubResources_(u);break;
 case 'markets':hubRequire_(u,'resources');data=hubMarkets_(u);break;
 case 'document':hubRequire_(u,'resources');data=hubDocument_(u,p);break;
 case 'typingStart':hubRequire_(u,'typing');data=hubTypingStart_(u,p);break;
 case 'typingSave':hubRequire_(u,'typing');data=hubTypingSave_(u,p);break;
 case 'typingLeaderboard':hubRequire_(u,'typing');data=hubTypingLeaderboard_(u,p);break;
 case 'adminData':hubRequire_(u,'administration');data=hubAdminData_();break;
 case 'adminSave':hubRequire_(u,'administration');data=hubAdminSave_(u,p);break;
 default:throw Error('Unknown action');}
 return hubJson_({ok:true,data});
 }catch(err){return hubJson_({ok:false,error:String(err.message||err)});}}
