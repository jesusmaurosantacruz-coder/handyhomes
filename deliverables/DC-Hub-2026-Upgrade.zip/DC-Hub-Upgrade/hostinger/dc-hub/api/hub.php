<?php
declare(strict_types=1);
require_once __DIR__.'/../auth/session.php';require_once __DIR__.'/../auth/content.php';
try {
 if(!dc_is_authenticated())dc_reply(['ok'=>false,'error'=>'Sign in with an active operations account.'],401);
 if($_SERVER['REQUEST_METHOD']!=='POST')dc_reply(['ok'=>false,'error'=>'POST required'],405);
 if(!dc_csrf_valid((string)($_SERVER['HTTP_X_CSRF_TOKEN']??'')))dc_reply(['ok'=>false,'error'=>'Security token expired. Refresh the page.'],403);
 if((int)($_SERVER['CONTENT_LENGTH']??0)>80000)dc_reply(['ok'=>false,'error'=>'Request too large'],413);
 $raw=file_get_contents('php://input',false,null,0,80001);if(strlen($raw)>80000)dc_reply(['ok'=>false,'error'=>'Request too large'],413);$p=json_decode($raw,true,512,JSON_THROW_ON_ERROR);if(!is_array($p))throw new InvalidArgumentException('Invalid request');$action=(string)($p['action']??'');$allowed=['bootstrap','appointments','detail','analytics','resources','markets','document','typingStart','typingSave','typingLeaderboard','adminData','adminSave'];if(!in_array($action,$allowed,true))dc_reply(['ok'=>false,'error'=>'Unknown action'],400);$params=$p['params']??[];if(!is_array($params))throw new InvalidArgumentException('Invalid parameters');$data=dc_read_rpc($action,$params);if($action==='document')$data['html']=dc_clean_html((string)($data['html']??''));dc_reply(['ok'=>true,'data'=>$data]);
}catch(Throwable $e){$message=$e->getMessage();$status=preg_match('/denied|identity|unauthorized/i',$message)?403:(str_contains($message,'changed')?409:400);dc_reply(['ok'=>false,'error'=>$message],$status);}
