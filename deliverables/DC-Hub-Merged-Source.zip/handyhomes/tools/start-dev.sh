#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Each cloud task is already isolated. Use this checkout; do not create a worktree.
python3 tools/sync_qa.py
mkdir -p /workspace/.dc-runtime
cat > /workspace/qa-site/apache.conf <<'EOF'
<Directory /var/www/html>
Options -Indexes +FollowSymLinks
AllowOverride All
Require all granted
</Directory>
ServerName localhost
EOF
cat /etc/ssl/certs/ca-certificates.crt > /workspace/.dc-runtime/ca-bundle.pem
if [ -n "${CODEX_PROXY_CERT:-}" ] && [ -f "$CODEX_PROXY_CERT" ]; then cat "$CODEX_PROXY_CERT" >> /workspace/.dc-runtime/ca-bundle.pem; fi
cat > /workspace/.dc-runtime/php.ini <<'EOF'
curl.cainfo=/run/session-ca-bundle.pem
openssl.cafile=/run/session-ca-bundle.pem
upload_max_filesize=50M
post_max_size=55M
EOF
if docker container inspect dc-hub-qa >/dev/null 2>&1; then docker stop dc-hub-qa >/dev/null; docker rm dc-hub-qa >/dev/null; fi
docker run -d --name dc-hub-qa -p 127.0.0.1:8080:80 \
 -e 'APACHE_RUN_USER=#1000' -e 'APACHE_RUN_GROUP=#1000' \
 -v /workspace/qa-site:/var/www/html \
 -v /workspace/qa-site/apache.conf:/etc/apache2/conf-enabled/dc-hub.conf:ro \
 -v /workspace/.dc-runtime/ca-bundle.pem:/run/session-ca-bundle.pem:ro \
 -v /workspace/.dc-runtime/php.ini:/usr/local/etc/php/conf.d/dc-hub.ini:ro \
 php@sha256:11093ce0630a495ce9436647d2939b5ca44b411d2a04917afe8b2d051ae2d2ed \
 sh -c 'a2enmod rewrite >/dev/null && apache2-foreground'
