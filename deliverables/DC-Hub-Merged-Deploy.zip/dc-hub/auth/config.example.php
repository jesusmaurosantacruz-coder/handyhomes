<?php
// Existing installations MUST retain their production auth/config.php unchanged.
// For a new installation only: supply existing approved users and password hashes securely.
return [
 'users'=>[], // email => ['id'=>'existing-id','name'=>'Display name']; manager id is jesus
 'password_hash'=>'', // password_hash() output, never a plaintext password
 'manager_password_hash'=>'',
 'session_idle_seconds'=>7200,
];
