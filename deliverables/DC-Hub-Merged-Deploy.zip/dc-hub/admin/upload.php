<?php
declare(strict_types=1);
require_once __DIR__.'/../auth/session.php';
header('Content-Type: application/json');header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');
function upload_reply(int $code,array $data): never{http_response_code($code);echo json_encode($data);exit;}
if(!dc_is_authenticated()||($_SESSION['dc_user_id']??'')!=='jesus'||time()-(int)($_SESSION['dc_editor_unlocked_at']??0)>3600)upload_reply(403,['ok'=>false,'error'=>'Manager unlock required']);
if($_SERVER['REQUEST_METHOD']!=='POST')upload_reply(405,['ok'=>false,'error'=>'POST required']);
if(!dc_csrf_valid((string)($_SERVER['HTTP_X_CSRF_TOKEN']??'')))upload_reply(403,['ok'=>false,'error'=>'Session verification failed']);
$f=$_FILES['media']??null;
if(!is_array($f)||($f['error']??1)!==UPLOAD_ERR_OK)upload_reply(422,['ok'=>false,'error'=>'Upload failed. Check hosting upload_max_filesize and post_max_size.']);
if(!is_int($f['size'])||$f['size']<1||$f['size']>50*1024*1024)upload_reply(413,['ok'=>false,'error'=>'Maximum media size is 50 MB']);
$ext=strtolower(pathinfo((string)$f['name'],PATHINFO_EXTENSION));
$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
$allowed=['mp3'=>['audio/mpeg','audio/mp3'],'mp4'=>['video/mp4']];
if(!isset($allowed[$ext])||!in_array($mime,$allowed[$ext],true))upload_reply(422,['ok'=>false,'error'=>'Only verified MP3 audio or MP4 video files are accepted']);
$name='media-'.bin2hex(random_bytes(12)).'.'.$ext;
if(!move_uploaded_file($f['tmp_name'],__DIR__.'/../training/media/'.$name))upload_reply(500,['ok'=>false,'error'=>'Cannot store media; check folder permissions']);
chmod(__DIR__.'/../training/media/'.$name,0640);
upload_reply(200,['ok'=>true,'file'=>$name]);
