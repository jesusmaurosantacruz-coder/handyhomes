<?php require_once __DIR__.'/../../auth/session.php'; dc_reply(['ok'=>false,'error'=>'Use the consolidated authenticated typing API.'],410);
