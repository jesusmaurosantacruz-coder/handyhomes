<?php
/** Private media stream with byte ranges for seeking. No filesystem path from clients. */
declare(strict_types=1);
require_once __DIR__.'/../auth/session.php';
header('X-Content-Type-Options: nosniff');header('Cache-Control: private, no-store');
if(!dc_is_authenticated()||!dc_permission('training')){http_response_code(401);exit;}
$items=json_decode(file_get_contents(__DIR__.'/../assets/data/media.json'),true)??[];
$item=null;foreach($items as $candidate)if(($candidate['id']??'')===($_GET['id']??'')&&($candidate['visible']??false)){$item=$candidate;break;}
if(!$item||!preg_match('/^[a-z0-9-]+\.(mp3|mp4)$/D',(string)$item['file'])){http_response_code(404);exit;}
$file=__DIR__.'/media/'.$item['file'];if(!is_file($file)){http_response_code(404);exit;}
$size=filesize($file);$start=0;$end=$size-1;
if(isset($_SERVER['HTTP_RANGE'])){
 if(!preg_match('/^bytes=(\d*)-(\d*)$/D',$_SERVER['HTTP_RANGE'],$m)||($m[1]===''&&$m[2]==='')){header("Content-Range: bytes */$size");http_response_code(416);exit;}
 if($m[1]==='')$start=max(0,$size-(int)$m[2]);else{$start=(int)$m[1];if($m[2]!=='')$end=min($end,(int)$m[2]);}
 if($start>$end||$start>=$size){header("Content-Range: bytes */$size");http_response_code(416);exit;}
 http_response_code(206);header("Content-Range: bytes $start-$end/$size");
}
header('Accept-Ranges: bytes');header('Content-Type: '.($item['type']==='audio'?'audio/mpeg':'video/mp4'));header('Content-Length: '.($end-$start+1));
session_write_close();if($_SERVER['REQUEST_METHOD']==='HEAD')exit;
$handle=fopen($file,'rb');fseek($handle,$start);$left=$end-$start+1;
while($left>0&&!feof($handle)&&!connection_aborted()){$data=fread($handle,min(65536,$left));echo $data;$left-=strlen($data);}fclose($handle);
