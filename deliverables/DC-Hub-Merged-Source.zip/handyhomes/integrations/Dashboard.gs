/**

 * HANDY HOMES / DIGITAL CITIZEN OPERATIONS API - FINAL PACKAGE

 * Bound to the SAME project as Code.gs; CRM MASTER remains canonical.

 * Endpoint credentials belong in Apps Script Script Properties, never in this file.

 * Access to this endpoint MUST be proxied through the authenticated Hostinger PHP API.

 */

const DASH = Object.freeze({

  sheetName:'CRM MASTER',

  logName:'CRM_AUDIT_LOG',

  metadata:['CRM Revision','Calendar Sync Status','Calendar Sync Error','Last Synced At','Last Updated','Updated By','Reschedule Count'],

  // Only these existing CRM columns can be modified from this API.

  fields:{

    notes:'Internal Notes',status:'Appointment Status',disposition:'Disposition',

    appointmentDate:'Appointment Date',appointmentTime:'Start Time',

    timezone:'Appointment Time Zone',confirmationStatus:'Confirmation Status',

    followUpStatus:'Follow-Up Status',campaign:'Campaign',partner:'Partner / Company',

    outcomeNotes:'Appointment Outcome Notes',followUpOwner:'Follow-Up Owner',

    followUpDate:'Follow-Up Date',confirmationMethod:'Preferred Confirmation Method',

    neighborOutreach:'Neighbor Outreach Status',rescheduleReason:'Reschedule Reason'

  },

  statuses:['Scheduled','Confirmed','Completed','No Show','Rescheduled','Cancelled','DNQ'],

  dispositions:['Pending Outcome','Closed Won','No Sale','DNQ','Follow Up Needed','Not Interested'],

  confirmations:['Not Started','Attempted','Confirmed','No Answer','Needs Reschedule','Cancelled'],

  followUps:['Not Needed','Pending','In Progress','Waiting on Partner','Completed'],

  neighborStatuses:['Not Required','Eligible','In Progress','Completed']

});

function dashReply_(obj){return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);}

function doGet(e) {
  const leaderboard = dcLeaderboardResponse_(e);
  if (leaderboard) return leaderboard;

  return dashReply_({
    ok: true,
    service: 'DC Eagle Eye CRM API',
    version: '2.2-responsive-saves'
  });
}

function doPost(e){

  try{

    if(!e||!e.postData||!e.postData.contents)throw Error('Missing request body');

    if(e.postData.contents.length>40000)throw Error('Request too large');

    const p=JSON.parse(e.postData.contents);

    if(!p||typeof p!=='object'||Array.isArray(p))throw Error('Invalid request');

    const key=PropertiesService.getScriptProperties().getProperty('DASHBOARD_API_KEY');

    if(!key||typeof p.key!=='string'||p.key!==key)throw Error('Unauthorized');

    if(['update','retrySync'].includes(p.action)){

      if(!p.actor || p.actor.role!=='manager' || !/^[a-z0-9._@+\-]{1,254}$/i.test(String(p.actor.username||p.actor.email||'')))throw Error('An authenticated manager account is required');

    }

    switch(p.action){

      case 'summary':return dashReply_({ok:true,data:dashSummary_(p)});

      case 'search':return dashReply_({ok:true,data:dashSearch_(p)});

      case 'detail':return dashReply_({ok:true,record:dashDetail_(p)});

      case 'update':return dashReply_(dashUpdate_(p));

      case 'retrySync':return dashReply_(dashRetrySync_(p));

      default:throw Error('Unknown action');

    }

  }catch(err){Logger.log('DASH API error: '+String(err));return dashReply_({ok:false,error:String(err.message||err)});}

}

function dashSheet_(){

  // Refer to DC.spreadsheetId; NEVER copy an old spreadsheet ID into this API.

  const sh=SpreadsheetApp.openById(DC.spreadsheetId).getSheetByName(DASH.sheetName);

  if(!sh)throw Error('CRM MASTER tab missing');

  return sh;

}

function dashIndex_(h){

  const m={};h.forEach((n,i)=>{const k=String(n||'').trim().toLowerCase();if(k)m[k]=i;});

  return m;

}

function dashCell_(row,idx,key){const i=idx[String(key).toLowerCase()];return i===undefined?'':String(row[i]??'').trim();}

function dashRows_(){

  const sh=dashSheet_(),grid=sh.getDataRange().getDisplayValues(),head=grid.shift()||[];

  const idx=dashIndex_(head);

  for(const required of ['Record Type','Lead ID','Form Submission Key','Appointment Date','Start Time','Appointment Time Zone','Appointment Status','Calendar Event ID','Agent Calendar Event ID'])

    if(idx[required.toLowerCase()]===undefined)throw Error('Missing CRM header: '+required);

  const records=grid.map((values,i)=>({values,row:i+2})).filter(x=>

    dashCell_(x.values,idx,'Lead ID')&&dashCell_(x.values,idx,'Record Type').toLowerCase()==='appointment');

  return {sh,head,idx,records};

}

function dashDate_(input){

  let s=String(input||'').trim();let m=s.match(/^(\d{4})-(\d{2})-(\d{2})$/);

  if(!m){m=s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);if(!m)return '';s=m[3]+'-'+m[1].padStart(2,'0')+'-'+m[2].padStart(2,'0');}

  const d=new Date(s+'T12:00:00Z');return Number.isFinite(d.getTime())&&d.toISOString().slice(0,10)===s?s:'';

}

function dashTime_(s){

  s=String(s||'').trim().toUpperCase();let m=s.match(/^(\d{1,2}):(\d{2})(?::\d{2})?\s*(AM|PM)?$/);

  if(!m)return '';

  let h=Number(m[1]),minute=Number(m[2]);if(m[3]){if(h<1||h>12)return '';h=h%12+(m[3]==='PM'?12:0);}

  if(h>23||minute>59)return '';return String(h).padStart(2,'0')+':'+String(minute).padStart(2,'0');

}

function dashKey_(rec,idx){

  return dashCell_(rec.values,idx,'Form Submission Key')||'legacy:'+rec.row+':'+dashCell_(rec.values,idx,'Lead ID');

}

function dashFingerprint_(g,r){

  return Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,JSON.stringify([g.head,r.values]),Utilities.Charset.UTF_8));

}

function dashSyncStatus_(value){

  const s=String(value||'');

  if(/^error\b/i.test(s))return 'Error';

  if(/^synced\b/i.test(s))return 'Synced';

  if(/^pending\b/i.test(s))return 'Pending';

  if(/^not linked/i.test(s))return 'Not Linked';

  return s||'Not Checked';

}

function dashBrief_(rec,idx){

  const get=k=>dashCell_(rec.values,idx,k);

  const date=dashDate_(get('Appointment Date'));

  return {

    id:get('Lead ID'),recordKey:dashKey_(rec,idx),

    name:[get('First Name'),get('Last Name')].filter(Boolean).join(' '),

    agent:get('Setter Name'),campaign:get('Campaign'),partner:get('Partner / Company'),

    status:get('Appointment Status'),confirmationStatus:get('Confirmation Status'),

    followUpStatus:get('Follow-Up Status'),neighborOutreach:get('Neighbor Outreach Status'),disposition:get('Disposition'),

    appointmentDate:date,appointmentTime:dashTime_(get('Start Time')),timezone:get('Appointment Time Zone'),

    city:get('City'),state:get('State'),

    submittedAt:dashDate_((get('Submission Timestamp')||get('Created At')).split(' ')[0]),

    version:Number(get('CRM Revision')||0),syncStatus:dashSyncStatus_(get('Calendar Sync Status'))

  };

}

function dashFind_(g,p){

  const key=String(p.recordKey||'').trim(),id=String(p.id||'').trim();

  if(!key&&!id)throw Error('Missing appointment identifier');

  const matches=g.records.filter(r=>{

    if(key)return dashKey_(r,g.idx)===key && (!id||dashCell_(r.values,g.idx,'Lead ID')===id);

    return dashCell_(r.values,g.idx,'Lead ID')===id;

  });

  if(matches.length!==1)throw Error(matches.length?'Ambiguous appointment; refresh and select exact record':'Appointment not found');

  return matches[0];

}

function dashPeriod_(p,today){

  const period=String(p.period||'today');const parsed=new Date(today+'T12:00:00Z');

  const iso=d=>d.toISOString().slice(0,10),shift=(date,n)=>{const x=new Date(date);x.setUTCDate(x.getUTCDate()+n);return x;};

  if(period==='custom'){

    const from=dashDate_(p.from),to=dashDate_(p.to);if(!from||!to||from>to)throw Error('Invalid custom period');return [from,to];

  }

  if(period==='yesterday'){const t=iso(shift(parsed,-1));return [t,t];}

  if(period==='tomorrow'){const t=iso(shift(parsed,1));return [t,t];}

  const weekday=(parsed.getUTCDay()+6)%7;

  if(period==='week'){const mon=shift(parsed,-weekday);return [iso(mon),iso(shift(mon,6))];}

  if(period==='lastweek'){const mon=shift(parsed,-weekday-7);return [iso(mon),iso(shift(mon,6))];}

  if(period==='month')return [today.slice(0,7)+'-01',today];

  return [today,today];

}

function dashSummary_(p){

  const g=dashRows_(),today=Utilities.formatDate(new Date(),'America/Mexico_City','yyyy-MM-dd');

  const [from,to]=dashPeriod_(p,today);

  const records=g.records.map(x=>dashBrief_(x,g.idx));

  const relevant=records.filter(r=>(!p.agent||r.agent===p.agent)&&(!p.campaign||r.campaign===p.campaign));

  const submitted=relevant.filter(r=>r.submittedAt>=from&&r.submittedAt<=to);

  const booked=relevant.filter(r=>r.appointmentDate>=from&&r.appointmentDate<=to);

  const count=(arr,key,value)=>arr.filter(r=>r[key]===value).length;

  const agg=key=>Object.entries(submitted.reduce((a,r)=>{const k=r[key]||'Unassigned';a[k]=(a[k]||0)+1;return a;},{})).sort((a,b)=>b[1]-a[1]).slice(0,20);

  const upcoming=relevant.filter(r=>r.appointmentDate>=today&&!['Cancelled','Completed','DNQ','No Show'].includes(r.status)).sort((a,b)=>(a.appointmentDate+' '+a.appointmentTime).localeCompare(b.appointmentDate+' '+b.appointmentTime));

  const pending=upcoming.filter(r=>r.confirmationStatus!=='Confirmed'&&r.status!=='Confirmed');
  const pendingOutcomes=relevant.filter(r=>dashPendingOutcome_(r,today)).length;
  const stateCounts=submitted.reduce((a,r)=>{const state=dashState_(r.state);a[state]=(a[state]||0)+1;return a;},{});
  const stateStats=Object.entries(stateCounts).sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));

  return {today,from,to,totals:{set:submitted.length,scheduledToday:count(relevant,'appointmentDate',today),confirmed:booked.filter(r=>r.status==='Confirmed'||r.confirmationStatus==='Confirmed').length,completed:count(booked,'status','Completed'),noShows:count(booked,'status','No Show'),closed:count(booked,'disposition','Closed Won'),pendingConfirmation:pending.length,pendingOutcomes,syncErrors:relevant.filter(r=>r.syncStatus==='Error').length},agents:[...new Set(records.map(r=>r.agent).filter(Boolean))].sort(),campaigns:[...new Set(records.map(r=>r.campaign).filter(Boolean))].sort(),leaderboard:agg('agent'),stateStats,statuses:DASH.statuses.map(k=>[k,count(booked,'status',k)]),outcomes:DASH.dispositions.map(k=>[k,count(booked,'disposition',k)]),upcoming:upcoming.slice(0,12)};

}

function dashState_(value){
  const state=String(value||'').trim().toUpperCase().replace(/\./g,'');
  const names=['Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut','Delaware','District of Columbia','Florida','Georgia','Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana','Maine','Maryland','Massachusetts','Michigan','Minnesota','Mississippi','Missouri','Montana','Nebraska','Nevada','New Hampshire','New Jersey','New Mexico','New York','North Carolina','North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania','Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont','Virginia','Washington','West Virginia','Wisconsin','Wyoming'];
  const codes='AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY'.split(' ');
  const i=names.findIndex(n=>n.toUpperCase()===state);
  return i>=0?codes[i]:state||'Unknown state';
}

function dashPendingOutcome_(record,today){
  if(['Cancelled','DNQ'].includes(record.status)||!['','Pending Outcome'].includes(record.disposition))return false;
  const date=dashDate_(record.appointmentDate);
  if(!date)return false;
  const time=dashTime_(record.appointmentTime);
  if(!time)return date<today;
  try{
    const start=Utilities.parseDate(date+' '+time,record.timezone||DC.defaultZone,'yyyy-MM-dd HH:mm');
    return start.getTime()+(DC.durationMinutes||60)*60000<=Date.now();
  }catch(e){return date<today;}
}

function dashSearch_(p){

  const g=dashRows_(),q=String(p.query||'').toLowerCase().trim().slice(0,120),filters={agent:String(p.agent||''),campaign:String(p.campaign||''),status:String(p.status||'')};

  const today=Utilities.formatDate(new Date(),'America/Mexico_City','yyyy-MM-dd');
  const disposition=String(p.disposition||''),confirmation=String(p.confirmation||'');
  const workQueue=String(p.workQueue||'');
  if(workQueue&&!['pendingOutcome'].includes(workQueue))throw Error('Invalid work queue');
  const dateFilter=String(p.dateFilter||'all'),dateBasis=String(p.dateBasis||'appointment');
  if(!['all','today','tomorrow','upcoming','next7','custom'].includes(dateFilter))throw Error('Invalid appointment date filter');
  if(!['appointment','submission'].includes(dateBasis))throw Error('Invalid appointment date basis');
  if(disposition&&disposition!=='unset'&&!DASH.dispositions.includes(disposition))throw Error('Invalid disposition filter');
  if(confirmation&&!['pending',...DASH.confirmations].includes(confirmation))throw Error('Invalid confirmation filter');
  const shift=n=>{const d=new Date(today+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);};
  let from='',to='';
  if(dateFilter==='today'){from=today;to=today;}
  if(dateFilter==='tomorrow'){from=shift(1);to=from;}
  if(dateFilter==='upcoming')from=today;
  if(dateFilter==='next7'){from=today;to=shift(6);}
  if(dateFilter==='custom'){
    from=dashDate_(p.dateFrom);to=dashDate_(p.dateTo);
    if(!from||!to||from>to)throw Error('Choose a valid start and end date');
  }
  const rows=g.records.map(r=>({source:r,b:dashBrief_(r,g.idx)})).filter(x=>{
    const b=x.b,date=dateBasis==='submission'?b.submittedAt:b.appointmentDate;
    if(workQueue==='pendingOutcome'&&!dashPendingOutcome_(b,today))return false;
    if(filters.agent&&b.agent!==filters.agent||filters.campaign&&b.campaign!==filters.campaign||filters.status&&b.status!==filters.status)return false;
    if(disposition&&(disposition==='unset'?!!b.disposition:b.disposition!==disposition))return false;
    if(from&&(!date||date<from)||to&&(!date||date>to))return false;
    if(confirmation==='pending'){
      if(['Cancelled','Completed','DNQ','No Show'].includes(b.status)||b.confirmationStatus==='Confirmed'||b.status==='Confirmed')return false;
    }else if(confirmation&&b.confirmationStatus!==confirmation)return false;
    return true;
  });

  const scoring=x=>{

    if(!q)return 1;const b=x.b,v=n=>dashCell_(x.source.values,g.idx,n).toLowerCase();const phone=v('Phone Number').replace(/\D/g,''),digits=q.replace(/\D/g,'');

    if(b.id.toLowerCase()===q||b.recordKey.toLowerCase()===q)return 1000;

    if(digits.length>=4&&phone.includes(digits))return 850;

    if(b.name.toLowerCase().includes(q))return 650;

    if(b.id.toLowerCase().includes(q))return 700;

    if([b.agent,b.campaign,b.partner,b.city,b.state].some(n=>String(n).toLowerCase().includes(q)))return 300;

    return 0;

  };

  const sorted=rows.map(x=>({...x,score:scoring(x)})).filter(x=>x.score>0).sort((a,b)=>{

    if(q)return b.score-a.score;
    if(workQueue==='pendingOutcome')return (a.b.appointmentDate+' '+a.b.appointmentTime).localeCompare(b.b.appointmentDate+' '+b.b.appointmentTime);

    const upcomingA=a.b.appointmentDate>=today,upcomingB=b.b.appointmentDate>=today;

    if(upcomingA!==upcomingB)return upcomingA?-1:1;

    const cmp=(a.b.appointmentDate+' '+a.b.appointmentTime).localeCompare(b.b.appointmentDate+' '+b.b.appointmentTime);

    return upcomingA?cmp:-cmp;

  });

  const limit=Math.min(50,Math.max(1,Number(p.limit)||25)),offset=Math.max(0,Math.min(100000,Number(p.offset)||0));

  return {items:sorted.slice(offset,offset+limit).map(x=>x.b),total:sorted.length,offset,limit,filterVersion:1,today,dateFilter,dateBasis};

}

function dashDetail_(p){

  const g=dashRows_(),r=dashFind_(g,p),v=n=>dashCell_(r.values,g.idx,n);

  return {...dashBrief_(r,g.idx),phone:v('Phone Number'),email:v('Email'),street:v('Street Address'),zip:v('ZIP Code'),utility:v('Utility Provider'),highestBill:v('Highest Electric Bill'),lowestBill:v('Lowest Electric Bill'),credit:v('Credit Qualification'),approximateCredit:v('Approximate Credit Score'),qualificationNotes:v('Qualification Notes'),appointmentReason:v('Appointment Reason'),notes:v('Internal Notes'),outcomeNotes:v('Appointment Outcome Notes'),followUpOwner:v('Follow-Up Owner'),followUpDate:v('Follow-Up Date'),confirmationMethod:v('Preferred Confirmation Method'),neighborOutreach:v('Neighbor Outreach Status'),rescheduleReason:v('Reschedule Reason'),syncError:v('Calendar Sync Error'),lastUpdated:v('Last Updated'),fingerprint:dashFingerprint_(g,r),calendarName:v('Calendar Name'),calendarMatchStatus:v('Calendar Match Status'),hasCalendarLink:!!(v('Calendar API Event ID')||v('Calendar Event ID')),allDay:v('Linked Event All Day').toLowerCase()==='true',editableFields:Object.keys(DASH.fields).filter(k=>g.idx[DASH.fields[k].toLowerCase()]!==undefined)};

}

function dashEnsureMetadata_(sh){

  // Append only. Existing column order and Calendar event IDs remain unchanged.

  let h=dcHeaders_(sh);

  const missing=DASH.metadata.filter(k=>!h.some(x=>dcNorm_(x)===dcNorm_(k)));

  if(missing.length){

    const last=sh.getLastColumn();

    if(last+missing.length>sh.getMaxColumns())sh.insertColumnsAfter(sh.getMaxColumns(),last+missing.length-sh.getMaxColumns());

    sh.getRange(1,last+1,1,missing.length).setValues([missing]);

    h=dcHeaders_(sh);

  }

  return h;

}

function dashAudit_(id,recordKey,changes,previous,revision,actor){

  const ss=SpreadsheetApp.openById(DC.spreadsheetId);

  let log=ss.getSheetByName(DASH.logName);

  if(!log){log=ss.insertSheet(DASH.logName);log.appendRow(['Timestamp','Lead ID','Form Submission Key','Actor','Revision','Changes (JSON)','Previous values (JSON)']);}

  log.appendRow([new Date(),id,recordKey,actor&&(actor.username||actor.email)?String(actor.username||actor.email).toLowerCase():'Owner script invocation',revision,JSON.stringify(changes),JSON.stringify(previous)]);

}

function dashValidateSchedule_(date,time,zone){

  if(!dashDate_(date)||dashDate_(date)!==date)throw Error('Date must be a real YYYY-MM-DD calendar date');

  if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))throw Error('Time must be HH:mm (24 hour)');

  if(!DC.zones.includes(zone))throw Error('Unsupported appointment time zone');

  const start=Utilities.parseDate(date+' '+time,zone,'yyyy-MM-dd HH:mm');

  const wall=date+' '+time;

  if(Utilities.formatDate(start,zone,'yyyy-MM-dd HH:mm')!==wall)throw Error('Nonexistent local appointment time (DST)');

  // Refuse repeated fall-back clock times when no explicit UTC offset is supplied.

  const before=new Date(start.getTime()-60*60000),after=new Date(start.getTime()+60*60000);

  if(Utilities.formatDate(before,zone,'yyyy-MM-dd HH:mm')===wall||Utilities.formatDate(after,zone,'yyyy-MM-dd HH:mm')===wall)

    throw Error('Ambiguous daylight saving time: select an unambiguous appointment time');

}

function dashValidateChanges_(changes,g,r){

  if(!changes||typeof changes!=='object'||Array.isArray(changes)||!Object.keys(changes).length)throw Error('No changes to save');

  const normalized={};

  for(const [k,raw] of Object.entries(changes)){

    if(!Object.prototype.hasOwnProperty.call(DASH.fields,k))throw Error('Field is not editable: '+k);

    if(raw===null||typeof raw==='object')throw Error('Invalid value type: '+k);

    const v=String(raw).trim();if(v.length>6000)throw Error('Value is too long: '+k);

    if(g.idx[DASH.fields[k].toLowerCase()]===undefined)throw Error('Missing CRM column: '+DASH.fields[k]);

    if(k==='status'&&!DASH.statuses.includes(v))throw Error('Invalid appointment status');

    if(k==='disposition'&&v&&!DASH.dispositions.includes(v))throw Error('Invalid disposition');

    if(k==='confirmationStatus'&&v&&!DASH.confirmations.includes(v))throw Error('Invalid confirmation status');

    if(k==='followUpStatus'&&v&&!DASH.followUps.includes(v))throw Error('Invalid follow-up status');

    if(k==='neighborOutreach'&&v&&!DASH.neighborStatuses.includes(v))throw Error('Invalid neighbor outreach status');

    if(['notes','outcomeNotes'].includes(k)&&v.length>3000)throw Error('Note exceeds 3000 characters');

    if(['campaign','partner','followUpOwner','confirmationMethod','rescheduleReason'].includes(k)&&v.length>150)throw Error('Field exceeds 150 characters');

    if(k==='followUpDate'&&v&&!dashDate_(v))throw Error('Invalid follow-up date');

    normalized[k]=v;

  }

  const get=(n)=>dashCell_(r.values,g.idx,n);

  const date=normalized.appointmentDate!==undefined?normalized.appointmentDate:dashDate_(get('Appointment Date'));

  const time=normalized.appointmentTime!==undefined?normalized.appointmentTime:dashTime_(get('Start Time'));

  const zone=normalized.timezone!==undefined?normalized.timezone:get('Appointment Time Zone')||DC.defaultZone;

  if(['appointmentDate','appointmentTime','timezone'].some(k=>Object.prototype.hasOwnProperty.call(normalized,k))){

    if(get('Linked Event All Day').toLowerCase()==='true'){

      if(normalized.appointmentTime!==undefined && normalized.appointmentTime!==get('Start Time'))throw Error('All-day appointment: edit its date only');

      if(!dashDate_(date)||dashDate_(date)!==date)throw Error('Invalid appointment date');

      if(normalized.timezone!==undefined&&!DC.zones.includes(zone))throw Error('Unsupported appointment time zone');

    }else dashValidateSchedule_(date,time,zone);

  }

  return normalized;

}

function dashSync_(sh,h,row){

  const errors=[],apiId=dcGetOptional_(sh,h,row,'Calendar API Event ID');

  try {dcEnsureFormPrimary_(sh,h,row);} catch(e) {

    dcCell_(sh,h,row,'Calendar Sync Status').setValue('Error');

    dcCell_(sh,h,row,'Calendar Sync Error').setValue(e.message);

    return {errors:[e.message],calendarSynced:false,message:'CRM saved; Calendar sync needs attention: '+e.message};

  }

  const legacyId=dcGet_(sh,h,row,'Calendar Event ID');

  const agentId=dcGet_(sh,h,row,'Agent Calendar Event ID');

  if(!apiId&&!legacyId){

    dcCell_(sh,h,row,'Calendar Sync Status').setValue('Not Linked');

    dcCell_(sh,h,row,'Calendar Sync Error').setValue('');

    return {errors,calendarSynced:false,message:'CRM saved. This appointment has no linked Calendar event.'};

  }

  let primarySynced=false;

  try{dcSync_(sh,h,row);primarySynced=true;}catch(e){errors.push('Linked Calendar: '+e.message);}

  // Imported API-linked rows intentionally have no extra agent tracker.

  if(primarySynced && (agentId||!apiId)){

    try{dcAgentSync_(sh,h,row);if(!dcGet_(sh,h,row,'Agent Calendar Event ID'))errors.push('Agent tracker: event ID missing');}

    catch(e){errors.push('Agent tracker: '+e.message);}

  }

  dcCell_(sh,h,row,'Calendar Sync Status').setValue(errors.length?'Error':'Synced');

  dcCell_(sh,h,row,'Calendar Sync Error').setValue(errors.join(' | '));

  if(!errors.length)dcCell_(sh,h,row,'Last Synced At').setValue(new Date());

  return {errors,calendarSynced:!errors.length,message:errors.length?'CRM saved; Calendar sync needs attention: '+errors.join(' | '):'CRM and linked Calendar synchronized.'};

}

function dashUpdate_(p){

  const lock=LockService.getScriptLock();lock.waitLock(30000);

  try{

    const sh=dashSheet_();

    const g=dashRows_(),r=dashFind_(g,p),version=Number(dashCell_(r.values,g.idx,'CRM Revision')||0);

    if(p.expectedVersion===undefined||p.expectedVersion===null||!Number.isInteger(Number(p.expectedVersion)))throw Error('Missing expected record version');

    if(Number(p.expectedVersion)!==version)throw Error('Record changed since it was opened. Refresh and retry.');

    if(!p.expectedFingerprint)throw Error('Update the website files and reopen this appointment before saving');

    if(p.expectedFingerprint!==dashFingerprint_(g,r))throw Error('Record changed since it was opened. Refresh and retry.');

    const input=dashValidateChanges_(p.changes,g,r),previous={},changes={};

    for(const [k,v] of Object.entries(input)){

      const col=DASH.fields[k],old=dashCell_(r.values,g.idx,col);

      if(old!==v){changes[k]=v;previous[k]=old;}

    }

    if(!Object.keys(changes).length)return {ok:true,saved:false,noChange:true,calendarSynced:dashSyncStatus_(dashCell_(r.values,g.idx,'Calendar Sync Status'))==='Synced',calendarMessage:'No changes to save.',version};

    const apiId=dashCell_(r.values,g.idx,'Calendar API Event ID');

    if(['appointmentDate','appointmentTime','timezone'].some(k=>k in changes)){

      if(!apiId&&!dashCell_(r.values,g.idx,'Calendar Event ID')&&!/:form-row:\d+$/.test(dashKey_(r,g.idx)))throw Error('Link this appointment in CRM MASTER before rescheduling');

      if(apiId)dcLinkedApiEvent_(sh,g.head,r.row,apiId);

    }

    const h=dashEnsureMetadata_(sh);

    for(const [k,v] of Object.entries(changes)){

      const cell=dcCell_(sh,h,r.row,DASH.fields[k]);

      if(['appointmentDate','appointmentTime','timezone','followUpDate'].includes(k))cell.setNumberFormat('@');

      cell.setValue(dcSafe_(v));

    }

    const newVersion=version+1;

    dcCell_(sh,h,r.row,'CRM Revision').setValue(newVersion);

    dcCell_(sh,h,r.row,'Calendar Sync Status').setValue('Pending');

    dcCell_(sh,h,r.row,'Calendar Sync Error').setValue('');

    dcCell_(sh,h,r.row,'Last Updated').setValue(new Date());

    dcCell_(sh,h,r.row,'Updated By').setValue(dcSafe_(String(p.actor.username||p.actor.email)));

    if(['appointmentDate','appointmentTime','timezone'].some(k=>k in changes))

      dcCell_(sh,h,r.row,'Reschedule Count').setValue(Number(dashCell_(r.values,g.idx,'Reschedule Count')||0)+1);

    SpreadsheetApp.flush();

    let auditError='';try{dashAudit_(dashCell_(r.values,g.idx,'Lead ID'),dashKey_(r,g.idx),changes,previous,newVersion,p.actor);}catch(e){auditError=e.message;Logger.log('Audit failure: '+auditError);}

    const result=dashSync_(sh,h,r.row);

    // dcSync_ updates Last Updated itself; CRM Revision remains authoritative for concurrency.

    SpreadsheetApp.flush();

    return {ok:true,saved:true,version:newVersion,calendarSynced:result.calendarSynced,calendarErrors:result.errors,calendarMessage:result.message,auditWarning:auditError||undefined};

  }finally{lock.releaseLock();}

}

function dashRetrySync_(p){

  const lock=LockService.getScriptLock();lock.waitLock(30000);

  try{

    const sh=dashSheet_(),h=dashEnsureMetadata_(sh),g=dashRows_(),r=dashFind_(g,p);

    // Retry is idempotent because calendar IDs persist in CRM MASTER.

    const result=dashSync_(sh,h,r.row);SpreadsheetApp.flush();

    return {ok:true,saved:false,calendarSynced:result.calendarSynced,calendarErrors:result.errors,calendarMessage:result.message};

  }finally{lock.releaseLock();}

}

/** OPTIONAL read-only diagnostic: select dashboardHealthCheck in Apps Script and click Run.

 * It checks access and headers; it does not create or edit calendar appointments.

 */

function dashboardHealthCheck(){

  const sh=dashSheet_(),h=dcHeaders_(sh),missing=[];

  for(const k of ['Record Type','Lead ID','Form Submission Key','Calendar Event ID','Agent Calendar Event ID','Appointment Date','Start Time','Appointment Time Zone','Appointment Status','Setter Name','Setter Email'])

    if(!h.some(x=>dcNorm_(x)===dcNorm_(k)))missing.push(k);

  const primary=!!CalendarApp.getCalendarById(DC.calendarId);

  const agent=!!CalendarApp.getCalendarById(DC.agentCalendarId);

  const triggers=ScriptApp.getProjectTriggers().map(t=>t.getHandlerFunction());

  const selectedCalendars=(typeof DC_ALLOWED_CALENDARS!=='undefined'?DC_ALLOWED_CALENDARS:[DC.calendarId]).map(id=>{try{const c=CalendarApp.getCalendarById(id);return {id,accessible:!!c};}catch(e){return {id,accessible:false};}});

  const result={calendarApiEnabled:typeof Calendar!=='undefined',selectedCalendars,sheet:sh.getName(),rows:sh.getLastRow(),missingHeaders:missing,closersAccessible:primary,agentAccessible:agent,hasFormTrigger:triggers.includes('onFormSubmit'),hasCrmEditTrigger:triggers.includes('onCrmEdit'),hasRetryTrigger:triggers.includes('retryPendingCalendarSync'),formTabFound:!!dcSs_().getSheetByName(DC.formTab),dashboardApiKeyConfigured:!!PropertiesService.getScriptProperties().getProperty('DASHBOARD_API_KEY')};

  Logger.log(JSON.stringify(result));return result;

}



/** Run once after pasting both files. Adds missing management columns only;

 * keeps every existing row, column position, event ID, and source response. */

function setupDashboard() {

  const sh=dashSheet_();

  const lock=LockService.getScriptLock();lock.waitLock(30000);

  try {

    dashEnsureMetadata_(sh);

    const h=dcHeaders_(sh),missing=Object.values(DASH.fields).filter(n=>!h.some(x=>dcNorm_(x)===dcNorm_(n)));

    if(missing.length) {

      const end=sh.getLastColumn();

      if(end+missing.length>sh.getMaxColumns())sh.insertColumnsAfter(sh.getMaxColumns(),end+missing.length-sh.getMaxColumns());

      sh.getRange(1,end+1,1,missing.length).setValues([missing]);

    }

    SpreadsheetApp.flush();

  } finally {lock.releaseLock();}

  setupTriggers();

  return dashboardHealthCheck();

}
