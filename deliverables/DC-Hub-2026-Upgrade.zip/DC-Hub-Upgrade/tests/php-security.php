<?php
require __DIR__.'/../hostinger/dc-hub/auth/content.php';
$checks=[];
function check_test($name,$ok){global $checks;if(!$ok)throw new RuntimeException($name);$checks[]=$name;echo 'PASS '.$name."\n";}
$dirty='<p onclick="alert(1)" style="position:fixed;color:rgb(0,0,255);background-image:url(https://bad.test)">Safe<script>alert(1)</script><a href="javascript:alert(1)">bad</a><img src="https://bad.test/a" onerror="alert(1)"></p>';
$clean=dc_clean_html($dirty);
check_test('Rich text removes executable markup',!str_contains($clean,'<script')&&!str_contains($clean,'onclick')&&!str_contains($clean,'onerror'));
check_test('CSS allowlist preserves color and rejects positioned or external styling',str_contains($clean,'color:#0000ff')&&!str_contains($clean,'position:')&&!str_contains($clean,'background-image'));
check_test('Unsafe links removed',!str_contains($clean,'javascript:'));
check_test('Unapproved remote images removed',!str_contains($clean,'src="https://bad.test'));
$doc='<html><head><style>.c1{font-weight:700;color:#ff0000;position:fixed}</style></head><body><h2>Market</h2><p><span class="c1">Emphasis</span></p><table><tr><td colspan="2">Value</td></tr></table><img src="https://lh3.googleusercontent.com/reference" alt="Reference"></body></html>';
$clean=dc_clean_html($doc);
check_test('Google Docs class formatting is preserved safely',str_contains($clean,'font-weight:700')&&str_contains($clean,'color:#ff0000')&&!str_contains($clean,'position:fixed'));
check_test('Google Docs structure and image preserved',str_contains($clean,'<h2>Market</h2>')&&str_contains($clean,'colspan="2"')&&str_contains($clean,'https://lh3.googleusercontent.com/reference'));
$count=0;
foreach(glob(__DIR__.'/../hostinger/dc-hub/assets/scripts/*.html') as $file){$raw=file_get_contents($file);$safe=dc_clean_html($raw);$text=static function($html){$d=new DOMDocument();@$d->loadHTML('<?xml encoding="UTF-8"><html><body>'.$html.'</body></html>',LIBXML_NONET);return $d->getElementsByTagName('body')->item(0)->textContent;};if($text($raw)!==$text($safe))throw new RuntimeException('Script text lost: '.basename($file));$count++;}
check_test('All '.$count.' supplied script texts survive sanitization',true);
file_put_contents(__DIR__.'/php-results.json',json_encode(['passed'=>count($checks),'checks'=>$checks],JSON_PRETTY_PRINT));
