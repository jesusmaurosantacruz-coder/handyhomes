/* Five-character words. Accuracy counts insertion attempts; corrections retain prior mistakes. */
(function(scope){'use strict';
function metrics({text,passage,keys,errors,elapsed,seconds}){const time=Math.max(0,Math.min(seconds,elapsed));let remainingErrors=0;for(let i=0;i<text.length;i++)if(text[i]!==passage[i])remainingErrors++;return {elapsed:time,grossWpm:time?Math.round(text.length/5/(time/60)):0,wpm:time?Math.max(0,Math.round((text.length/5-remainingErrors)/(time/60))):0,accuracy:keys?Math.round(1000*(keys-errors)/keys)/10:100,errors,remainingErrors,characters:text.length};}
function inserted(previous,current){let start=0;while(start<previous.length&&start<current.length&&previous[start]===current[start])start++;let end=0;while(end<previous.length-start&&end<current.length-start&&previous[previous.length-1-end]===current[current.length-1-end])end++;return {start,text:current.slice(start,current.length-end)};}
const engine={metrics,inserted};if(typeof module!=='undefined'&&module.exports)module.exports=engine;else scope.DCTypingEngine=engine;
})(typeof window!=='undefined'?window:globalThis);
