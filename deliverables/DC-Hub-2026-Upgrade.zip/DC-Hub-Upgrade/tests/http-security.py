"""Real Apache/PHP access checks with CLI-seeded local sessions; never OAuth bypass in app."""
import json,os,subprocess,tempfile,urllib.request,urllib.error
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];BASE='http://127.0.0.1:8081/dc-hub/';checks=[]
def check(name,ok):
 assert ok,name
 checks.append(name);print('PASS '+name,flush=True)
def request(path,cookie='',data=None,headers=None):
 h={'Cookie':'DC_HUB_V3='+cookie} if cookie else {}
 h.update(headers or {})
 try:
  with urllib.request.urlopen(urllib.request.Request(BASE+path,data=data,headers=h)) as r:return r.status,r.headers,r.read()
 except urllib.error.HTTPError as e:return e.code,e.headers,e.read()
with tempfile.NamedTemporaryFile(suffix='.php',prefix='hub-private-',delete=False) as f:
 config=f.name;f.write(b"<?php return ['google_client_id'=>'fixture.apps.googleusercontent.com','session_idle_seconds'=>3600];")
try:
 subprocess.run(['bash','tools/start-local.sh'],cwd=ROOT,env={**os.environ,'HUB_CONFIG_FILE':config},check=True)
 # Create session state via CLI only. No testing switch exists in HTTP application.
 def seed(sid,permission):
  profile={'name':'Local Test','email':'test@example.test','role':'Agent','permissions':permission}
  code="session_name('DC_HUB_V3');session_id('"+sid+"');session_start();$_SESSION=['dc_user_id'=>'fixture-sub','dc_user_email'=>'test@example.test','dc_last_active'=>time(),'dc_profile_checked'=>time(),'dc_profile'=>json_decode('"+json.dumps(profile)+"',true),'dc_csrf'=>'fixture-csrf'];session_write_close();"
  subprocess.run(['docker','exec','dc-hub-upgrade-qa','php','-r',code],check=True)
 sid='localtestsessionabcdefghijklmnop';seed(sid,['resources','dashboard','appointments','calendar'])
 for path in ['assets/data/markets/texas.json','assets/data/library.json']:
  check('Anonymous local data denied '+path,request(path)[0]==401)
  status,h,body=request(path,sid);check('Authenticated local data served '+path,status==200 and bool(json.loads(body)))
  check('Static cache is private and conditional '+path,'private' in h['Cache-Control'] and bool(h['ETag']))
  check('Conditional request honors ETag '+path,request(path,sid,headers={'If-None-Match':h['ETag']})[0]==304)
 for action in ['update','retrySync','syncForms']:
  status,h,body=request('api/hub.php',sid,json.dumps({'action':action,'params':{'id':'anything','role':'Admin'}}).encode(),{'Content-Type':'application/json','X-CSRF-Token':'fixture-csrf'})
  check('Authenticated PHP rejects write action '+action,status==400 and json.loads(body)['error']=='Unknown action')
  check('API responses never publicly cached '+action,'no-store' in h['Cache-Control'])
 check('Forged role cannot bypass login',request('api/hub.php?role=Admin',data=b'{"action":"detail"}')[0]==401)
 check('CSRF protects authenticated API',request('api/hub.php',sid,b'{"action":"appointments"}',{'Content-Type':'application/json'})[0]==403)
 seed(sid,[]);check('Cached static content still checks role',request('assets/data/markets/texas.json',sid)[0]==403)
 seed(sid,['resources']);check('Path traversal is denied',request('auth/serve.php?file=../../../../etc/passwd',sid)[0]==404)
 (ROOT/'tests/http-results.json').write_text(json.dumps({'passed':len(checks),'checks':checks,'scope':'Actual local Apache/PHP with CLI-created synthetic session state; no live OAuth or Workspace'},indent=2))
finally:
 # Restore the ordinary unconfigured local startup, removing the mounted fixture.
 subprocess.run(['bash','tools/start-local.sh'],cwd=ROOT,env={k:v for k,v in os.environ.items() if k!='HUB_CONFIG_FILE'},check=True)
 Path(config).unlink(missing_ok=True)
