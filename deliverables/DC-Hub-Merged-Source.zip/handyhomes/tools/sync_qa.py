"""Copy application to an isolated local QA tree; never copy production credentials."""
from pathlib import Path
import shutil
r=Path(__file__).resolve().parents[1];q=Path('/workspace/qa-site/dc-hub');q.mkdir(parents=True,exist_ok=True)
for source in r.rglob('*'):
 if source.is_file() and source.name not in ['config.php','typing-config.php'] and not any(x in source.parts for x in ['.git','backups','source-documents','__pycache__']):
  target=q/source.relative_to(r)
  if target.is_file():target.unlink()
shutil.copytree(r,q,dirs_exist_ok=True,ignore=shutil.ignore_patterns('.git','config.php','typing-config.php','backups','source-documents','__pycache__'))
(q/'auth/config.php').write_text("<?php return ['users'=>['agent@example.test'=>['id'=>'agent','name'=>'Test Agent'],'manager@example.test'=>['id'=>'jesus','name'=>'Test Manager']],'password_hash'=>password_hash('Local-test-pass-2026', PASSWORD_DEFAULT),'manager_password_hash'=>password_hash('Local-editor-pass-2026',PASSWORD_DEFAULT),'session_idle_seconds'=>7200];")
