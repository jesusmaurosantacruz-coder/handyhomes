# QA report — October 29, 2026

## Scope and results

Local development acceptance on the merged source, not a live Hostinger deployment. PHP 8.3 / Apache 2.4 in the official image pinned by SHA-256; Chromium with Python Playwright. The server used an isolated copy at `/workspace/qa-site/dc-hub` with test-only credentials; source production credentials were never replaced. Test media were generated sine/color fixtures and are not bundled as training content.

- **111 browser functional checks passed** (`tests/functional.py`): anonymous page/data/private-path gates; login/logout; agent/manager separation; elevated editor unlock; CSRF; dashboard data and resource modals; all primary retained/new routes; all 10 visible campaigns (11 total including preserved hidden Pennsylvania Roofing); script/notes loading and form mappings; exact DOCX colors/shading on white; independent scrolling; 1366/1920/390px widths; focus/restore; Maps and popup destinations; local Fiber handoff; 25 lessons, Merida rotation, wrong-key accuracy, restart, full-passage completion, local progress and honest unconfigured status; manager module roundtrips; rich-text sanitization; URL rejection; private MP3/MP4 uploads, authorization, seek ranges, browser playback and speed; disguised PHP upload rejection; manager campaign editing and Roofing action.
- **9 targeted editor/retry checks passed** (`tests/editor.py`): source styling in visual editor, input state, persisted edit with colors, cleared form configuration, honest missing-form fallback, popup-blocker fallback, rapid campaign switching, exact warm-note expiration caution, visible pending submission retry after reload. This follow-up covers the final editor and retry-state changes after the broader suite.
- **14 Apps Script service-double checks passed** (`tests/typing-backend.cjs`): shared key, roster, daily lesson, bounds, IDs, append acknowledgment, duplicate suppression under lock, Retry status, formula escaping, protected results, private GET behavior and 25-day rotation. This is not a deployed Google Sheets test.
- **14 script text/highlight roundtrips + 5 sanitizer cases passed** (`tests/content.php`): sanitization preserves document text and shading; valid browser RGB is normalized; unsafe CSS/markup/URLs are removed.
- **All final PHP files passed syntax checks.** JS/Apps Script/inline-script syntax, JSON parsing and local asset references passed (`tools/audit.py`, counts in STATIC-QA.json). No missing referenced local assets. All original archive files remain in the source workspace; file-level disposition and hashes are in CHANGELOG.json. Runtime credentials, historical backups and real uploads are deliberately excluded from ZIPs.
- **5 packaged-release smoke checks passed** after extracting the actual deployable ZIP into a separate local directory and adding only fixture credentials: protected leaderboard route, login/dashboard data, station campaign options, visual manager editor/navigation, and typing/config API.
- The startup script was executed successfully; setup and local service initialization are saved in the environment draft. Saving does not publish or verify restoration in a new task.

Earlier test failures exposed a private-example route, editor RGB normalization, document-switching race and hidden retry panel; these were corrected and affected checks rerun. Some harness failures came from waiting for invisible option elements and losing a test CSRF token across navigation; these were corrected. No unresolved locally reproduced application failures remain in the tested scope.

## Visual comparison

`tests/visual.py` captures the original baseline dashboard/resource reader, Release 4 station, and merged dashboard/station. The evidence ZIP contains `visual-comparison.html` plus the captures. Other screenshots cover 1366/1920px and mobile station layouts, focused reading, Battery Backup, typing completion, the visual manager editor and media playback using generated fixtures.

Inspected captures against the supplied screenshot references and the WordprocessingML: the merged reader uses white instead of dark, retains red/blue emphasis and the pale highlighted “RIGHT? PERFECT.” cue, and avoids the broad forced yellow styling/white-bold overrides shown in the reported failure. Source documents determine exact colors and emphasis; screenshots are a visual reference, not a reason to rewrite the latest documents. Responsive wrapping differs from full-width Google Docs. There is no claim of pixel-identical page geometry.

The DOCX import report verifies all six supplied documents, source hashes, paragraph/run counts and source-text preservation. Word shading and highlighting are interpreted at the run/paragraph level; paragraph-end-only formatting does not become an invented whole-paragraph highlight. The latest DOCX files, including Warm Reschedule, are retained in the source package. The missing Fiber DOCX cannot be compared.

External page requests were intercepted/labeled during browser testing so that Google Forms, Maps, fonts and CRM responses do not make local regression tests depend on remote access or create submissions. Popup tests verify the intended URL and local behavior. The screenshots' external-form notice is a QA interception, not a replacement deployed form. Unavailable CRM values remain dashes and a connection message, not generated statistics.

## Not verified / deployment prerequisites

- No production Hostinger access: live rewrite/permissions/cache behavior, actual user credentials, PHP limits and production route placement must be checked in staging. Existing shared-password architecture is retained; it is not individual/MFA identity management.
- No live Forms submission, CRM appointment creation/update, Calendar write, Roam admission or provider serviceability check was performed. The existing read-only CRM endpoint is preserved but its current response/authorization is not established here.
- Typing endpoint `/exec` URL and private shared key are not configured; no Sheets delivery/results claim is made. The supplied standalone backend and exact configuration/deployment steps are in INTEGRATIONS.md.
- Final Fiber destination and authoritative Fiber DOCX were not supplied; existing candidate script and local handoff remain.
- No approved audio/video recordings were supplied. Libraries are intentionally empty until populated; only generated fixtures were used for playback QA.
- Preserved morning roll-call destination is an `/edit` URL. Supply a verified responder URL if ordinary agents lack access; the correct published link cannot be inferred safely.
- Automatic Google Docs synchronization is not implemented. Formatting-preserving DOCX import and secure visual manager edits are implemented.

## Reproduce

From `/workspace/handyhomes`, run `bash tools/start-dev.sh`, then `python3 tests/functional.py`, `node tests/typing-backend.cjs`, and `python3 tools/audit.py`. Reset the QA copy with `python3 tools/sync_qa.py` before `python3 tests/editor.py`. Run `docker exec dc-hub-qa php /var/www/html/dc-hub/tests/content.php` for PHP content tests. Browser tests require Playwright + Chromium, and generated media tests require ffmpeg. Baseline comparison screenshots additionally require the original and candidate reference trees prepared from the uploads; these references are not production dependencies.

Inspect command exit codes, current result JSON timestamps, and screenshot content. ZIP packaging checks required routes, archive CRC integrity and exclusion of credential files. Local evidence does not replace the staging acceptance steps in DEPLOYMENT.md.
