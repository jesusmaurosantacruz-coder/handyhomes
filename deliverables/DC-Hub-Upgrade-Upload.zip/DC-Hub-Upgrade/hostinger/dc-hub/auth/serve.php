<?php
/** Server-side gate for the existing HTML dashboard and companion resources. */
declare(strict_types=1);
require_once __DIR__ . '/session.php';

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Cache-Control: private, no-store, max-age=0');

$file = (string)($_GET['file'] ?? '');
$allowed = in_array($file, ['index.html','training/typing/passages.json'], true)
    || in_array($file, ['operations/index.html','leaderboard/index.html','campaigns/index.html','resources/index.html','calendar/index.html','dialing-station/index.html','training/typing/index.html','training/audio/index.html','training/videos/index.html'], true)
    || (bool)preg_match('~^assets/data/[a-z0-9-]+\.json$~iD', $file)
    || $file === 'leaderboard/assets/js/config.js'
    || (bool)preg_match('~^assets/(?:scripts|market-notes)/[a-z0-9-]+\.html$~iD', $file);
if (!$allowed) {
    http_response_code(404);
    exit('Not found.');
}

if (!dc_is_authenticated()) {
    // An ordinary page navigation returns to login; fetch requests get a useful 401.
    if (str_ends_with($file, '/index.html') || $file === 'index.html') {
        header('Location: ' . rtrim(dirname(dirname((string)$_SERVER['SCRIPT_NAME'])), '/') . '/login.php', true, 302);
    } else {
        http_response_code(401);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'Authentication required.';
    }
    exit;
}

$permission = str_starts_with($file,'training/typing/') ? 'typing'
    : (str_starts_with($file,'training/') ? 'training'
    : (str_starts_with($file,'dialing-station/') ? 'dialing' : (str_starts_with($file,'calendar/') ? 'calendar' : (str_starts_with($file,'leaderboard/')||str_starts_with($file,'campaigns/') ? 'analytics' : 'resources'))));
if (!dc_permission($permission) && $file !== 'index.html' && $file !== 'operations/index.html') {
    http_response_code(403);exit('Permission denied.');
}
$root = realpath(__DIR__ . '/..');
$target = realpath($root . '/' . $file);
if (!$target || !str_starts_with($target, $root . DIRECTORY_SEPARATOR) || !is_file($target)) {
    http_response_code(404);
    exit('Not found.');
}

$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
$types = ['html' => 'text/html; charset=UTF-8', 'json' => 'application/json; charset=UTF-8', 'js' => 'text/javascript; charset=UTF-8'];
header('Content-Type: ' . ($types[$ext] ?? 'application/octet-stream'));
header('Content-Length: ' . filesize($target));
readfile($target);
