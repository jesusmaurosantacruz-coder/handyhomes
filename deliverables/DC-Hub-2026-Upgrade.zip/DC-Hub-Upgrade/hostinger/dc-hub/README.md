# Digital Citizen Hub 2026 website

PHP/Apache, static JavaScript/CSS, authenticated local market JSON and resource files. No npm build or frontend framework is required. The complete source release includes Apps Script, tests and deployment documentation outside this runtime directory; read `docs/UPGRADE-2026.md` there before deployment.

Preserve production private configuration outside the web root and use Google OAuth. Never copy local QA sessions or credentials to production. Source Forms and triggers remain the intake system. The dashboard reads CRM/Calendar information and does not edit appointments, create events or synchronize form choices.

Update local market files using `assets/data/markets/README.md`; update resources using `assets/library/README.md`. Do not store customer data in static JSON.
