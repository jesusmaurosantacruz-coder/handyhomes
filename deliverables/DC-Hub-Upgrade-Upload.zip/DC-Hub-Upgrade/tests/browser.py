"""Browser integration against the actual UI with explicit Workspace service doubles.
Real unauthenticated Apache routes are checked separately. No Google or Roam calls.
"""
from pathlib import Path
from datetime import datetime, timezone
import json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT/'hostinger/dc-hub'
OUT=ROOT/'tests/evidence';OUT.mkdir(exist_ok=True)
BASE='http://127.0.0.1:8081/dc-hub/'
checks=[];calls=[]
def check(name, condition):
 assert condition,name
 checks.append(name);print('PASS '+name,flush=True)
today=datetime.now(timezone.utc).strftime('%Y-%m-%d')
user={'email':'admin@example.test','name':'Test Admin','role':'Admin','team':'Team 1','permissions':['dashboard','appointments','calendar','analytics','resources','typing','administration','training','dialing']}
record={'id':'DC-test','name':'Test Customer','phone':'555-0100','street':'Fixture street','city':'Test City','state':'TX','zip':'00000','email':'customer@example.test','setter':'Test Agent','campaign':'SOLAR','date':today,'time':'14:00','timezone':'America/Chicago','team':'Team 1','version':1,'fingerprint':'fixture-fingerprint','status':'Scheduled','confirmation':'Not Started','disposition':'Pending Outcome','syncStatus':'Synced','canEdit':True,'notes':'','rescheduleReason':'','outcomeNotes':''}
resource={'name':'Operations room','url':'https://example.test/room','section':'MEETINGS','description':'Fixture resource'}
analytics={'from':today,'to':today,'total':3,'personal':1,'team':2,'confirmed':1,'states':[{'state':'TX','count':2,'campaigns':[['SOLAR',1],['FIBER',1]]},{'state':'CA','count':1,'campaigns':[['ROOFING',1]]}],'agents':[['Test Agent',2],['Test Other',1]],'teams':[['Team 1',2],['Team 2',1]],'campaigns':[['SOLAR',1],['ROOFING',1],['FIBER',1]],'daily':[[today,3]],'statuses':[['Scheduled',3]],'dispositions':[['Pending Outcome',3]]}
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 # Real PHP/Apache authentication and file rules, without mocked requests.
 ctx=browser.new_context()
 for route in ['','index.html','operations/index.html?view=appointments','calendar/index.html','training/typing/index.html']:
  response=ctx.request.get(BASE+route,max_redirects=0);check('Real anonymous gate '+route,response.status==302)
 for route in ['auth/session.php','auth/config.php','training/media/test.mp3','tests/backend.cjs','private/config.php']:
  check('Real direct private-path denial '+route,ctx.request.get(BASE+route).status==403)
 check('Real unauthenticated API denies access',ctx.request.post(BASE+'api/hub.php',data={'action':'adminData'}).status==401)
 login=ctx.request.get(BASE+'login.php');check('Unconfigured login renders honest setup state',login.status==200 and 'awaiting its Google connection' in login.text())
 ctx.close()
 ctx=browser.new_context(viewport={'width':1440,'height':1000})
 def route(r):
  url=r.request.url
  if not url.startswith(BASE):
   r.fulfill(status=200,body='External request blocked by test harness');return
  rel=url[len(BASE):].split('?')[0]
  if rel=='auth/whoami.php':r.fulfill(json={'authenticated':True,'user':user,'csrf':'fixture-csrf'});return
  if rel=='api/hub.php':
   data=r.request.post_data_json;action=data['action'];params=data.get('params',{});calls.append((action,params))
   result={}
   if action=='bootstrap':result={'user':user,'resources':[resource],'announcements':[{'title':'Team focus','text':'Fixture announcement'}],'goals':[{'campaign':'SOLAR','daily':3,'weekly':15,'monthly':60}],'teams':['Team 1','Team 2','Team 3']}
   elif action=='appointments':result={'items':[record],'total':1,'from':params.get('from',today),'to':params.get('to',today)}
   elif action=='detail':result=record
   elif action=='update':
    record.update(params['changes']);record['version']+=1;result={'record':record,'sync':{'ok':True}}
   elif action=='retrySync':result={'record':record,'sync':{'ok':True}}
   elif action=='analytics':result=analytics
   elif action=='markets':result=[{'id':'2','name':'Texas market','state':'TX','campaign':'SOLAR','summary':'Fixture market','url':'https://docs.google.com/document/d/fixture/edit','canEdit':True}]
   elif action=='document':result={'html':'<h2>Fixture market notes</h2><p>Approved reference material.</p>','url':'https://docs.google.com/document/d/fixture/edit','canEdit':True}
   elif action=='adminData':result={'users':[{'email':'agent@example.test','name':'Test Agent','role':'Agent','active':True,'team':'Team 1'}],'permissions':[{'Feature / Action':'typing','Intern':True,'Agent':True,'Team Lead':True,'Admin':True}],'teams':['Team 1','Team 2','Team 3'],'configurationTabs':['USERS','CRM_HUB_LINKS'],'spreadsheetUrl':'https://docs.google.com/spreadsheets/d/fixture/edit'}
   elif action=='adminSave':result={'saved':True}
   elif action=='typingStart':result={'attemptId':'test-attempt-'+str(len(calls)),'seconds':params['seconds'],'sourceId':params['sourceId']}
   elif action=='typingSave':result={'saved':True}
   elif action=='typingLeaderboard':result={'leaders':[],'mine':[]}
   elif action=='syncForms':result=[{'campaign':'SOLAR','choices':2}]
   r.fulfill(json={'ok':True,'data':result});return
  file=SITE/rel
  if rel=='' or rel.endswith('/') :file=SITE/rel/'index.html'
  if file.is_file() and file.suffix in ['.html','.json']:
   r.fulfill(path=str(file),content_type='application/json' if file.suffix=='.json' else 'text/html');return
  r.continue_()
 ctx.route('**/*',route)
 page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE+'index.html');page.get_by_text('Where we are producing',exact=True).wait_for()
 check('Dashboard greets authenticated user',page.locator('#heading').inner_text()=='Welcome back, Test.')
 check('Dashboard renders real API aggregates',page.locator('.kpi strong').all_text_contents()==['3','1','2','1'])
 check('Market intelligence is available in navigation',page.get_by_role('link',name='Market intelligence').is_visible());check('Sheet announcement is rendered',page.get_by_text('Team focus',exact=True).count()==1)
 page.screenshot(path=str(OUT/'dashboard-desktop.png'),full_page=True)
 page.goto(BASE+'operations/index.html?view=appointments');page.get_by_role('button',name='Open →').wait_for();page.get_by_role('button',name='Open →').click();page.get_by_role('dialog').wait_for();page.wait_for_function("document.getElementById('dialog-title').textContent==='Test Customer'")
 check('Appointment detail shows authorized customer',page.locator('#dialog-title').inner_text()=='Test Customer')
 page.get_by_role('button',name='Confirm appointment',exact=True).click();page.wait_for_function("document.querySelector('[name=confirmation]').value==='Confirmed'")
 check('Quick confirm submits version and fingerprint',any(a=='update' and v.get('version')==1 and v.get('fingerprint')=='fixture-fingerprint' for a,v in calls))
 page.get_by_role('button',name='Close details').click();page.get_by_role('button',name='Tomorrow',exact=True).click();page.wait_for_timeout(100)
 check('Queue requests a bounded date window',all('from' in v and 'to' in v for a,v in calls if a=='appointments'))
 page.goto(BASE+'calendar/index.html');page.get_by_text('Scheduled production',exact=True).wait_for();check('Calendar uses protected appointment API',any(a=='appointments' and v.get('calendar') for a,v in calls))
 page.goto(BASE+'operations/index.html?view=analytics');page.get_by_text('State production',exact=True).wait_for();check('State view includes campaign breakdown',[s.replace(' ↕','') for s in page.locator('th').all_text_contents()[:5]]==['STATE','TOTAL','SOLAR','ROOFING','FIBER'])
 page.goto(BASE+'leaderboard/index.html');page.get_by_text('Agent standings',exact=True).wait_for();check('Agent and team standings available',page.get_by_text('Team standings',exact=True).count()==1)
 page.goto(BASE+'operations/index.html?view=markets');page.get_by_role('button',name='Read market notes →').wait_for();page.get_by_role('button',name='Read market notes →').click();page.get_by_text('Fixture market notes',exact=True).wait_for();check('Google Docs content and edit action render',page.get_by_role('link',name='Edit in Google Docs ↗').count()==1)
 page.goto(BASE+'resources/index.html');page.get_by_text('Operations room ↗',exact=True).wait_for();check('Sheet-driven resource link rendered',page.get_by_role('link',name='MEETINGS Operations room ↗ Fixture resource').count()==1)
 page.goto(BASE+'operations/index.html?view=admin');page.get_by_text('People & teams',exact=True).wait_for();check('Team 1-3 available for assignment',page.get_by_label('Team for Test Agent').locator('option').all_text_contents()==['Unassigned','Team 1','Team 2','Team 3']);page.get_by_label('Team for Test Agent').select_option('Team 2');page.get_by_role('button',name='Save',exact=True).click();page.get_by_text('User settings saved.',exact=True).wait_for();check('Admin team update uses authenticated API',any(a=='adminSave' and v.get('team')=='Team 2' for a,v in calls))
 page.goto(BASE+'dialing-station/index.html');page.wait_for_function("document.querySelector('#campaign').options.length>0 && document.querySelector('#script-body').textContent.length>100");check('Existing campaign station and scripts retained',page.locator('#campaign option').count()>3);page.get_by_label('Read live market notes').wait_for();page.get_by_label('Read live market notes').select_option('0');page.get_by_text('Fixture market notes',exact=True).wait_for();check('Dialing station reads sheet-registered Google Docs',page.get_by_text('Approved reference material.',exact=True).count()==1)
 page.goto(BASE+'training/typing/index.html');page.get_by_role('button',name='Start test',exact=True).wait_for();page.wait_for_function("!document.getElementById('start').disabled")
 check('Typing identity comes from session',page.locator('#identity').inner_text()=='Test Admin')
 check('Typing has exactly three duration selections',page.locator('#durations button').count()==3)
 check('Typing has exactly three script selections',page.locator('#sources button').count()==3)
 page.clock.install()
 for seconds,label in [(60,'1 min'),(90,'90 sec'),(120,'2 min')]:
  page.get_by_role('button',name=label,exact=True).click();page.get_by_role('button',name='Start test',exact=True).click();page.wait_for_function("!document.getElementById('entry').disabled")
  passage=page.locator('#passage').inner_text();page.locator('#entry').press_sequentially(passage[:10]);page.clock.fast_forward(seconds*1000)
  page.get_by_text('Result saved to Google Sheets.',exact=True).wait_for()
  check(str(seconds)+' second browser timer stops at deadline',page.locator('#entry').is_disabled() and page.locator('#clock').inner_text()=='00:00')
  sent=[v for a,v in calls if a=='typingSave'][-1];check(str(seconds)+' second result contains measured elapsed and text',sent['elapsed']==seconds and sent['typedText']==passage[:10])
  page.get_by_role('button',name='Restart test',exact=True).click()
 page.screenshot(path=str(OUT/'typing-lab.png'),full_page=True)
 page.goto(BASE+'index.html');page.get_by_text('Where we are producing',exact=True).wait_for();page.set_viewport_size({'width':390,'height':844});check('Mobile layout has no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'));page.get_by_role('button',name='Toggle navigation').click();check('Mobile navigation opens',page.locator('body').evaluate("el=>el.classList.contains('nav-open')"));page.get_by_role('button',name='Toggle navigation').click();page.screenshot(path=str(OUT/'dashboard-mobile.png'),full_page=True)
 check('No browser JavaScript exceptions',not errors)
 browser.close()
(OUT/'browser-results.json').write_text(json.dumps({'passed':len(checks),'checks':checks,'scope':'Local PHP anonymous gates plus browser UI with explicit Workspace service doubles; no live integration validation'},indent=2))
print('Completed',len(checks),'browser checks')
