/* Decorative canvas globe; deliberately contains no authentication logic. */
(() => {
  'use strict';
  const eye = document.getElementById('toggle-password');
  const passwordInput = document.getElementById('password');
  if (eye && passwordInput) eye.addEventListener('click', () => {
    const visible = passwordInput.type === 'password';
    passwordInput.type = visible ? 'text' : 'password';
    eye.setAttribute('aria-pressed', String(visible));
    eye.setAttribute('aria-label', visible ? 'Hide password' : 'Show password');
  });

  const canvas = document.getElementById('globe');
  if (!canvas?.getContext) return;
  const ctx = canvas.getContext('2d', { alpha: true });
  if (!ctx) return;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const RAD = Math.PI / 180;
  let w = 0, h = 0, ratio = 1, radius = 0, cx = 0, cy = 0;

  // Simplified continent outlines. Fuzzy coast dots avoid the look of a hard-edged map.
  const continents = [
    [[-168,69],[-153,72],[-133,71],[-121,61],[-112,56],[-99,52],[-82,51],[-68,48],[-62,44],[-80,25],[-97,16],[-108,28],[-114,32],[-126,39],[-131,51],[-153,58]],
    [[-114,33],[-103,30],[-96,19],[-90,14],[-83,9],[-80,13],[-86,22],[-96,30]],
    [[-81,13],[-68,11],[-57,8],[-49,0],[-34,-8],[-39,-19],[-48,-29],[-54,-37],[-67,-55],[-76,-41],[-72,-24],[-80,-10]],
    [[-73,60],[-59,59],[-42,62],[-37,73],[-48,83],[-61,79]],
    [[-12,36],[-10,43],[-25,57],[-13,61],[7,58],[18,68],[31,71],[42,60],[54,59],[63,55],[85,54],[104,58],[122,57],[140,51],[159,58],[180,66],[180,49],[148,41],[140,33],[127,34],[117,22],[101,2],[93,8],[83,9],[72,20],[61,22],[51,28],[42,26],[33,37],[26,40],[17,34],[7,39],[-4,36]],
    [[-17,37],[11,37],[32,29],[44,11],[50,-13],[40,-25],[32,-34],[17,-35],[12,-26],[4,-5],[-10,5]],
    [[112,-11],[123,-13],[138,-12],[153,-26],[146,-39],[126,-38],[114,-28]],
    [[-8,59],[2,59],[1,51],[-6,50]],
    [[44,-12],[51,-13],[50,-26],[45,-26]],
    [[120,19],[126,15],[125,5],[120,7]],
    [[129,32],[135,34],[139,40],[145,44],[145,35],[140,33]],
    [[-180,-63],[180,-63],[180,-90],[-180,-90]],
  ];
  function inside(lon, lat, poly) {
    let hit = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const a = poly[i], b = poly[j];
      if (((a[1] > lat) !== (b[1] > lat)) && lon < (b[0] - a[0]) * (lat - a[1]) / ((b[1] - a[1]) || 1e-9) + a[0]) hit = !hit;
    }
    return hit;
  }
  // Deterministic noise (consistent dot pattern each load).
  let seed = 4317;
  const rand = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  const points = [];
  for (let i = 0; i < 7500; i++) {
    const lon = rand() * 360 - 180;
    const lat = Math.asin(2 * rand() - 1) / RAD;
    if (continents.some(p => inside(lon, lat, p))) {
      points.push({ lon: lon * RAD, lat: lat * RAD, size: .42 + rand() * .95, pulse: rand() * Math.PI * 2 });
    }
  }
  const nodes = [
    [-118.24,34.05],[-76.61,39.29],[-74.01,40.71],[-112.07,33.45],[-89.4,43.1],
    [-89.62,20.97],[-58.38,-34.6],[-0.12,51.5],[12.49,41.89],[31.23,30.05],
    [28.05,-26.2],[77.2,28.61],[121.47,31.23],[139.69,35.69],[-74.07,4.71]
  ].map(([lon,lat]) => ({lon:lon*RAD,lat:lat*RAD}));

  function resize() {
    const box = canvas.getBoundingClientRect();
    w = box.width; h = box.height;
    ratio = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.max(1, Math.round(w * ratio));
    canvas.height = Math.max(1, Math.round(h * ratio));
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    radius = Math.min(w * .43, h * .48, 345);
    cx = w * .495;
    cy = h * .50;
  }
  window.addEventListener('resize', resize, { passive: true });
  resize();

  function project(lon, lat, angle) {
    const l = lon + angle;
    const x = Math.cos(lat) * Math.sin(l);
    const y = -Math.sin(lat);
    const z = Math.cos(lat) * Math.cos(l);
    // 13-degree axial tilt.
    const tilt = .21;
    return { x: cx + (x * Math.cos(tilt) - y * Math.sin(tilt)) * radius,
      y: cy + (x * Math.sin(tilt) + y * Math.cos(tilt)) * radius, z };
  }
  const drawPath = (items, angle, alpha, width) => {
    let started = false;
    ctx.beginPath();
    for (const [lon, lat] of items) {
      const p = project(lon, lat, angle);
      if (p.z <= 0) { started = false; continue; }
      if (!started) { ctx.moveTo(p.x,p.y); started = true; }
      else ctx.lineTo(p.x,p.y);
    }
    ctx.strokeStyle = `rgba(117,203,155,${alpha})`;
    ctx.lineWidth = width;
    ctx.stroke();
  };
  function render(now) {
    const time = now * .001;
    const angle = (reducedMotion ? -.7 : time * .053 - .7);
    ctx.clearRect(0, 0, w, h);
    const glow = ctx.createRadialGradient(cx,cy,radius*.08,cx,cy,radius*1.42);
    glow.addColorStop(0,'rgba(17,65,41,.085)');
    glow.addColorStop(.47,'rgba(21,74,48,.058)');
    glow.addColorStop(.71,'rgba(57,179,104,.024)');
    glow.addColorStop(1,'rgba(6,43,27,0)');
    ctx.fillStyle = glow;ctx.beginPath();ctx.arc(cx,cy,radius*1.4,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.arc(cx,cy,radius,0,Math.PI*2);
    ctx.strokeStyle='rgba(105,235,156,.18)';ctx.lineWidth=1;ctx.stroke();
    for (let lat=-75;lat<=75;lat+=15) {
      const items=[];for(let lon=-180;lon<=180;lon+=3)items.push([lon*RAD,lat*RAD]);
      drawPath(items,angle,.07,.56);
    }
    for (let lon=-180;lon<180;lon+=15) {
      const items=[];for(let lat=-89;lat<=89;lat+=2)items.push([lon*RAD,lat*RAD]);
      drawPath(items,angle,.07,.56);
    }
    for (const dot of points) {
      const p = project(dot.lon,dot.lat,angle);
      if (p.z < -.025) continue;
      const depth = Math.max(0,p.z);
      const shimmer = reducedMotion ? 1 : .84 + .16 * Math.sin(time*1.2+dot.pulse);
      ctx.fillStyle = `rgba(120,237,161,${(.13 + .56*depth)*shimmer})`;
      ctx.fillRect(p.x,p.y,dot.size*.7+depth*.45,dot.size*.7+depth*.45);
    }
    // Connections skim the globe rather than a distracting web of straight rays.
    for (let i = 1; i < nodes.length; i++) {
      const a = project(nodes[i-1].lon,nodes[i-1].lat,angle);
      const b = project(nodes[i].lon,nodes[i].lat,angle);
      if(a.z < .22 || b.z < .22) continue;
      const mx=(a.x+b.x)/2, my=(a.y+b.y)/2;
      const dx=mx-cx,dy=my-cy;
      ctx.beginPath();ctx.moveTo(a.x,a.y);
      ctx.quadraticCurveTo(mx+dx*.22,my+dy*.22,b.x,b.y);
      ctx.strokeStyle='rgba(124,252,169,.18)';ctx.lineWidth=.8;ctx.stroke();
    }
    for(const node of nodes){const p=project(node.lon,node.lat,angle);if(p.z<.07)continue;
      const flicker = reducedMotion ? .8 : .65+.35*Math.sin(time*1.7+node.lon*6);
      ctx.beginPath();ctx.arc(p.x,p.y,3.4,0,Math.PI*2);ctx.fillStyle=`rgba(113,247,165,${.06*flicker})`;ctx.fill();
      ctx.beginPath();ctx.arc(p.x,p.y,1.5,0,Math.PI*2);ctx.fillStyle=`rgba(204,255,215,${.65*flicker})`;ctx.fill();
    }
    if (!reducedMotion) {
      // Transient analogue signal noise, visible only over the globe.
      const jitter = Math.sin(time*18.4);
      if(jitter > .97) {
        ctx.fillStyle = 'rgba(161,241,181,.035)';
        ctx.fillRect(cx-radius*.88,cy+Math.sin(time*20)*radius*.64,radius*1.72,1.25);
      }
    }
    if (!reducedMotion && !document.hidden) requestAnimationFrame(render);
  }
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!reducedMotion)requestAnimationFrame(render)});
  requestAnimationFrame(render);
})();
