from pathlib import Path
import json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'tests/evidence';BASE='http://127.0.0.1:8081/dc-hub/';checks=[]
def check(name,ok):assert ok,name;checks.append(name);print('PASS '+name,flush=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--enable-unsafe-swiftshader']);c=b.new_context();page=c.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE+'login.php');page.wait_for_function("document.querySelector('.login-network').classList.contains('globe-ready') || document.getElementById('globe').hidden")
 check('Globe initializes or enters a clean fallback',page.locator('.earth-fallback').count()==1 and not errors)
 check('Textured WebGL initializes on supported browser',page.locator('.login-network.globe-ready').count()==1)
 page.screenshot(path=str(OUT/'login-earth.png'),full_page=True)
 page.set_viewport_size({'width':390,'height':844});check('Login mobile has no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
 page.screenshot(path=str(OUT/'login-earth-mobile.png'),full_page=True)
 c.close();c=b.new_context(reduced_motion='reduce');page=c.new_page();page.add_init_script("HTMLCanvasElement.prototype.getContext=()=>null")
 page.goto(BASE+'login.php');page.wait_for_function("document.getElementById('globe').hidden")
 check('No WebGL retains visible sign-in setup state and CSS Earth',page.locator('.login-card').is_visible() and page.locator('.earth-fallback').is_visible())
 check('Reduced motion stops decorative light trails',page.locator('.network-orbit').first.evaluate("e=>getComputedStyle(e,'::after').animationName")== 'none')
 c.close();c=b.new_context();page=c.new_page();page.route('**/earth-day.jpg',lambda r:r.abort());page.goto(BASE+'login.php');page.wait_for_function("document.getElementById('globe').hidden");check('Missing texture leaves login content available',page.locator('.login-card').is_visible());b.close()
(ROOT/'tests/globe-results.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2))
