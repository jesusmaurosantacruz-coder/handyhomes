/** One bound project; replace old handlers, do not paste alongside them. */
const HUB = Object.freeze({
  aliases: {master:['CRM MASTER','CRM_MASTER'],users:['USERS','CRM_USERS'],permissions:['ROLE_PERMISSIONS','CRM_PERMISSIONS'],resources:['CRM_HUB_LINKS','CRM_RESOURCES'],goals:['PRODUCTION_GOALS','CRM_GOALS'],market:['CRM_MARKET_NOTES'],typing:['Typing Test','Typing Results'],announcements:['CRM_ANNOUNCEMENTS'],teams:['CRM_TEAMS'],settings:['CRM_SETTINGS'],audit:['CRM_AUDIT_LOG']},
  actions:['dashboard','calendar','appointments','editOwn','editTeam','analytics','resources','typing','administration','training','dialing'],roles:['Intern','Agent','Team Lead','Admin'],teams:['Team 1','Team 2','Team 3'],
  statuses:['Scheduled','Confirmed','Completed','No Show','Rescheduled','Cancelled','DNQ'],
  dispositions:['Pending Outcome','Qualified Sit','Closed Won','No Sale','DNQ','Follow Up Needed','Not Interested'],
  confirmations:['Not Started','Attempted','Confirmed','No Answer','Needs Reschedule','Cancelled'],
  fields:{notes:'Internal Notes',status:'Appointment Status',disposition:'Disposition',date:'Appointment Date',time:'Start Time',timezone:'Appointment Time Zone',confirmation:'Confirmation Status',outcomeNotes:'Appointment Outcome Notes',rescheduleReason:'Reschedule Reason'},
  sources:{'Solar PreQual Form (Responses)':'SOLAR','Roofing Inspection Scheduling Form (Responses)':'ROOFING','The Dark Fiber OPs Intake (Responses)':'FIBER'},
  schema:{
    master:['Hub Intake Version','Lead ID','Form Submission Key','Record Type','Campaign','Source Form','Source Row','Submission Timestamp','Created At','Last Updated','Updated By','First Name','Last Name','Phone Number','Street Address','City','State','ZIP Code','Email','Setter Name','Setter Email','Source Classification','Original Team','Current Team','Appointment Date','Start Time','Appointment Time Zone','Appointment Status','Disposition','Confirmation Status','Internal Notes','Qualification Notes','Appointment Outcome Notes','Reschedule Reason','Reschedule Count','Linked Event All Day','Calendar ID','Calendar API Event ID','Calendar Event ID','Agent Calendar Event ID','Related Calendar Events','Calendar Sync Status','Calendar Sync Error','CRM Revision','Last Synced At','Roam New Status','Roam Update Revision','Roam Error','Utility Provider','Highest Electric Bill','Lowest Electric Bill','Roof Age','Roof Material','Roof Damage / Warning Signs','Property Type','Insurance Carrier','Fiber Provider','Fiber Appointment / Transfer Type','Fiber Installation Scheduled For','Call Recording'],
    users:['Email','Name','Role','Active','GOOGLE_SUB','LAST_LOGIN','AUTH_PROVIDER','Team','Calendar Email','Campaign'],
    permissions:['Group','Feature / Action','Intern','Agent','Team Lead','Admin','Implementation Notes'],
    teams:['Team','Active'],resources:['Section','Display Name','URL','Open As','Active','Sort Order','Description','Audience'],market:['State','Campaign','Market / Utility','Google Doc URL','Active','Priority','Display Order','Summary'],
    goals:['Campaign','Role','Daily Goal','Weekly Goal','Monthly Goal','Active','Effective From','Notes','Email','Team'],
    announcements:['ID','Title','Text','Type','Start','End','Active','Audience'],settings:['Key','Value','Description'],
    typing:['Timestamp','Agent Email','Agent Name','Test','Duration (sec)','Gross WPM','Net WPM','Accuracy %','Errors','Corrected Errors','Characters Typed','Status','Attempt ID','Uncorrected Errors','Elapsed','Team'],
    audit:['Timestamp','Lead ID','Form Submission Key','Actor','Revision','Changes (JSON)','Previous values (JSON)']
  }
});
function hubProps_(){return PropertiesService.getScriptProperties();}
function hubBook_(){const id=hubProps_().getProperty('HUB_SPREADSHEET_ID');if(!id)throw Error('Configure HUB_SPREADSHEET_ID');return SpreadsheetApp.openById(id);}
function hubSheet_(kind){const ss=hubBook_();const found=HUB.aliases[kind].map(n=>ss.getSheetByName(n)).filter(Boolean);if(found.length!==1)throw Error('Missing or ambiguous tab: '+kind);return found[0];}
function hubText_(x){return String(x===undefined||x===null?'':x).trim();}
function hubNorm_(s){return hubText_(s).replace(/\s+/g,' ');}
function hubSafe_(v){return typeof v==='string'&&/^[=+@\-\t\r]/.test(v)?"'"+v:v;}
function hubHeads_(sh){return sh.getRange(1,1,1,sh.getLastColumn()).getDisplayValues()[0].map(hubText_);}
function hubObject_(heads,row){const o={};heads.forEach((h,i)=>{if(h)o[h]=row[i];});return o;}
function hubRow_(sh,row){return hubObject_(hubHeads_(sh),sh.getRange(row,1,1,sh.getLastColumn()).getValues()[0]);}
let HUB_REFERENCE_CACHE = {};
function hubRows_(kind){if(HUB_REFERENCE_CACHE[kind])return HUB_REFERENCE_CACHE[kind];const sh=hubSheet_(kind),h=hubHeads_(sh),n=sh.getLastRow();return HUB_REFERENCE_CACHE[kind]=n<2?[]:sh.getRange(2,1,n-1,h.length).getValues().map((v,i)=>({...hubObject_(h,v),_row:i+2}));}
function hubWrite_(sh,row,changes){HUB_REFERENCE_CACHE={};const h=hubHeads_(sh);for(const k of Object.keys(changes)){const i=h.indexOf(k);if(i<0)throw Error('Missing column '+k);sh.getRange(row,i+1).setValue(hubSafe_(changes[k]));}}
function hubAppend_(kind,obj){HUB_REFERENCE_CACHE={};const sh=hubSheet_(kind),h=hubHeads_(sh);sh.appendRow(h.map(k=>hubSafe_(obj[k]===undefined?'':obj[k])));return sh.getLastRow();}
function hubFind_(sh,column,value){const h=hubHeads_(sh),i=h.indexOf(column);if(i<0||sh.getLastRow()<2)return 0;const matches=sh.getRange(2,i+1,sh.getLastRow()-1,1).createTextFinder(String(value)).matchEntireCell(true).useRegularExpression(false).findAll();if(matches.length>1)throw Error('Ambiguous '+column);return matches.length?matches[0].getRow():0;}
function hubLock_(fn){const lock=LockService.getScriptLock();lock.waitLock(30000);try{return fn();}finally{lock.releaseLock();}}
function hubActive_(x){return x===true||['true','yes','active','1'].includes(hubText_(x).toLowerCase());}
function hubDate_(v,zone){if(v instanceof Date)return Utilities.formatDate(v,zone||hubBook_().getSpreadsheetTimeZone(),'yyyy-MM-dd');const s=hubText_(v);if(/^\d{4}-\d{2}-\d{2}(?:$|[ T])/.test(s))return s.slice(0,10);const m=s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);return m?m[3]+'-'+m[1].padStart(2,'0')+'-'+m[2].padStart(2,'0'):'';}
function hubTime_(v,zone){if(v instanceof Date)return Utilities.formatDate(v,hubBook_().getSpreadsheetTimeZone(),'HH:mm');const s=hubText_(v),m=s.match(/^(\d{1,2}):(\d{2})(?::\d{2})?\s*(AM|PM)?$/i);if(!m)return '';let hr=+m[1];if(m[3])hr=hr%12+(m[3].toUpperCase()==='PM'?12:0);return hr<24&&+m[2]<60?String(hr).padStart(2,'0')+':'+m[2]:'';}
function hubHash_(s){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,s,Utilities.Charset.UTF_8).map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');}

function hubCampaign_(v){const s=hubText_(v).toUpperCase();return s==='ROOF'?'ROOFING':['SOLAR','ROOFING','FIBER'].includes(s)?s:'Unspecified';}

function hubBatchPatch_(sh,updates){if(!updates.length)return;HUB_REFERENCE_CACHE={};if(typeof Sheets==='undefined'){updates.forEach(x=>hubWrite_(sh,x.row,x.changes));return;}const h=hubHeads_(sh),data=[];updates.forEach(x=>Object.entries(x.changes).forEach(([key,value])=>{const col=h.indexOf(key);if(col<0)throw Error('Missing column '+key);data.push({range:"'"+sh.getName().replace(/'/g,"''")+"'!"+hubColumn_(col)+x.row,values:[[value]]});}));for(let i=0;i<data.length;i+=2500)Sheets.Spreadsheets.Values.batchUpdate({valueInputOption:'RAW',data:data.slice(i,i+2500)},hubBook_().getId());}
