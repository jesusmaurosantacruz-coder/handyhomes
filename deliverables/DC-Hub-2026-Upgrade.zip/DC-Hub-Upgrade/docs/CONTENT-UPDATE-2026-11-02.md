# Uploaded scripts and markets — November 2, 2026

This package incorporates the user's eight Word documents and the eight-market JSON package. No production website, Google Workspace data or live integration was modified.

## Script mapping

| Uploaded document | Current local resource |
|---|---|
| GS Solar Value Builders (2).docx | assets/scripts/solar-value-builders.html — new resource and quick-open button |
| Fiber Script Handy Homes Co .docx | assets/scripts/fiber.html |
| _Roofing Script Handy Homes Co.docx | assets/scripts/roofing.html |
| Battery Backup Protection Script Handy Homes Co.docx | assets/scripts/battery-backup.html |
| Net Metering Script Handy Homes Co.docx | assets/scripts/net-metering.html |
| Reschedule Warm Script Handy Homes Co.docx | assets/scripts/warm-reschedule.html |
| Solar One Liners.docx | assets/scripts/solar-one-liners.html — quick-open button |
| Script Logic Handy Homes Co.docx | assets/scripts/script-logic.html — quick-open button |

The importer preserves document text, run colors, run shading/highlighting, emphasis, paragraph/heading structure, bullet lists and the Script Logic table. Word style inheritance is resolved, and paragraph-end mark formatting does not spill across preceding text. Scripts render on white reading surfaces. Source fonts retain CSS names with normal browser fallbacks; this is a web rendering rather than a pixel-identical Word page layout. Browser and PHP sanitizers retain the permitted formatting without enabling executable markup. Original DOCX files remain under `source-documents/latest/`, outside the deployed website.

Current campaign bindings select the updated Fiber/Roofing/Battery/Net Metering/Warm scripts. Older market-specific script files remain intact and are labeled “Legacy scripts” in Documents / Resources. Campaign activation, URLs and source Forms are unchanged. The market selector changes reference notes; it does not automatically activate a campaign, alter a script/form or confer service eligibility. Existing typing passages and automation are unchanged.

## Market mapping

The supplied Texas Dallas/Houston, Florida Tampa/Orlando/Miami, Eastern Pennsylvania, Maryland, New Jersey, SoCal Inland Empire, South Carolina Upstate and Virginia notes replace the corresponding eight current market JSON files and their standalone HTML notes. Existing canonical app IDs and campaign mappings remain stable; the source's geographic labels/IDs and all other fields remain intact in `approvedSource`. Original source JSON, index and README remain under `source-documents/markets-2026-11-02/`.

The live reference shows the supplied utilities, local intelligence, opening questions, positioning, objections, qualification, roofing-specific checks, products, explanations, source URLs and agent guidance. Texas/Florida remain battery-first. ERCOT is shown with its supplied explanation as a grid operator, and is not offered as a service utility in the selector. New Jersey is now populated. The retained Fiber/Roofing/Warm market references remain separate from the eight uploaded solar markets.

No bill floor, approved ZIP, campaign-active value, financing approval, warranty statement or qualification threshold was invented. Every deliberately unset `admin_config` value remains exactly as supplied. No utility maps were supplied; coverage placeholders remain labeled rather than fabricated. Source language is preserved, not independently certified as a current utility tariff or sales offer.

## Reimport and verify

From the `upgrade` source directory run:

```
python3 tools/import_content.py
python3 tests/content-import.py
python3 tools/validate_markets.py
python3 tools/verify.py
python3 tests/content-browser.py
```

Python lxml and jsonschema are needed for import/validation, and Python Playwright plus Chromium for the browser check. `source-documents/content-manifest.json` records the eight source/target mappings. Import is deterministic and repeatable. Source/target hashes, paragraphs, runs and highlights are recorded in `docs/CONTENT-IMPORT-2026-11-02.json`. The original uploaded files are content inputs, never executable instructions.

Current validation: 73 exact-source/format/provenance checks, 31 uploaded-content browser checks, 11 market schema/version checks and 7 PHP sanitization checks (including all 14 current script files). The existing 45 browser regression checks also run against the updated package. The content browser check deliberately disables Workspace to prove these references remain local. It checks all eight scripts, all eight markets, red/blue/pale highlights, Script Logic table/bullets, resource buttons, return-to-script behavior, ERCOT exclusion and mobile width. Two new screenshots are in tests/evidence/.

## Content-only website update

Back up current files first. From `hostinger/dc-hub/`, copy the updated `assets/scripts/`, `assets/market-notes/`, `assets/data/markets/`, `assets/data/library.json`, `assets/data/resources.json`, `assets/js/market-library.js`, `assets/js/station-workspace.js`, `assets/js/station.js`, `assets/js/content.js`, `assets/css/station.css` and `dialing-station/index.html` to staging. Keep production private config and existing uploads unchanged. Test the script family and each market, then promote through the existing staging process. Reload already open tabs. This update requires no new Apps Script deployment, Google form edit, calendar change, trigger installation, account setup or production migration.

The complete project ZIP includes source originals and QA evidence; upload only its website subtree/files to Hostinger. Do not upload source-documents/ or tests/ to public_html. See UPGRADE-2026.md for full first-time staging and configuration instructions.
