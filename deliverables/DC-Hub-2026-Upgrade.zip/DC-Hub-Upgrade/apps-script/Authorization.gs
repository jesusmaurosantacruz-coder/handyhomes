function hubUser_(email,sub){const users=hubRows_('users'),u=users.filter(r=>hubText_(r.Email).toLowerCase()===hubText_(email).toLowerCase());if(u.length!==1||!hubActive_(u[0].Active)||!HUB.roles.includes(u[0].Role))throw Error('Access denied: inactive or unauthorized user');const r=u[0];if(r.Role==='Affiliate'&&!hubActive_(r['Dashboard Access']))throw Error('Access denied: affiliate dashboard access is not granted');if(r.GOOGLE_SUB&&hubText_(r.GOOGLE_SUB)!==sub)throw Error('Google identity mismatch');return {email:hubText_(r.Email).toLowerCase(),name:hubText_(r.Name),role:r.Role,team:hubText_(r.Team),sub,calendarEmail:hubText_(r['Calendar Email']),id:hubText_(r['User ID'])||hubText_(r.Email).toLowerCase(),setterName:hubText_(r['Setter Name'])||hubText_(r.Name),aliases:hubText_(r['Setter Aliases']).split(/[;|]/).map(hubText_).filter(Boolean)};}
function hubSetterMatches_(row,name){const n=hubText_(name).toLowerCase();return !!n&&[row['Setter Name'],row.Name,...hubText_(row['Setter Aliases']).split(/[;|]/)].some(v=>hubText_(v).toLowerCase()===n);}
function hubOwn_(u,r){
 if(hubText_(r['Source Classification'])==='Affiliate')return false;
 if(r['Setter User ID'])return hubText_(r['Setter User ID'])===(u.id||u.email);
 if(r['Setter Email'])return hubText_(r['Setter Email']).toLowerCase()===u.email;
 const matches=hubRows_('users').filter(row=>hubSetterMatches_(row,r['Setter Name']));
 return matches.length===1&&hubText_(matches[0].Email).toLowerCase()===u.email;
}
function hubTeam_(u,r){return !!u.team&&hubText_(r['Current Team'])===u.team;}
function hubCan_(u,action){
 const restricted=['syncForms','update','retrySync'];if(restricted.includes(action))return false;
 if(action==='administration'&&!['Admin','Administrator'].includes(u.role))return false;
 if(u.role==='Affiliate'&& !['resources','typing'].includes(action))return false;
 const rows=hubRows_('permissions').filter(r=>r['Feature / Action']===action);if(rows.length>1)throw Error('Ambiguous permission '+action);
 if(rows.length&&rows[0][u.role]!==undefined&&rows[0][u.role]!=='')return hubActive_(rows[0][u.role]);
 const employee=['Agent','Team Lead','Operations / Manager','Admin','Administrator'].includes(u.role);
 if(action==='editTeam')return ['Team Lead','Operations / Manager','Admin','Administrator'].includes(u.role);return action==='administration'?['Admin','Administrator'].includes(u.role):['dashboard','calendar','appointments','analytics','dialing','editOwn'].includes(action)?employee:['resources','typing','training'].includes(action)&&u.role!=='Affiliate';
}
function hubRequire_(u,action){if(!hubCan_(u,action))throw Error('Permission denied: '+action);}
function hubDetails_(u,r){return ['Admin','Administrator'].includes(u.role)||(u.role!=='Intern'&&u.role!=='Affiliate'&&hubOwn_(u,r))||(['Team Lead','Operations / Manager'].includes(u.role)&&hubTeam_(u,r));}
function hubEdit_(u,r){return (u.role==='Admin'&&hubCan_(u,'administration'))||(hubOwn_(u,r)&&hubCan_(u,'editOwn'))||(u.role==='Team Lead'&&hubTeam_(u,r)&&hubCan_(u,'editTeam'));}
function hubPublicUser_(u){return {...u,permissions:['dashboard','calendar','appointments','analytics','resources','typing','administration','training','dialing'].filter(a=>hubCan_(u,a)),sub:undefined};}
function hubAudience_(u,value){const roles=hubText_(value).split(/[,;|]/).map(hubText_).filter(Boolean);return !roles.length||roles.includes('All')||roles.includes(u.role);}
function hubVerifyEnvelope_(p){if(!p||typeof p.body!=='string'||typeof p.signature!=='string')throw Error('Invalid signed request');const secret=hubProps_().getProperty('HUB_SHARED_SECRET');if(!secret||secret.length<32)throw Error('Server signing key not configured');const expected=Utilities.base64Encode(Utilities.computeHmacSha256Signature(p.body,secret));let diff=expected.length^p.signature.length;for(let i=0;i<expected.length;i++)diff|=expected.charCodeAt(i)^p.signature.charCodeAt(i);if(diff)throw Error('Invalid signature');const b=JSON.parse(p.body);if(Math.abs(Date.now()/1000-Number(b.timestamp))>90||!/^[a-f0-9]{48}$/.test(b.nonce||''))throw Error('Expired request');hubLock_(()=>{const cache=CacheService.getScriptCache(),key='nonce:'+b.nonce;if(cache.get(key))throw Error('Request replay');cache.put(key,'1',180);});if(!b.actor||!b.actor.email||!b.actor.sub)throw Error('Missing authenticated identity');return b;}
