(function (root) {
  'use strict';
  const metrics = Object.freeze(['set', 'confirmed', 'completed', 'closedWon', 'noShows']);

  function isoDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value || ''))) return '';
    const date = new Date(value + 'T12:00:00Z');
    return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value ? value : '';
  }

  function shiftDate(value, days) {
    const date = new Date(value + 'T12:00:00Z');
    date.setUTCDate(date.getUTCDate() + days);
    return date.toISOString().slice(0, 10);
  }

  function periodRange(period, today, from, to) {
    if (!isoDate(today)) throw new Error('The CRM returned an invalid reporting date.');
    if (period === 'all') return { from: '', to: '', label: 'All time' };
    if (period === 'custom') {
      if (!isoDate(from) || !isoDate(to) || from > to) throw new Error('Choose a valid start and end date.');
      return { from, to, label: 'Custom period' };
    }
    if (period === 'today') return { from: today, to: today, label: 'Today' };
    const weekday = (new Date(today + 'T12:00:00Z').getUTCDay() + 6) % 7;
    if (period === 'week') return { from: shiftDate(today, -weekday), to: shiftDate(today, 6 - weekday), label: 'This week' };
    if (period === 'lastweek') return { from: shiftDate(today, -weekday - 7), to: shiftDate(today, -weekday - 1), label: 'Last week' };
    if (period === 'month') return { from: today.slice(0, 7) + '-01', to: today, label: 'This month to date' };
    throw new Error('Choose a supported period.');
  }

  function todayInZone(timezone, now) {
    const parts = new Intl.DateTimeFormat('en-US', { timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now || new Date());
    const get = type => parts.find(part => part.type === type).value;
    return get('year') + '-' + get('month') + '-' + get('day');
  }

  function validateDataset(input) {
    if (!input || input.ok !== true) throw new Error(input && input.error ? input.error : 'The CRM did not return leaderboard data. Check that Leaderboard.gs and the doGet change are deployed.');
    if (input.schemaVersion !== 1 || !Array.isArray(input.agents) || !Array.isArray(input.buckets) || !isoDate(input.today)) {
      throw new Error('The CRM endpoint needs the Leaderboard update.');
    }
    const ids = new Set();
    const agents = input.agents.map(agent => {
      if (!agent || typeof agent.id !== 'string' || typeof agent.name !== 'string' || !agent.name.trim() || ids.has(agent.id)) throw new Error('Invalid agent standings from the CRM.');
      ids.add(agent.id);
      return { id: agent.id, name: agent.name };
    });
    const buckets = input.buckets.map(bucket => {
      if (!bucket || !ids.has(bucket.agentId)) throw new Error('Invalid agent totals from the CRM.');
      for (const field of ['submissionDate', 'appointmentDate']) {
        if (typeof bucket[field] !== 'string' || (bucket[field] && !isoDate(bucket[field]))) throw new Error('Invalid appointment reporting date.');
      }
      const clean = { agentId: bucket.agentId, submissionDate: bucket.submissionDate, appointmentDate: bucket.appointmentDate, campaign: String(bucket.campaign || 'Unspecified'), state: String(bucket.state || 'Unspecified') };
      for (const metric of metrics) {
        if (!Number.isSafeInteger(bucket[metric]) || bucket[metric] < 0 || (metric !== 'set' && bucket[metric] > bucket.set)) throw new Error('Invalid appointment totals from the CRM.');
        clean[metric] = bucket[metric];
      }
      return clean;
    });
    const timezone = typeof input.timezone === 'string' ? input.timezone : 'America/New_York';
    todayInZone(timezone);
    if (!Number.isFinite(Date.parse(input.generatedAt))) throw new Error('Invalid CRM refresh timestamp.');
    const statuses = ['Scheduled','Confirmed','Completed','No Show','Rescheduled','Cancelled','DNQ','Pending'];
    if (!Array.isArray(input.calendar)) throw new Error('The CRM endpoint needs the calendar display update.');
    const calendar = input.calendar.map(event => {
      if (!event || !ids.has(event.agentId) || !isoDate(event.date) || (event.time !== '' && !/^([01]\d|2[0-3]):[0-5]\d$/.test(event.time)) || !statuses.includes(event.status)) throw new Error('Invalid team calendar data.');
      return { agentId: event.agentId, date: event.date, time: event.time, state: String(event.state || 'Unspecified'), campaign: String(event.campaign || 'Unspecified'), status: event.status };
    });
    // Keep only whitelisted agent statistics and the customer-free schedule.
    return { ok: true, schemaVersion: 1, agents, buckets, calendar, today: input.today, timezone, generatedAt: input.generatedAt };
  }

  function standings(data, options) {
    const metric = metrics.includes(options.metric) ? options.metric : 'set';
    const basis = options.basis === 'appointment' ? 'appointmentDate' : 'submissionDate';
    const range = periodRange(options.period || 'week', options.today || data.today, options.from, options.to);
    const byAgent = new Map(data.agents.map(agent => [agent.id, { ...agent, ...Object.fromEntries(metrics.map(key => [key, 0])) }]));
    const totals = Object.fromEntries(metrics.map(key => [key, 0]));
    for (const bucket of data.buckets) {
      const date = bucket[basis];
      if (range.from && (!date || date < range.from) || range.to && (!date || date > range.to)) continue;
      if (options.state && bucket.state !== options.state || options.campaign && bucket.campaign !== options.campaign) continue;
      const agent = byAgent.get(bucket.agentId);
      for (const key of metrics) { agent[key] += bucket[key]; totals[key] += bucket[key]; }
    }
    const rows = [...byAgent.values()].filter(agent => agent.set > 0).sort((a, b) => b[metric] - a[metric] || a.name.localeCompare(b.name) || a.id.localeCompare(b.id));
    // Equal scores share a rank. Alphabetical ordering is only for display.
    let rank = 0, previous = null;
    rows.forEach((agent, index) => { if (agent[metric] !== previous) rank = index + 1; agent.rank = rank; previous = agent[metric]; });
    const query = String(options.query || '').trim().toLocaleLowerCase();
    return { range, totals, agentCount: rows.length, rows: query ? rows.filter(agent => agent.name.toLocaleLowerCase().includes(query)) : rows, metric };
  }

  const api = Object.freeze({ metrics, isoDate, shiftDate, periodRange, todayInZone, validateDataset, standings });
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.DCLeaderboardCore = api;
})(typeof window !== 'undefined' ? window : globalThis);
