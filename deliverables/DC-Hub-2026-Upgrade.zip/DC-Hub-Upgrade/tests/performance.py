"""Repeatable UI timing using concurrent delayed service doubles, never live data."""
import asyncio,json,sys,time
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
MODE=sys.argv[1]
SITE=(Path(sys.argv[2]) if MODE=='before' else ROOT)/'hostinger/dc-hub'
BASE='http://127.0.0.1:8081/dc-hub/'
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);c=await b.new_context();calls=[]
  user={'email':'a@example.test','name':'Agent Test','role':'Agent','team':'Team 1','permissions':['dashboard','appointments','analytics','resources']}
  async def route(r):
   rel=r.request.url.removeprefix(BASE).split('?')[0]
   if not r.request.url.startswith(BASE):await r.fulfill(body='');return
   if rel=='auth/whoami.php':await r.fulfill(json={'authenticated':True,'user':user,'csrf':'fixture'});return
   if rel=='api/hub.php':
    action=r.request.post_data_json['action'];calls.append(action);await asyncio.sleep(.25)
    data={'bootstrap':{'user':user,'resources':[],'announcements':[],'goals':[],'teams':[]},'appointments':{'items':[],'total':0},'analytics':{'total':0,'personal':0,'team':0,'confirmed':0,'qualifiedSits':0,'states':[],'agents':[],'campaigns':[],'daily':[]}}.get(action,{})
    await r.fulfill(json={'ok':True,'data':data});return
   f=SITE/(rel or 'index.html')
   if f.is_file():await r.fulfill(path=str(f),content_type={'.html':'text/html','.json':'application/json','.js':'text/javascript','.css':'text/css'}.get(f.suffix,'application/octet-stream'))
   else:await r.fulfill(status=404)
  await c.route('**/*',route);page=await c.new_page();start=time.monotonic();await page.goto(BASE)
  await page.locator('.kpi').first.wait_for()
  await page.wait_for_function("!document.querySelector('.kpis').hasAttribute('aria-busy') || document.querySelector('.kpis').getAttribute('aria-busy')==='false'")
  elapsed=(time.monotonic()-start)*1000
  report={'scope':'Local Chromium, concurrent artificial 250ms delay per Workspace call; not live performance','dashboardReadyMs':round(elapsed),'paint':await page.evaluate("performance.getEntriesByType('paint').map(x=>({name:x.name,ms:x.startTime}))"),'workspaceRequests':calls,'dashboardJsBytes':(SITE/'assets/js/operations.js').stat().st_size}
  (ROOT/'tests'/('performance-'+MODE+'.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report));await b.close()
asyncio.run(main())
