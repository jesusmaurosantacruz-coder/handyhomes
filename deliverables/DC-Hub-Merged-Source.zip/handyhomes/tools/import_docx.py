#!/usr/bin/env python3
"""Deterministic WordprocessingML → scoped HTML. No third-party runtime dependencies."""
import argparse,html,json,re,zipfile,hashlib,shutil
from pathlib import Path
from xml.etree import ElementTree as E
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'; N={'w':W}
def val(e,k='val',default=None):return e.get('{'+W+'}'+k,default) if e is not None else default
def child(e,k):return e.find('w:'+k,N) if e is not None else None
def escape(s):return html.escape(str(s),quote=True)
HIGHLIGHT={'yellow':'ffff00','white':'ffffff','green':'00ff00','cyan':'00ffff','magenta':'ff00ff','blue':'0000ff','red':'ff0000','darkBlue':'000080','darkCyan':'008080','darkGreen':'008000','darkMagenta':'800080','darkRed':'800000','darkYellow':'808000','darkGray':'808080','lightGray':'c0c0c0','black':'000000'}
def convert(src):
 z=zipfile.ZipFile(src); root=E.fromstring(z.read('word/document.xml')); styles=E.fromstring(z.read('word/styles.xml')) if 'word/styles.xml' in z.namelist() else E.Element('styles')
 sm={val(s,'styleId'):s for s in styles.findall('w:style',N)}
 defaults=styles.find('w:docDefaults',N)
 def props(node,kind,base=None):
  d=dict(base or {})
  if node is not None:
   for c in node: d[c.tag.split('}')[-1]]=c
  return d
 def inherited(sid,kind,seen=None):
  seen=set(seen or ());s=sm.get(sid)
  if s is None or sid in seen:return {}
  seen.add(sid);return props(child(s,kind),kind,inherited(val(child(s,'basedOn')),kind,seen))
 def css(p):
  out={}
  def put(k,v):out[k]=v
  for k in ['b','i','strike']:
   if k in p:put({'b':'font-weight','i':'font-style','strike':'text-decoration'}[k],({'b':'bold','i':'italic','strike':'line-through'}[k] if val(p[k],default='1') not in ['0','false','off'] else {'b':'normal','i':'normal','strike':'none'}[k]))
  c=val(p.get('color'))
  if c and re.fullmatch('[a-fA-F0-9]{6}',c):put('color','#'+c)
  bg=HIGHLIGHT.get(val(p.get('highlight')));sh=val(p.get('shd'),'fill')
  if bg:put('background-color','#'+bg)
  elif sh and re.fullmatch('[a-fA-F0-9]{6}',sh):put('background-color','#'+sh)
  sz=val(p.get('sz'))
  if sz and sz.isdigit():put('font-size',str(int(sz)/2)+'pt')
  font=val(p.get('rFonts'),'ascii')
  if font and re.fullmatch('[A-Za-z0-9 ,_-]{1,80}',font):put('font-family',font)
  if 'u' in p:put('text-decoration','none' if val(p['u'])=='none' else 'underline')
  if val(p.get('vertAlign')) in ['superscript','subscript']:put('vertical-align','super' if val(p['vertAlign'])=='superscript' else 'sub')
  if 'spacing' in p:
   s=p['spacing']
   for a,b in [('before','margin-top'),('after','margin-bottom')]:
    v=val(s,a)
    if v and v.isdigit():put(b,str(int(v)/20)+'pt')
   v=val(s,'line');rule=val(s,'lineRule')
   if v and re.fullmatch(r'\d+(?:\.\d+)?',v):put('line-height',str(float(v)/240) if rule in [None,'auto'] else str(float(v)/20)+'pt')
  align=val(p.get('jc'))
  if align in ['left','center','right','both']:put('text-align','justify' if align=='both' else align)
  return ';'.join(k+':'+v for k,v in out.items())
 defaultR=props(defaults.find('w:rPrDefault/w:rPr',N) if defaults is not None else None,'rPr')
 defaultP=props(defaults.find('w:pPrDefault/w:pPr',N) if defaults is not None else None,'pPr')
 def paragraph(p):
  pp=child(p,'pPr');sid=val(child(pp,'pStyle')) or 'Normal';ps=props(pp,'pPr',{**defaultP,**inherited(sid,'pPr')});rb={**defaultR,**inherited(sid,'rPr')};runs=[]
  for r in p.findall('.//w:r',N):
   rp=child(r,'rPr');rs=val(child(rp,'rStyle'));pr=props(rp,'rPr',{**rb,**inherited(rs,'rPr')});text=''
   for n in r:
    tag=n.tag.split('}')[-1]
    if tag=='t':text+=escape(n.text or '')
    elif tag in ['br','cr']:text+='<br>'
    elif tag=='tab':text+='&#9;'
   if text:runs.append('<span style="'+escape(css(pr))+'">'+text+'</span>')
  num=child(pp,'numPr');tag='p'
  if re.search('heading[1-6]',sid,re.I):tag='h'+re.search('[1-6]',sid).group()
  content=''.join(runs) or '<br>'
  if num is not None:
   # Resolve explicit numbering formats from the source numbering definitions.
   content='<span class="doc-list-marker">'+('• ' if 'bullet' in numbering.get(val(child(num,'numId')),'bullet') else str(counters.setdefault(val(child(num,'numId')),0)+1)+'. ')+'</span>'+content
   counters[val(child(num,'numId'))]=counters.get(val(child(num,'numId')),0)+1
  return '<'+tag+' style="'+escape(css(ps))+'">'+content+'</'+tag+'>'
 numbering={};counters={}
 if 'word/numbering.xml' in z.namelist():
  nr=E.fromstring(z.read('word/numbering.xml'));ab={val(a,'abstractNumId'):val(a.find('w:lvl/w:numFmt',N)) for a in nr.findall('w:abstractNum',N)}
  numbering={val(n,'numId'):ab.get(val(child(n,'abstractNumId')),'bullet') for n in nr.findall('w:num',N)}
 def render(n):
  tag=n.tag.split('}')[-1]
  if tag=='p':return paragraph(n)
  if tag=='tbl':return '<table><tbody>'+''.join('<tr>'+''.join('<td>'+''.join(render(c) for c in td if c.tag.split('}')[-1] in ['p','tbl'])+'</td>' for td in tr.findall('w:tc',N))+'</tr>' for tr in n.findall('w:tr',N))+'</tbody></table>'
  return ''
 body=root.find('w:body',N);out='<article class="source-document">'+''.join(render(n) for n in body)+'</article>\n'
 source=''.join(t.text or '' for t in body.findall('.//w:t',N))
 from html.parser import HTMLParser
 class Text(HTMLParser):
  def __init__(self):super().__init__();self.text=''
  def handle_data(self,d):self.text+=d
 # Every original run must occur in order; no copy rewrite.
 cursor=0
 for t in body.findall('.//w:t',N):
  s=escape(t.text or '');idx=out.find(s,cursor)
  if s and idx<0:raise ValueError('Lost source text')
  if s:cursor=idx+len(s)
 return out,{'source':src.name,'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'paragraphs':len(body.findall('.//w:p',N)),'runs':len(body.findall('.//w:r',N)),'sourceCharacters':len(source),'textPreserved':True}
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('source',type=Path);a.add_argument('destination',type=Path);args=a.parse_args();out,report=convert(args.source);args.destination.write_text(out);print(json.dumps(report))
