# Architecture and merge decisions

Original archive: preservation baseline, 91 entries (including directory entries and 19 historical backups). Release 4: candidate upgrade, 27 files; not a full application despite its README claim. Original authentication, manager identity (jesus), elevated one-hour editor unlock, CSRF, all campaign IDs/CRM aliases, artwork, calendar and leaderboard remain authoritative. Production auth/config.php must remain on the host and is excluded from the distributable.

Dependency map: Apache .htaccess → auth/serve.php → session.php/config.php → protected pages, JSON, scripts and notes. login.php → regenerated PHP session. hub.js → campaigns/resources/schedule/team/site JSON; leaderboard config/core/client → existing CRM Apps Script; calendar uses the same read-only CRM payload. admin/index.php → elevated unlock → admin/api.php → validated JSON/HTML + backups. Release 4 station → campaign data + scripts + market notes + Google Forms or local Fiber handoff.

Gaps identified before implementation:
- Release 4 omits auth, leaderboard, calendar and other original files. A partial overwrite/deployment can leave 404s.
- Original script sanitization removes formatting; Release 4 browser sanitization does too. Dark reader CSS overrides deliberate source colors.
- Separate station and dashboard campaign files can drift. Consolidate into campaigns.json while preserving original IDs, CRM aliases, visibility and dialer URLs.
- Original resource schema supports documents only; extend to validated internal/external links and manager ordering.
- Typing HTML has 25 lessons, Merida rotation, roster, local streaks and an opaque no-cors POST incorrectly implying delivery. Retain test and replace integration boundary.
- Audio/video assets are absent. Add private metadata-driven libraries and manager upload/metadata controls, with honest empty states.
- No Fiber DOCX or final provider URL supplied. Preserve Release 4 Fiber script/handoff; report missing authoritative replacement.
- No Hostinger credentials or active typing deployment supplied. Local QA and integration instructions cannot establish production behavior.

Implementation: retain original PHP architecture, merge Release 4 station and market notes, regenerate latest scripts from WordprocessingML (including styles, runs, shading, paragraphs and tables), use white document surfaces, extend existing manager, gate all new content. Typing proxy authenticates requests, validates CSRF, uses a server-only backend key, and confirms JSON acknowledgments; scores remain self-reported. No CRM writes are introduced by Hub changes. Supplied CRM Apps Script files are reference integrations, not automatically installed or run.

Preservation: original ZIP stays untouched in uploaded attachments. docs/CHANGELOG.json records every baseline file and final disposition/hash. Existing server config and content require backup/staging reconciliation on deployment. No passwords are reset.
