"""Create a self-contained upload/source bundle; never includes external uploads or secrets."""
from pathlib import Path
import hashlib,zipfile,sys,json
root=Path(__file__).resolve().parents[1]
destination=Path(sys.argv[1]) if len(sys.argv)>1 else root.parent/'deliverables/DC-Hub-Upgrade-Upload.zip'
destination.parent.mkdir(parents=True,exist_ok=True)
files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.zip'] and p.name!='SHA256SUMS.txt')
for p in files:
 if p.name in ['dc-hub-config.php','config.php','typing-config.php']:
  raise SystemExit('Refusing to package credential configuration: '+str(p))
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(root))+'\n' for p in files)
(root/'SHA256SUMS.txt').write_text(manifest)
files.append(root/'SHA256SUMS.txt')
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,'DC-Hub-Upgrade/'+str(p.relative_to(root)))
with zipfile.ZipFile(destination) as z:
 assert z.testzip() is None
 names=set(z.namelist())
 assert 'DC-Hub-Upgrade/hostinger/dc-hub/.htaccess' in names
 assert 'DC-Hub-Upgrade/apps-script/appsscript.json' in names
 assert 'DC-Hub-Upgrade/START-HERE.md' in names
 for p in files:
  assert z.read('DC-Hub-Upgrade/'+str(p.relative_to(root)))==p.read_bytes()
print(json.dumps({'archive':str(destination),'files':len(files),'bytes':destination.stat().st_size,'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'zipIntegrity':'passed'}))
