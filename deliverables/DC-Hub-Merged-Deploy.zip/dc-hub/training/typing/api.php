<?php
declare(strict_types=1);
require_once __DIR__.'/../../auth/session.php';
header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');
function typing_reply(int $code,array $data): never{http_response_code($code);echo json_encode($data);exit;}
if(!dc_is_authenticated())typing_reply(401,['ok'=>false,'error'=>'Authentication required']);
$cfg=is_file(__DIR__.'/../../auth/typing-config.php')?require __DIR__.'/../../auth/typing-config.php':require __DIR__.'/../../auth/typing-config.example.php';
$connected=!empty($cfg['key'])&&preg_match('~^https://script\.google\.com/macros/s/[A-Za-z0-9_-]+/exec$~D',(string)($cfg['url']??''));
$roster=json_decode(file_get_contents(__DIR__.'/../../assets/data/typing.json'),true)['agents'];
$action=(string)($_GET['action']??'config');
if($_SERVER['REQUEST_METHOD']==='GET'&&$action==='config')typing_reply(200,['ok'=>true,'configured'=>(bool)$connected,'agents'=>$roster,'csrf'=>dc_token(),'isManager'=>($_SESSION['dc_user_id']??'')==='jesus']);
if(!$connected)typing_reply(503,['ok'=>false,'error'=>'Google Sheets is not configured. Results remain on this device.']);
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!dc_csrf_valid((string)($_SERVER['HTTP_X_CSRF_TOKEN']??'')))typing_reply(403,['ok'=>false,'error'=>'Session verification failed']);
 $raw=file_get_contents('php://input');if(strlen($raw)>4000)typing_reply(413,['ok'=>false,'error'=>'Request too large']);
 $p=json_decode($raw,true);if(!is_array($p))typing_reply(422,['ok'=>false,'error'=>'Invalid result']);
 if(!in_array($p['agent']??'',$roster,true))typing_reply(422,['ok'=>false,'error'=>'Choose an approved agent']);
 if(!preg_match('/^[a-zA-Z0-9-]{12,80}$/D',(string)($p['attemptId']??'')))typing_reply(422,['ok'=>false,'error'=>'Invalid attempt']);
 foreach(['wpm'=>[1,220],'accuracy'=>[0,100],'seconds'=>[10,10800],'lesson'=>[0,24]] as $field=>$range)if(!isset($p[$field])||!is_numeric($p[$field])||$p[$field]<$range[0]||$p[$field]>$range[1])typing_reply(422,['ok'=>false,'error'=>'Invalid '.$field]);
 $payload=array_intersect_key($p,array_flip(['attemptId','agent','lesson','title','wpm','accuracy','seconds']));$payload['action']='submit';$payload['complete']='true';
 // Log provenance, not a claim of verified performance or identity of the selected roster name.
 $payload['submittedBy']=(string)($_SESSION['dc_user_id']??'');
}elseif($_SERVER['REQUEST_METHOD']==='GET'&&$action==='results'){
 if(($_SESSION['dc_user_id']??'')!=='jesus')typing_reply(403,['ok'=>false,'error'=>'Manager access required']);
 $payload=['action'=>'results'];
}else typing_reply(405,['ok'=>false,'error'=>'Unsupported action']);
$payload['key']=$cfg['key'];
session_write_close();
$ch=curl_init($cfg['url']);curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($payload),CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>3,CURLOPT_TIMEOUT=>25,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_PROTOCOLS=>CURLPROTO_HTTPS,CURLOPT_REDIR_PROTOCOLS=>CURLPROTO_HTTPS]);
$body=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
$result=is_string($body)?json_decode($body,true):null;
if($code!==200||!is_array($result)||!isset($result['ok']))typing_reply(502,['ok'=>false,'error'=>'No valid acknowledgment from Google Sheets. Your local progress is saved; retry with the same submission ID.']);
if(!$result['ok'])typing_reply(422,['ok'=>false,'error'=>'Google Sheets rejected this result. Check roster, daily lesson, time and backend configuration.']);
typing_reply(200,$result);
