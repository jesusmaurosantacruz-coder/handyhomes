"""Build complete runtime/source/evidence ZIPs, excluding runtime credentials and local data."""
from pathlib import Path
import zipfile,hashlib,json
ROOT=Path(__file__).resolve().parents[1];OUT=Path('/workspace/deliverables');OUT.mkdir(exist_ok=True)
private_names={'config.php','typing-config.php'}
def allowed(p):
 rel=p.relative_to(ROOT)
 return p.is_file() and not any(x in rel.parts for x in ['.git','__pycache__','backups']) and p.name not in private_names and p.suffix not in ['.pyc','.bak','.zip'] and not (str(rel).startswith('training/media/') and p.name!='.htaccess')
runtime_dirs={'admin','assets','auth','calendar','campaigns','dialing-station','leaderboard','resources','training','private'}
files=[p for p in ROOT.rglob('*') if allowed(p)]
for name,source in [('DC-Hub-Merged-Deploy.zip',False),('DC-Hub-Merged-Source.zip',True)]:
 with zipfile.ZipFile(OUT/name,'w',compression=zipfile.ZIP_DEFLATED) as z:
  for p in sorted(files):
   rel=p.relative_to(ROOT)
   if source or rel.parts[0] in runtime_dirs or str(rel) in ['index.html','login.php','logout.php','.htaccess']:
    z.write(p,('handyhomes/' if source else 'dc-hub/')+str(rel))
  # Empty backup directory guard remains part of the runtime contract.
  z.write(ROOT/'admin/backups/.htaccess',('handyhomes/' if source else 'dc-hub/')+'admin/backups/.htaccess')
  if not source:z.write(ROOT/'docs/DEPLOYMENT.md','DEPLOYMENT-GUIDE.md')
 with zipfile.ZipFile(OUT/name) as z:
  names=z.namelist();assert not any(n.endswith('/auth/config.php') or n.endswith('/auth/typing-config.php') for n in names)
  assert z.testzip() is None
  prefix='handyhomes/' if source else 'dc-hub/'
  for required in ['login.php','auth/session.php','assets/data/campaigns.json','dialing-station/index.html','leaderboard/index.html','calendar/index.html','training/typing/index.html','training/audio/index.html','training/videos/index.html','admin/index.php','admin/backups/.htaccess']:
   assert prefix+required in names,required
qa=Path('/workspace/qa-artifacts')
with zipfile.ZipFile(OUT/'DC-Hub-QA-Evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for p in qa.iterdir():
  if p.suffix in ['.png','.html','.json','.txt']:z.write(p,p.name)
checksums={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob('*.zip')}
(OUT/'SHA256SUMS.txt').write_text(''.join(f'{h}  {n}\n' for n,h in checksums.items()))
print(json.dumps({'packages':[{ 'name':p.name,'bytes':p.stat().st_size} for p in OUT.glob('*.zip')],'credentialFilesIncluded':False},indent=2))
