/* Display only approved elements and constrained inline document formatting. */
window.DCContent = Object.freeze({parse(html){
 const d=new DOMParser().parseFromString(html,'text/html');
 const allowed=new Set('ARTICLE HEADER SECTION DIV SPAN SMALL H1 H2 H3 H4 H5 H6 P B STRONG EM I U S UL OL LI BLOCKQUOTE A BR HR MARK TABLE THEAD TBODY TR TH TD'.split(' '));
 const properties=new Set('color background-color font-weight font-style text-decoration text-decoration-line font-size font-family text-align vertical-align margin-top margin-bottom line-height'.split(' '));
 for(const el of [...d.body.querySelectorAll('*')]){
  if(!allowed.has(el.tagName)){el.remove();continue;}
  for(const a of [...el.attributes]){
   if(a.name==='style'){
    const style=document.createElement('span').style;style.cssText=a.value;const clean=[];
    for(const key of style){const value=style.getPropertyValue(key);if(properties.has(key)&&!/url|expression|var\(|\\|@|[<>]/i.test(value))clean.push(key+':'+value);}
    el.setAttribute('style',clean.join(';'));
   }else if(a.name==='class'&&/^[a-zA-Z0-9 _-]{1,180}$/.test(a.value))continue;
   else if(a.name==='href'&&el.tagName==='A'&&/^https:\/\//.test(a.value))continue;
   else el.removeAttribute(a.name);
  }
  if(el.tagName==='A'){el.target='_blank';el.rel='noopener noreferrer';}
 }
 return d.body;
}});
