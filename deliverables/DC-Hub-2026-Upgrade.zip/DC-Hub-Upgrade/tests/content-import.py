"""Verify output against the supplied DOCX/JSON inputs, not fabricated fixtures."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json
from lxml import etree as E,html as H
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'hostinger/dc-hub';W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';N={'w':W[1:-1]};checks=[]
def check(name,ok):
 assert ok,name
 checks.append(name);print('PASS '+name,flush=True)
manifest=json.loads((ROOT/'source-documents/content-manifest.json').read_text());report=json.loads((ROOT/'docs/CONTENT-IMPORT-2026-11-02.json').read_text())
for entry in manifest['scripts']:
 with ZipFile(ROOT/entry['source']) as z:doc=E.fromstring(z.read('word/document.xml'),E.XMLParser(resolve_entities=False,no_network=True))
 raw=(ROOT/entry['target']).read_text();html=H.fragment_fromstring(raw);out=''.join(html.itertext());source=''.join(doc.xpath('//w:t/text()',namespaces=N));check(entry['title']+' exact text preserved',out.replace('\t','').replace('\n','')==source.replace('\t','').replace('\n',''))
 check(entry['title']+' paragraph and table structure preserved',len(html.xpath('.//p|.//h1|.//h2|.//h3|.//h4|.//h5|.//h6'))==len(doc.findall('.//w:p',N)) and len(html.xpath('.//table'))==len(doc.findall('.//w:tbl',N)))
 # Run boundaries make emphasis changes testable even when the same words occur repeatedly.
 source_runs=[r for r in doc.findall('.//w:r',N) if r.xpath('w:t|w:br|w:cr|w:tab|w:noBreakHyphen|w:softHyphen',namespaces=N)]
 spans=html.xpath('.//span');check(entry['title']+' visible run boundaries preserved',len(spans)==len(source_runs))
 for original,span in zip(source_runs,spans):
  color=original.find('w:rPr/w:color',N);highlight=original.find('w:rPr/w:highlight',N);shade=original.find('w:rPr/w:shd',N);style=span.attrib.get('style','').lower()
  if color is not None and len(color.get(W+'val',''))==6:assert 'color:#'+color.get(W+'val').lower() in style
  if highlight is not None and highlight.get(W+'val')=='yellow':assert 'background-color:#ffff00' in style
  elif shade is not None and len(shade.get(W+'fill',''))==6:assert 'background-color:#'+shade.get(W+'fill').lower() in style
 check(entry['title']+' direct colors and highlights preserved',True)
 item=next(x for x in report['scripts'] if x['source']==entry['source']);check(entry['title']+' source fingerprint matches',hashlib.sha256((ROOT/entry['source']).read_bytes()).hexdigest()==item['sourceSha256'])
for entry in report['markets']:
 original=json.loads((ROOT/entry['source']).read_text());data=json.loads((ROOT/entry['target']).read_text());check(original['market_id']+' every source field preserved',data['approvedSource']==original);check(original['market_id']+' no invented eligibility values',all(v is None or v==[] for v in data['approvedSource']['admin_config'].values()));check(original['market_id']+' exact hooks preserved',data['salesHooks']==original['opening_questions']);check(original['market_id']+' updated notes have current source fingerprint',hashlib.sha256((SITE/data['source']['localPath']).read_bytes()).hexdigest()==data['source']['sha256'])
lib=json.loads((SITE/'assets/data/library.json').read_text());check('Value Builders and New Jersey are discoverable',all(any(x['path']==target for x in lib['resources']) for target in ['assets/scripts/solar-value-builders.html','assets/market-notes/new-jersey.html']))
(ROOT/'tests/content-import-results.json').write_text(json.dumps({'passed':len(checks),'checks':checks,'scope':'Exact uploaded content/formatting fidelity; not independent verification of sales claims'},indent=2))
print('Completed',len(checks),'content import checks')
