/**
 * DC Hub Daily Typing — standalone Apps Script for Solar PreQual Form 2027.
 * IMPORTANT: Make a NEW, standalone Apps Script project at script.google.com,
 * NOT inside the existing prequal script project. Do not replace existing scripts.
 * Deploy as Me / Anyone; all data actions require Script Property TYPING_API_KEY via the Hub server proxy.
 * Your workbook already contains the Typing Test, Typing Assets, and Typing Leaderboard tabs.
 * Agent roster: edit Typing Assets!A2:B (A = display name, B = Active checkbox).
 */
const DC_TYPING = {
  spreadsheetId: '1EB8gX-hT9ohp64YC3qtFjvVaQZuFM7fRHMWEQQTrcb8',
  resultsTab: 'Typing Test',
  assetsTab: 'Typing Assets',
  tz: 'America/Merida',
  firstLesson: '2026-10-29',
  lessons: 25,
  minAccuracy: 90,
};

function typingSafeCell_(value){return /^[=+@-]/.test(value)?"'"+value:value;}

function typingBook_() {
  return SpreadsheetApp.openById(DC_TYPING.spreadsheetId);
}

// Optional one-click check after pasting this file. Does not clear any data.
function checkTypingSetup() {
  const ss = typingBook_();
  const results = ss.getSheetByName(DC_TYPING.resultsTab);
  const roster = ss.getSheetByName(DC_TYPING.assetsTab);
  if (!results || !roster) throw new Error('Missing typing tabs in Solar PreQual Form 2027.');
  Logger.log('Typing Test ready. Approved names: ' + activeTypingNames_(ss).join(', '));
}

function activeTypingNames_(ss) {
  const sh = (ss || typingBook_()).getSheetByName(DC_TYPING.assetsTab);
  if (!sh) throw new Error('Typing Assets sheet not found.');
  const last = sh.getLastRow();
  if (last < 2) return [];
  const values = sh.getRange(2, 1, Math.min(149, last - 1), 2).getValues();
  const names = [];
  values.forEach(row => {
    const name = String(row[0] || '').trim().replace(/\s+/g, ' ');
    const enabled = row[1] === true || String(row[1]).toLowerCase() === 'true';
    if (name && enabled && !names.some(x => x.toLowerCase() === name.toLowerCase())) names.push(name);
  });
  return names;
}

function typingDate_() { return Utilities.formatDate(new Date(), DC_TYPING.tz, 'yyyy-MM-dd'); }
function lessonForDate_(date) {
  const days = Math.round((Date.parse(date + 'T00:00:00Z') - Date.parse(DC_TYPING.firstLesson + 'T00:00:00Z')) / 86400000);
  return ((days % DC_TYPING.lessons) + DC_TYPING.lessons) % DC_TYPING.lessons;
}
function typingJson_(object, callback) {
  const json = JSON.stringify(object);
  if (callback && /^[a-zA-Z_$][\w$]*$/.test(callback)) {
    return ContentService.createTextOutput(callback + '(' + json + ');').setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {return typingJson_({ok:false,error:'Use authenticated Hub proxy'});}

function doPost(e) {
  try {
    const p = (e && e.parameter) || {};
    const key=PropertiesService.getScriptProperties().getProperty('TYPING_API_KEY');
    if(!key||typeof p.key!=='string'||p.key!==key)throw Error('Unauthorized');
    if(p.action==='results')return typingJson_({ok:true,html:typingLeaderboardHtml_()});
    const id = String(p.attemptId || '').trim();
    const requestedName = String(p.agent || '').trim().replace(/\s+/g, ' ');
    const lessonIndex = Number(p.lesson);
    const wpm = Number(p.wpm);
    const accuracy = Number(p.accuracy);
    const seconds = Number(p.seconds);
    const title = typingSafeCell_(String(p.title || '').trim().slice(0,125));
    const date = typingDate_();
    if (!/^[a-zA-Z0-9-]{12,80}$/.test(id)) throw new Error('Invalid attempt id');
    if (!Number.isInteger(lessonIndex) || lessonIndex !== lessonForDate_(date)) throw new Error('Wrong daily lesson');
    if (!Number.isFinite(wpm) || wpm < 1 || wpm > 220) throw new Error('Invalid WPM');
    if (!Number.isFinite(accuracy) || accuracy < 0 || accuracy > 100) throw new Error('Invalid accuracy');
    if (!Number.isFinite(seconds) || seconds < 10 || seconds > 10800) throw new Error('Invalid time');

    const ss = typingBook_();
    const match = activeTypingNames_(ss).find(n => n.toLowerCase() === requestedName.toLowerCase());
    if (!match) throw new Error('Name is not on the approved active roster');
    const results = ss.getSheetByName(DC_TYPING.resultsTab);
    if (!results) throw new Error('Typing Test tab not found');

    const lock = LockService.getScriptLock();
    lock.waitLock(20000);
    try {
      const last = results.getLastRow();
      if (last > 1 && results.getRange(2,10,last-1,1)
        .createTextFinder(id).matchEntireCell(true).findNext()) {
        return typingJson_({ok:true,duplicate:true});
      }
      results.appendRow([new Date(), date, typingSafeCell_(match), lessonIndex + 1, title, wpm,
        accuracy, seconds, accuracy >= DC_TYPING.minAccuracy ? 'Passed' : 'Retry', id, typingSafeCell_(String(p.submittedBy||'')), 'Self-reported practice result']);
    } finally { lock.releaseLock(); }
    return typingJson_({ok:true,attemptId:id});
  } catch (error) {
    return typingJson_({ok:false,error:String(error.message || error)});
  }
}

// Optional standalone leaderboard: visit the deployed /exec URL or embed in your Hub.
function typingLeaderboardHtml_() {
  const sh=typingBook_().getSheetByName(DC_TYPING.resultsTab);
  const today=typingDate_();
  const weekStart=Utilities.formatDate(new Date(Date.now()-6*86400000),DC_TYPING.tz,'yyyy-MM-dd');
  const best={};
  if(sh && sh.getLastRow()>1) {
    sh.getRange(2,1,sh.getLastRow()-1,10).getValues().forEach(r=>{
      const date=r[1] instanceof Date?Utilities.formatDate(r[1],DC_TYPING.tz,'yyyy-MM-dd'):String(r[1]);
      if(r[8]!=='Passed'||date<weekStart||date>today)return;
      const name=String(r[2]),wpm=Number(r[5]),acc=Number(r[6]),key=name+'|'+date;
      if(!best[key]||wpm>best[key].wpm||(wpm===best[key].wpm&&acc>best[key].acc))best[key]={date,name,wpm,acc};
    });
  }
  const day=Object.values(best).filter(x=>x.date===today).sort((a,b)=>b.wpm-a.wpm||b.acc-a.acc);
  const summary={};
  Object.values(best).forEach(x=>{
    const s=summary[x.name]||(summary[x.name]={name:x.name,days:0,total:0,best:0});
    s.days++;s.total+=x.wpm;s.best=Math.max(s.best,x.wpm);
  });
  const week=Object.values(summary).map(x=>({...x,avg:Math.round(x.total/x.days)}))
    .sort((a,b)=>b.days-a.days||b.avg-a.avg);
  const h=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const d=day.map((x,i)=>`<tr><td>${i+1}</td><td>${h(x.name)}</td><td>${x.wpm}</td><td>${x.acc}%</td></tr>`).join('')||'<tr><td colspan="4">No completed tests today</td></tr>';
  const w=week.map((x,i)=>`<tr><td>${i+1}</td><td>${h(x.name)}</td><td>${x.days}</td><td>${x.avg}</td></tr>`).join('')||'<tr><td colspan="4">No completed tests yet</td></tr>';
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="60"><style>
  *{box-sizing:border-box}body{margin:0;background:#181a1d;color:#e1e4e8;font:14px system-ui,sans-serif;padding:24px}h1{font-size:22px;margin:0 0 6px}
  p{color:#9299a2;font-size:12px;margin:0 0 25px}.cols{display:grid;grid-template-columns:1fr 1fr;gap:18px}
  section{border:1px solid #373a42;background:#21252a;border-radius:10px;padding:18px}h2{font-size:14px;color:#e5b85b;margin:0 0 16px}
  table{border-collapse:collapse;width:100%}th,td{padding:9px 7px;text-align:left;border-bottom:1px solid #353941}th{font-size:11px;color:#9098a2}td:nth-child(n+3){text-align:right}th:nth-child(n+3){text-align:right}td:first-child{color:#e5b85b}@media(max-width:750px){.cols{grid-template-columns:1fr}body{padding:12px}}</style></head>
  <body><h1>DC Hub · Typing Leaderboard</h1><p>Best qualified result per agent each day · 90%+ accuracy · Mérida time · refreshes every 60 seconds</p>
  <div class="cols"><section><h2>Today · ${today}</h2><table><thead><tr><th>#</th><th>Agent</th><th>WPM</th><th>Accuracy</th></tr></thead><tbody>${d}</tbody></table></section>
  <section><h2>Last 7 days</h2><table><thead><tr><th>#</th><th>Agent</th><th>Days</th><th>Avg WPM</th></tr></thead><tbody>${w}</tbody></table></section></div></body></html>`;
}
