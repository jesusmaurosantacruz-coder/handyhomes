<?php
/** Metadata only. Never returns email lists or hashes. */
declare(strict_types=1);
require_once __DIR__.'/session.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
if (!dc_is_authenticated()) { http_response_code(401); echo '{"authenticated":false}'; exit; }
echo json_encode(['authenticated'=>true,'isManager'=>($_SESSION['dc_user_id']??'')==='jesus']);
