"""Uploaded content through actual browser modules; synthetic session identity only."""
from pathlib import Path
from zipfile import ZipFile
from lxml import etree as E
import json,re
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];SITE=ROOT/'hostinger/dc-hub';BASE='http://127.0.0.1:8081/dc-hub/';checks=[];calls=[]
manifest=json.loads((ROOT/'source-documents/content-manifest.json').read_text())
def check(name,ok):assert ok,name;checks.append(name);print('PASS '+name,flush=True)
def source_text(name):
 item=next(x for x in manifest['scripts'] if Path(x['target']).stem==name)
 with ZipFile(ROOT/item['source']) as z:d=E.fromstring(z.read('word/document.xml'),E.XMLParser(resolve_entities=False,no_network=True))
 return ''.join(d.xpath('//w:t/text()',namespaces={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'})).replace('\n','').replace('\t','')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);ctx=b.new_context(viewport={'width':1440,'height':1000});page=ctx.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 def route(r):
  if not r.request.url.startswith(BASE):r.fulfill(status=200,body='External destination intercepted for local content QA');return
  rel=r.request.url[len(BASE):].split('?')[0]
  if rel=='auth/whoami.php':r.fulfill(json={'authenticated':True,'user':{'name':'Content QA','email':'content@example.test','role':'Agent','permissions':['dashboard','resources','dialing']},'csrf':'fixture'});return
  if rel=='api/hub.php':calls.append(r.request.post_data_json);r.fulfill(status=503,json={'ok':False,'error':'Workspace deliberately unavailable in this test'});return
  file=(SITE/(rel or 'index.html')).resolve()
  if file.is_relative_to(SITE) and file.is_file():r.fulfill(path=str(file),content_type={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg'}.get(file.suffix,'application/octet-stream'));return
  r.fulfill(status=404)
 ctx.route('**/*',route);page.goto(BASE+'dialing-station/index.html');page.wait_for_function("document.getElementById('campaign').options.length>0")
 def script(name):
  expected=source_text(name);page.wait_for_function("text=>document.getElementById('script-body').textContent.replace(/[\\n\\t]/g,'')===text",arg=expected);check(name+' browser text exactly matches uploaded DOCX',True)
 for campaign,name in [('texas','battery-backup'),('maryland-solar','net-metering'),('roofing','roofing'),('fiber','fiber'),('warm-reschedule','warm-reschedule')]:
  page.select_option('#campaign',campaign);script(name)
 page.select_option('#campaign','texas');script('battery-backup');page.wait_for_function("document.querySelector('#notes-body h2')?.textContent.includes('TEXAS')")
 check('Texas uses latest supplied market notes',"Was last summer's bill more painful than the outages?" in page.locator('#notes-body').inner_text())
 check('ERCOT is not offered as a service utility',not any('ERCOT' in s for s in page.locator('#utility option').all_text_contents()))
 colors=page.locator('#script-body span').evaluate_all("nodes=>nodes.map(e=>getComputedStyle(e).color)");check('Uploaded red and blue emphasis render',all(x in colors for x in ['rgb(255, 0, 0)','rgb(0, 0, 255)']))
 highlights=page.locator('#script-body span').evaluate_all("nodes=>nodes.map(e=>getComputedStyle(e).backgroundColor)");check('Uploaded pale highlighting renders on white', 'rgb(255, 242, 150)' in highlights and page.locator('#script-body').evaluate("e=>getComputedStyle(e).backgroundColor")=='rgb(255, 255, 255)')
 for button,name in [('open-value-builders','solar-value-builders'),('open-one-liners','solar-one-liners'),('open-logic','script-logic')]:
  page.locator('#'+button).click();script(name);check(name+' has return-to-campaign control',page.locator('#return-script').is_visible())
 check('Script Logic table and bullet structure render',page.locator('#script-body table').count()==1 and page.locator('#script-body li').count()==39)
 page.locator('#return-script').click();script('battery-backup');check('Returning to campaign restores its status',page.locator('#status').inner_text()=='Texas · ready')
 for id in ['new-jersey','maryland','virginia','pennsylvania','south-carolina','southern-california','florida','texas']:
  page.select_option('#market',id);entry=json.loads((SITE/'assets/data/markets'/f'{id}.json').read_text());page.wait_for_function("title=>document.querySelector('#notes-body h2')?.textContent===title",arg=entry['name']);check(id+' uploaded notes and hooks render',entry['salesHooks'][0] in page.locator('#notes-body').inner_text())
 page.screenshot(path=str(ROOT/'tests/evidence/uploaded-market-and-script.png'),full_page=True)
 page.set_viewport_size({'width':390,'height':844});check('Expanded station toolbar fits mobile',page.evaluate('document.documentElement.scrollWidth<=innerWidth'));page.screenshot(path=str(ROOT/'tests/evidence/uploaded-station-mobile.png'),full_page=True)
 page.goto(BASE+'resources/index.html');page.get_by_role('link',name=re.compile('Solar Value Builders')).wait_for();check('New Value Builders is in Documents / Resources',page.locator('a[href$="assets/scripts/solar-value-builders.html"]').count()==1)
 check('All supplied content works with Workspace unavailable',not calls);check('Uploaded content produces no JavaScript exceptions',not errors);b.close()
(ROOT/'tests/content-browser-results.json').write_text(json.dumps({'passed':len(checks),'checks':checks,'scope':'Local browser UI with synthetic identity; Workspace explicitly unavailable; no external requests'},indent=2))
print('Completed',len(checks),'uploaded-content browser checks')
