export async function localResources(root=''){
 const r=await fetch(root+'assets/data/library.json',{credentials:'same-origin',cache:'no-cache'});if(!r.ok)throw Error('Local resource index is unavailable.');const d=await r.json();
 if(!Array.isArray(d.resources))throw Error('Your resource library is temporarily unavailable.');
 return d.resources.filter(x=>/^assets\/(?:scripts|market-notes|library)\/[\w/-]+\.(?:html|pdf|txt|png|webp|jpg)$/i.test(x.path)).map(x=>({...x,url:root+x.path,target:'_blank'}));
}
