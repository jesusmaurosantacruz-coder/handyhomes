"""Before/after screenshots, with external destinations intercepted and labeled."""
from playwright.sync_api import sync_playwright
from pathlib import Path
OUT=Path('/workspace/qa-artifacts');OUT.mkdir(exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 c=b.new_context(viewport={'width':1366,'height':900});c.route('**/*',lambda r:r.continue_() if r.request.url.startswith('http://127.0.0.1:8080/') else r.fulfill(status=200,content_type='text/html',body='<html><body style="font:14px system-ui;padding:20px;color:#31516a">External content is not previewed in local visual QA. Use the form action to open Google Forms.</body></html>'))
 page=c.new_page()
 for base,title in [('baseline','baseline'),('release4','release4'),('dc-hub','merged')]:
  url='http://127.0.0.1:8080/'+base+'/'
  page.goto(url+'logout.php');page.goto(url+'login.php');page.fill('#email','agent@example.test');page.fill('#password','Local-test-pass-2026');page.click('button[type=submit]');page.wait_for_url(url);page.wait_for_selector('[data-campaign-list] .campaign-card');page.screenshot(path=str(OUT/(title+'-dashboard.png')),full_page=True)
  if base=='baseline':
   page.get_by_role('heading',name='Solar One-Liners',exact=True).locator('..').get_by_role('button').click();page.wait_for_timeout(300);page.screenshot(path=str(OUT/'baseline-one-liners.png'),full_page=True)
  else:
   page.goto(url+'dialing-station/index.html');page.wait_for_selector('#campaign option',state='attached');page.select_option('#campaign','maryland' if base=='release4' else 'maryland-solar');page.wait_for_function("!document.querySelector('#script-body').textContent.includes('Loading…') && !document.querySelector('#notes-body').textContent.includes('Loading…')");page.screenshot(path=str(OUT/(title+'-station-net-metering.png')),full_page=True)
   if base=='dc-hub':
    page.locator('#focus-script').click();page.locator('#script-body').evaluate('(el)=>el.scrollTop=100');page.screenshot(path=str(OUT/'merged-focused-reader.png'),full_page=True);page.keyboard.press('Escape');page.select_option('#campaign','socal-solar');page.wait_for_function("!document.querySelector('#script-body').textContent.includes('Loading…') && !document.querySelector('#notes-body').textContent.includes('Loading…')");page.screenshot(path=str(OUT/'merged-station-battery.png'),full_page=True)
 b.close()
html='''<!doctype html><html><head><meta charset="utf-8"><title>DC Hub visual comparisons</title><style>body{font:16px system-ui;background:#06111d;color:#dbe9f2;margin:30px}section{display:grid;grid-template-columns:1fr 1fr;gap:20px}img{width:100%;border:1px solid #456073}a{color:#9adaff}</style></head><body><h1>DC Hub local visual review</h1><p>Original archive and Release 4 references compared with the merged release. External content was intercepted; screenshots do not establish live Google Forms, CRM or Hostinger connectivity.</p>'''
for title,left,right in [('Station: dark style stripping → source-formatted reader','release4-station-net-metering.png','merged-station-net-metering.png'),('Dashboard preservation and quick resources','baseline-dashboard.png','merged-dashboard.png'),('Document focus and battery source','merged-focused-reader.png','merged-station-battery.png')]:html+=f'<h2>{title}</h2><section><a href="{left}"><img src="{left}" alt="{left}"></a><a href="{right}"><img src="{right}" alt="{right}"></a></section>'
(OUT/'visual-comparison.html').write_text(html+'</body></html>')
print('Saved baseline/Release 4/merged visual comparisons')
