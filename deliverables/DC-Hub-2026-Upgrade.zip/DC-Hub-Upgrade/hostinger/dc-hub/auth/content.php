<?php
/** Allowlisted rich text: preserve document formatting without executable HTML/CSS. */
declare(strict_types=1);
function dc_clean_style(string $css): string {
    $rules=[];
    foreach(explode(';',$css) as $rule){
        $kv=explode(':',$rule,2);if(count($kv)!==2)continue;
        [$key,$value]=array_map('trim',$kv);$key=strtolower($key);$value=strtolower($value);
        if(in_array($key,['color','background-color'],true)&&preg_match('/^rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)$/D',$value,$rgb)&&max((int)$rgb[1],(int)$rgb[2],(int)$rgb[3])<=255)$value=sprintf('#%02x%02x%02x',(int)$rgb[1],(int)$rgb[2],(int)$rgb[3]);
        $valid=match($key){
            'color','background-color'=>preg_match('/^#[a-f0-9]{3}(?:[a-f0-9]{3})?$/D',$value),
            'font-weight'=>preg_match('/^(normal|bold|[1-9]00)$/D',$value),
            'font-style'=>in_array($value,['normal','italic'],true),
            'text-decoration','text-decoration-line'=>in_array($value,['none','underline','line-through'],true),
            'font-size'=>preg_match('/^(?:[89]|[1-3][0-9]|4[0-8])(?:\.\d+)?(?:pt|px)$/D',$value),
            'font-family'=>preg_match('/^[a-z0-9 ,_-]{1,80}$/D',$value),
            'text-align'=>in_array($value,['left','center','right','justify'],true),
            'vertical-align'=>in_array($value,['super','sub','baseline'],true),
            'margin-top','margin-bottom'=>preg_match('/^\d{1,2}(?:\.\d+)?(?:pt|px)$/D',$value),
            'line-height'=>preg_match('/^(?:[1-3](?:\.\d+)?|\d{1,2}(?:\.\d+)?(?:pt|px))$/D',$value),
            default=>false
        };
        if($valid)$rules[]=$key.':'.$value;
    }
    return implode(';',$rules);
}
function dc_clean_html(string $html): string {
    // Google Docs exports use class rules for emphasis. Keep safe declarations
    // as inline styles before removing the stylesheet and document wrapper.
    $classStyles=[];
    if(preg_match_all('~<style[^>]*>(.*?)</style>~is',$html,$styles)){
        foreach($styles[1] as $sheet){
            if(preg_match_all('~\.([a-zA-Z_][\w-]*)\s*\{([^}]*)\}~',$sheet,$rules,PREG_SET_ORDER)){
                foreach($rules as $rule)$classStyles[$rule[1]]=dc_clean_style($rule[2]);
            }
        }
    }
    $doc=new DOMDocument();$old=libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="UTF-8"><html><body>'.$html.'</body></html>',LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);
    libxml_clear_errors();libxml_use_internal_errors($old);
    $allowed=['article','header','section','div','span','small','h1','h2','h3','h4','h5','h6','p','b','strong','em','i','u','s','ul','ol','li','blockquote','a','br','hr','mark','table','thead','tbody','tr','th','td','img'];
    $walk=function($parent)use(&$walk,$allowed,$classStyles){
        foreach(iterator_to_array($parent->childNodes) as $node){
            if($node instanceof DOMComment){$parent->removeChild($node);continue;}
            if(!($node instanceof DOMElement))continue;
            if(!in_array(strtolower($node->tagName),$allowed,true)){$parent->removeChild($node);continue;}
            $inherited=[];
            foreach(preg_split('/\s+/', $node->getAttribute('class')) as $class){if(!empty($classStyles[$class]))$inherited[]=$classStyles[$class];}
            if($inherited)$node->setAttribute('style',implode(';',$inherited).';'.$node->getAttribute('style'));
            foreach(iterator_to_array($node->attributes) as $attr){
                $name=strtolower($attr->name);$value=$attr->value;
                if($name==='style'){$clean=dc_clean_style($value);$node->removeAttribute($name);if($clean!=='')$node->setAttribute('style',$clean);}
                elseif($name==='class'&&preg_match('/^[a-zA-Z0-9 _-]{1,180}$/D',$value))continue;
                elseif($name==='href'&&$node->tagName==='a'&&str_starts_with($value,'https://')&&filter_var($value,FILTER_VALIDATE_URL))continue;
                elseif($node->tagName==='img'&&$name==='src'&&filter_var($value,FILTER_VALIDATE_URL)&&preg_match('~^https://(?:[a-z0-9-]+\.)*googleusercontent\.com/~i',$value))continue;
                elseif($node->tagName==='img'&&$name==='alt')continue;
                elseif(in_array($node->tagName,['td','th'],true)&&in_array($name,['rowspan','colspan'],true)&&preg_match('/^[1-9][0-9]?$/D',$value))continue;
                else $node->removeAttribute($name);
            }
            if($node->tagName==='a'){$node->setAttribute('target','_blank');$node->setAttribute('rel','noopener noreferrer');}
            $walk($node);
        }
    };
    $body=$doc->getElementsByTagName('body')->item(0);$walk($body);$out='';foreach($body->childNodes as $n)$out.=$doc->saveHTML($n);return $out;
}
