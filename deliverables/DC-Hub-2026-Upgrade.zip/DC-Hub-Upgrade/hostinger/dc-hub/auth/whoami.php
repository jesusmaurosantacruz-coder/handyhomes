<?php
require_once __DIR__.'/session.php';try{if(!dc_is_authenticated())dc_reply(['authenticated'=>false],401);dc_reply(['authenticated'=>true,'user'=>$_SESSION['dc_profile'],'csrf'=>dc_token(),'isManager'=>dc_role()==='Admin']);}catch(Throwable $e){dc_reply(['authenticated'=>false,'error'=>'Workspace connection unavailable'],503);}
