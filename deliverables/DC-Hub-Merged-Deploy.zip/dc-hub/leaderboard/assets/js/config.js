/* One connection setting, shared by the Hub section and the full app. */
window.DC_LEADERBOARD_CONFIG = Object.freeze({
  // Paste the /exec URL of your CRM Apps Script web app after updating its deployment.
  apiUrl: 'https://script.google.com/macros/s/AKfycbxzZg5ifk_9t__g4pWkvbt_DD6SUuXhIWXErbvvLUeoF3lB7G_OIkNRkipXUsvNtDYgaQ/exec',
  refreshSeconds: 60,
  defaultPeriod: 'week',
  reportingTimezone: 'America/Mexico_City'
});
