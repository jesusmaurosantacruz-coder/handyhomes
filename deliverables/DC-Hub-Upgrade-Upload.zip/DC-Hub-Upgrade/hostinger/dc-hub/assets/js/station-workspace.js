/* Optional Workspace documents augment the preserved campaign station. */
try {
 const who=await fetch('../auth/whoami.php',{credentials:'same-origin',cache:'no-store'}).then(r=>r.json());
 if(!who.authenticated)throw Error('Sign in required');
 async function api(action,params={}){const r=await fetch('../api/hub.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':who.csrf},body:JSON.stringify({action,params})});const d=await r.json();if(!r.ok||!d.ok)throw Error(d.error||'Document request failed');return d.data;}
 const [markets,resources]=await Promise.all([api('markets'),api('resources')]);
 function selector(target,label,entries){if(!entries.length)return;const pane=document.querySelector(target).closest('.station-pane'),bar=document.createElement('div');bar.className='workspace-document-select';const select=document.createElement('select');select.setAttribute('aria-label',label);const first=document.createElement('option');first.value='';first.textContent=label;select.append(first);entries.forEach((r,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent=r.name;select.append(o);});bar.append(select);pane.querySelector('.pane-head').after(bar);let generation=0;select.onchange=async()=>{const request=++generation;if(select.value==='')return;const entry=entries[Number(select.value)],body=document.querySelector(target);body.textContent='Loading Google Docs…';try{const d=await api('document',entry.kind==='resource'?{resourceId:entry.id}:{id:entry.id});if(request!==generation)return;body.innerHTML=d.html;if(d.canEdit){const a=document.createElement('a');a.href=d.url;a.target='_blank';a.rel='noopener noreferrer';a.textContent='Edit in Google Docs ↗';body.prepend(a);}}catch(e){if(request===generation)body.textContent=e.message;}};document.getElementById('campaign').addEventListener('change',()=>{generation++;select.value='';});}
 selector('#notes-body','Read live market notes',markets);
 selector('#script-body','Read a Google Docs script',resources.filter(r=>/script/i.test(r.section)&&/^https:\/\/docs\.google\.com\/document\//.test(r.url)).map(r=>({...r,kind:'resource'})));
} catch {
 // The existing local campaign content remains usable if no live documents are configured.
}
