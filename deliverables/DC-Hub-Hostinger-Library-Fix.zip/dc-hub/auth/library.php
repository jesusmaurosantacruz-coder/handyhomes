<?php
declare(strict_types=1);
/** Local resource rendering; the caller must enforce authentication/permissions. */
function dc_local_library(string $root): array {
    $file=$root.'/assets/data/library.json';
    if(!is_file($file))throw new RuntimeException('Your resource library is temporarily unavailable.');
    $data=json_decode(file_get_contents($file),true,512,JSON_THROW_ON_ERROR);
    if(!is_array($data['resources']??null))throw new RuntimeException('Your resource library is temporarily unavailable.');
    $items=[];
    foreach($data['resources'] as $item){
        if(!is_array($item))continue;
        $path=(string)($item['path']??'');
        if(!preg_match('~^assets/(?:scripts|market-notes|library)/[a-z0-9/-]+\.(?:html|pdf|txt|png|webp|jpg)$~iD',$path))continue;
        $real=realpath($root.'/'.$path);
        if(!$real||!str_starts_with($real,realpath($root).DIRECTORY_SEPARATOR)||!is_file($real))continue;
        $items[]=['name'=>(string)($item['name']??'Resource'),'section'=>(string)($item['section']??'Resources'),'description'=>(string)($item['description']??''),'path'=>$path];
    }
    return $items;
}
function dc_library_cards(string $root,string $prefix='../'): string {
    $escape=static fn(string $value):string=>htmlspecialchars($value,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
    try{$items=dc_local_library($root);}catch(Throwable $e){return '<p class="notice error" role="alert">Your resource library is temporarily unavailable. Please try again.</p>';}
    if(!$items)return '<p class="empty">Your resource library has no published documents yet.</p>';
    $out='<div class="resource-grid" data-local-library="server">';
    foreach($items as $r)$out.='<a class="resource-card" href="'.$escape($prefix.$r['path']).'" target="_blank" rel="noopener noreferrer"><small>'.$escape($r['section']).'</small><h3>'.$escape($r['name']).' ↗</h3><p>'.$escape($r['description']).'</p></a>';
    return $out.'</div>';
}
