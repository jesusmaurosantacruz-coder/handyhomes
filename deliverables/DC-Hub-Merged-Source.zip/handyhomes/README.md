# Digital Citizen Hub — merged operations release

Hostinger-compatible PHP/Apache application. The original Hub is the preservation baseline; Release 4 contributes workstation features. The six supplied DOCX files are authoritative for their corresponding scripts. The original 25-lesson typing application is integrated, not replaced.

- [Architecture and gap analysis](docs/ARCHITECTURE.md)
- [Deployment and rollback](docs/DEPLOYMENT.md)
- [Integrations and missing configuration](docs/INTEGRATIONS.md)
- [Manager guide](docs/MANAGER.md)
- [QA evidence and limits](docs/QA.md)
- [Management claims review](docs/MANAGEMENT-REVIEW.md)
- [File-by-file preservation manifest](docs/CHANGELOG.json)

Use the existing checkout in cloud tasks; tasks are already isolated. Do not create a worktree unless requested. `bash tools/start-dev.sh` starts an isolated local Apache copy with test-only credentials defined in `tools/sync_qa.py`; it never replaces source/production credentials. `python3 tests/functional.py`, `node tests/typing-backend.cjs`, and `python3 tools/audit.py` run the QA workflows. Chromium and Python Playwright are needed for browser tests. PHP 8.3 Apache is pinned by image digest in the startup script. No Node build or application dependencies are required.

Production credential files and historical backups remain local and are excluded from delivery archives and Git. The deployment package expects you to retain your live `auth/config.php` unchanged. No production deployment or Google data modification was performed during development.

`DEPLOY-INSTRUCTIONS.txt` is retained historical baseline documentation. The current release instructions are `docs/DEPLOYMENT.md`.
