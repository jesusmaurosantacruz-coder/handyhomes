"""Local Apache regression tests; isolated fixtures only. Never tests live production."""
import json,re,sys,time,subprocess
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=Path('/workspace/qa-artifacts');OUT.mkdir(exist_ok=True)
BASE='http://127.0.0.1:8080/dc-hub/'
results=[]
def check(name,condition,detail=''):
 results.append({'name':name,'passed':bool(condition),'detail':detail});print(('PASS ' if condition else 'FAIL ')+name,flush=True)
 if not condition:raise AssertionError(name+': '+str(detail))
def login(page,manager=False,base=BASE):
 page.goto(base+'login.php');page.locator('#email').fill('manager@example.test' if manager else 'agent@example.test');page.locator('#password').fill('Local-test-pass-2026');page.locator('button[type=submit]').click();page.wait_for_url(base);page.wait_for_load_state('domcontentloaded')
def csrf(page):return page.evaluate('window.DC_MANAGER_CSRF')
def post(page,obj,token=None):return page.request.post(BASE+'admin/api.php',headers={'X-CSRF-Token':token if token is not None else (page.evaluate('window.DC_MANAGER_CSRF') or manager_token)},data=obj)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 anon=browser.new_context(viewport={'width':1366,'height':768});anon.route('**/*',lambda r:r.continue_() if r.request.url.startswith('http://127.0.0.1:8080/') else r.fulfill(status=200,content_type='text/html',body='External destination captured only; not live-verified'));page=anon.new_page()
 for route in ['index.html','leaderboard/index.html','calendar/index.html','dialing-station/index.html','training/typing/index.html','training/audio/index.html','training/videos/index.html']:
  r=anon.request.get(BASE+route,max_redirects=0);check('Anonymous page gate '+route,r.status==302)
 for route in ['assets/data/team.json','assets/scripts/net-metering.html','assets/market-notes/texas.html','training/stream.php?id=sample','training/typing/api.php','admin/api.php','admin/upload.php']:
  r=anon.request.get(BASE+route);check('Anonymous data/API gate '+route,r.status in [401,403])
 for route in ['auth/config.php','auth/session.php','auth/typing-config.example.php','source-documents/x.docx','training/media/example.mp3','integrations/Typing.gs']:
  r=anon.request.get(BASE+route);check('Direct private path denied '+route,r.status==403)
 login(page);check('Agent login session',anon.request.get(BASE+'auth/whoami.php').json()['authenticated'])
 check('Agent manager API denied',anon.request.get(BASE+'admin/api.php?name=campaigns').status==403)
 check('Agent editor denied',anon.request.get(BASE+'admin/index.php').status==403)
 page.screenshot(path=str(OUT/'dashboard-1366.png'),full_page=True)
 page.goto(BASE+'index.html');page.wait_for_selector('[data-team] .member-card');check('Dashboard operational modules load',page.locator('[data-roll-call] .roll-card').count()==2 and page.locator('[data-team] .member-card').count()==3)
 for title in ['Solar One-Liners','Script Logic']:
  page.get_by_role('heading',name=title,exact=True).locator('..').get_by_role('button').click();page.wait_for_selector('#content-modal-body .source-document');check('Resource loader '+title,page.locator('#content-modal-body').inner_text().strip()!='');page.get_by_role('button',name='Close',exact=True).click()
 for route in ['campaigns/index.html','resources/index.html','leaderboard/index.html','calendar/index.html','training/audio/index.html','training/videos/index.html','training/typing/index.html']:
  r=page.goto(BASE+route);check('Protected route '+route,r.status==200)
 page.goto(BASE+'dialing-station/index.html');page.wait_for_selector('#campaign option',state='attached');campaigns=json.loads((ROOT/'assets/data/campaigns.json').read_text());visible=[c for c in campaigns if c['visible']]
 check('Visible station campaigns',page.locator('#campaign option').count()==len(visible))
 for c in visible:
  page.select_option('#campaign',c['id']);page.wait_for_function("!document.querySelector('#script-body').textContent.includes('Loading…') && !document.querySelector('#notes-body').textContent.includes('Loading…')")
  check('Script and notes '+c['id'],'Could not load' not in page.locator('#script-body').inner_text()+page.locator('#notes-body').inner_text())
  if c['type']!='fiber':check('Form destination '+c['id'],page.locator('#form-fallback').get_attribute('href')==c['submitUrl'])
 page.select_option('#campaign','maryland-solar');page.wait_for_selector('#script-body .source-document')
 style=page.evaluate("""() => {const body=document.querySelector('#script-body');return {bg:getComputedStyle(body).backgroundColor,colors:[...body.querySelectorAll('span')].map(s=>getComputedStyle(s).color),overflow:body.scrollWidth>body.clientWidth,highlight:[...body.querySelectorAll('span')].some(s=>['rgb(255, 244, 212)','rgb(255, 242, 150)','rgb(255, 242, 204)'].includes(getComputedStyle(s).backgroundColor))}}""")
 check('DOCX red blue and highlight preserved',style['bg']=='rgb(255, 255, 255)' and 'rgb(255, 0, 0)' in style['colors'] and 'rgb(0, 0, 255)' in style['colors'] and style['highlight'],str(style))
 check('Reader no horizontal overflow',not style['overflow'])
 page.locator('#script-body').evaluate('(el)=>el.scrollTop=200');check('Independent script scrolling',page.locator('#notes-body').evaluate('(el)=>el.scrollTop')==0)
 for w,h in [(1366,768),(1920,1080),(390,844)]:
  page.set_viewport_size({'width':w,'height':h});page.locator('#script-body').evaluate('(el)=>el.scrollTop=0');page.screenshot(path=str(OUT/f'station-net-metering-{w}.png'),full_page=True);check('Responsive page width '+str(w),page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
 page.set_viewport_size({'width':1366,'height':768});page.locator('#focus-script').click();check('Focused reader',page.locator('body').evaluate("el=>el.classList.contains('script-focused')"));page.keyboard.press('Escape');check('Focus restore',not page.locator('body').evaluate("el=>el.classList.contains('script-focused')"))
 page.select_option('#campaign','socal-solar');page.wait_for_selector('#script-body .source-document');page.screenshot(path=str(OUT/'station-battery-1366.png'),full_page=True)
 page.locator('#map-query').fill('Dallas Texas');
 with page.expect_popup() as popup:page.get_by_role('button',name='Search Google Maps').click()
 check('Maps destination',popup.value.url.startswith('https://www.google.com/maps/search/?api=1&query=Dallas%20Texas'));popup.value.close()
 page.select_option('#campaign','pennsylvania');
 with page.expect_popup() as popup:page.locator('#prequal').click()
 check('Solar popup destination',popup.value.url.startswith('https://docs.google.com/forms/'));popup.value.close()
 # Exercise the hidden original Roofing campaign by manager enabling it later; Fiber stays local.
 page.select_option('#campaign','fiber');page.locator('[name=customer]').fill('QA Example');check('Fiber local handoff',page.locator('#fiber-handoff').is_visible() and page.locator('#embedded-form').get_attribute('src') is None)
 page.goto(BASE+'training/typing/index.html');page.wait_for_selector('#agentName option:nth-child(2)',state='attached');page.select_option('#agentName','Robert Valencia');check('Typing 25 lessons retained',page.evaluate('LESSONS.length')==25)
 check('Typing Merida rotation',page.evaluate("CONFIG.timeZone==='America/Merida' && lessonIndex===((dayDiff(CONFIG.rotationStart,dateInZone())%25)+25)%25"))
 check('Typing unconfigured reported honestly',not page.request.get(BASE+'training/typing/api.php?action=config').json()['configured'])
 page.locator('#focusBtn').click();page.keyboard.type('x');check('Typing accuracy penalizes error',page.evaluate('mistakes')==1);page.locator('#resetBtn').click();check('Typing restart',page.evaluate('keystrokes===0 && !completed'))
 # Type full supplied passage with real browser beforeinput events. Controlled elapsed duration avoids a synthetic impossible WPM.
 text=page.evaluate('lesson.typing');page.locator('#typingInput').focus();page.keyboard.type(text[:1]);page.evaluate('startTime=Date.now()-180000');page.keyboard.type(text[1:]);check('Typing completion and local progress',page.evaluate('completed && !!readRecords()[today]'))
 check('Typing no false submission claim','not connected' in page.locator('#submitStatus').inner_text().lower());page.screenshot(path=str(OUT/'typing-completed.png'),full_page=True)
 page.goto(BASE+'logout.php');check('Logout clears session',page.request.get(BASE+'auth/whoami.php').status==401)
 manager=browser.new_context(viewport={'width':1366,'height':900});manager.route('**/*',lambda r:r.continue_() if r.request.url.startswith('http://127.0.0.1:8080/') else r.fulfill(status=200,content_type='text/html',body='External destination captured only; not live-verified'));m=manager.new_page();login(m,True);m.goto(BASE+'admin/index.php');check('Manager separate unlock',m.get_by_role('button',name='Unlock editor').count()==1)
 check('Locked manager API denied',manager.request.get(BASE+'admin/api.php?name=campaigns').status==403)
 m.locator('[name=manager_password]').fill('Local-editor-pass-2026');m.get_by_role('button',name='Unlock editor').click();m.wait_for_selector('#asset-form');m.wait_for_selector('#editor-fields input');check('Manager unlock works',bool(csrf(m)));manager_token=csrf(m)
 check('CSRF enforced',post(m,{'mode':'module','name':'typing','data':{'agents':['QA']}},'invalid').status==403)
 for module in ['campaigns','resources','schedule','team','site','leaderboard','typing','media']:
  data=manager.request.get(BASE+'admin/api.php?mode=module&name='+module).json()['data'];r=post(m,{'mode':'module','name':module,'data':data});check('Manager module roundtrip '+module,r.status==200,r.text())
 for module in ['typing','media','resources','marketnotes','scripts','campaigns']:
  m.locator('[data-module='+module+']').click();m.wait_for_timeout(100);check('Manager UI '+module,'unavailable' not in m.locator('#editor-fields').inner_text().lower() and not m.locator('#save-status').inner_text().startswith('Unknown'))
 r=post(m,{'mode':'script','name':'qa-rich-text.html','data':'<p style="color:#ff0000;background-color:#ffff00;font-weight:bold;position:fixed;background-image:url(https://bad.test)">Safe<script>alert(1)</script><img src=x onerror=alert(1)></p>'});check('Rich text save',r.status==200)
 saved=manager.request.get(BASE+'assets/scripts/qa-rich-text.html').text();check('Rich text sanitizer keeps colors removes executable content','color:#ff0000' in saved and 'background-color:#ffff00' in saved and all(x not in saved for x in ['<script','onerror','position:','url(']))
 r=post(m,{'mode':'module','name':'resources','data':[{'id':'bad','title':'Bad','description':'','category':'Test','script':'','url':'javascript:alert(1)','visible':True}]});check('Unsafe resource URL rejected',r.status==422)
 # Media fixtures: generated tone and color clip, no actual training/customer content.
 for ext,typ in [('mp3','audio'),('mp4','video')]:
  sample=OUT/('qa.'+ext)
  args=['ffmpeg','-y','-f','lavfi','-i','sine=frequency=440:duration=2','-codec:a','libmp3lame',str(sample)] if ext=='mp3' else ['ffmpeg','-y','-f','lavfi','-i','color=c=blue:s=320x240:d=2','-pix_fmt','yuv420p',str(sample)]
  subprocess.run(args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
  r=manager.request.post(BASE+'admin/upload.php',headers={'X-CSRF-Token':manager_token},multipart={'media':{'name':'qa.'+ext,'mimeType':'audio/mpeg' if ext=='mp3' else 'video/mp4','buffer':sample.read_bytes()}});check('Private '+typ+' upload',r.status==200,r.text())
  manifest=manager.request.get(BASE+'admin/api.php?name=media').json()['data'];item={'id':'qa-'+typ,'title':'QA '+typ,'description':'Generated test fixture','category':'Tool training','difficulty':'Beginner','type':typ,'file':r.json()['file'],'visible':True};manifest.append(item);check('Save '+typ+' manifest',post(m,{'mode':'module','name':'media','data':manifest}).status==200)
  stream=manager.request.get(BASE+'training/stream.php?id='+item['id'],headers={'Range':'bytes=0-99'});check('Seekable '+typ+' private stream',stream.status==206 and len(stream.body())==100)
  check('Media direct URL denied '+typ,manager.request.get(BASE+'training/media/'+item['file']).status==403)
  check('Media anonymous stream denied '+typ,browser.new_context().request.get(BASE+'training/stream.php?id='+item['id']).status==401)
  m.goto(BASE+'training/'+('audio' if typ=='audio' else 'videos')+'/index.html');m.get_by_role('button',name='QA '+typ).click();m.wait_for_function('document.querySelector("#player").readyState>=1');m.locator('#player').evaluate('(el)=>el.play()');m.wait_for_function('document.querySelector("#player").currentTime>0');check('Browser '+typ+' playback',m.locator('#player').evaluate('(el)=>!el.paused'));m.locator('#player').evaluate('(el)=>el.pause()');m.select_option('#speed','1.5');check('Playback speed '+typ,m.locator('#player').evaluate('(el)=>el.playbackRate===1.5'))
  m.screenshot(path=str(OUT/f'{typ}-library-fixture.png'),full_page=True)
 m.goto(BASE+'admin/index.php');m.wait_for_selector('#editor-fields input');r=manager.request.post(BASE+'admin/upload.php',headers={'X-CSRF-Token':manager_token},multipart={'media':{'name':'attack.mp3','mimeType':'audio/mpeg','buffer':b'<?php echo "bad";'}});check('Disguised executable upload rejected',r.status==422)
 # Enable roofing in isolated QA copy to verify its campaign actions without changing shipped baseline visibility.
 data=manager.request.get(BASE+'admin/api.php?name=campaigns').json()['data'];roof=next(c for c in data if c['type']=='roofing');roof['visible']=True;check('Manager campaign edit',post(m,{'mode':'module','name':'campaigns','data':data}).status==200)
 m.goto(BASE+'dialing-station/index.html');m.wait_for_selector('#campaign option',state='attached');m.select_option('#campaign',roof['id']);check('Exact roofing form',m.locator('#form-fallback').get_attribute('href')==roof['submitUrl'])
 with m.expect_popup() as popup:m.locator('#prequal').click()
 check('Roofing popup destination',popup.value.url.startswith(roof['submitUrl']));popup.value.close()
 OUT.joinpath('functional-results.json').write_text(json.dumps(results,indent=2));browser.close()
print('Completed',len(results),'checks')
