<?php
// Copy outside public_html as dc-hub-config.php. Never place real secrets in the site.
return ['google_client_id'=>'','google_client_secret'=>'','google_redirect_uri'=>'https://YOUR-DOMAIN/dc-hub/auth/google.php','apps_script_url'=>'','shared_secret'=>'','session_idle_seconds'=>3600];
