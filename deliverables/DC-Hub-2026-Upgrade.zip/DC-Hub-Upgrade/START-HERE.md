# Digital Citizen Hub — read-only operations upgrade

Start with docs/UPGRADE-2026.md. This release preserves the supplied PHP/Apache application and Apps Script automation. It adds local JSON market intelligence and resources, a read-only CRM/Calendar dashboard, ownership aliases/stable IDs, isolated short-lived caches, and a local textured Earth login.

- Website: `hostinger/dc-hub/`
- Complete Apps Script files: `apps-script/`
- Private configuration example: `hostinger/private-config/dc-hub-config.example.php`
- Setup, migration, preservation and validation: `docs/UPGRADE-2026.md`
- Market editing: `hostinger/dc-hub/assets/data/markets/README.md`

Use staging and a workbook copy first. Preserve live configuration, user directory, forms, calendar IDs, triggers and Script Properties. Do not replace a live project or install triggers blindly. Nothing in this delivery has been deployed to Google Workspace or Hostinger.
