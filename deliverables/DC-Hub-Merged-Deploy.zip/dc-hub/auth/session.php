<?php
declare(strict_types=1);

function dc_config(): array
{
    static $configuration = null;
    if ($configuration === null) {
        $configuration = require __DIR__ . '/config.php';
    }
    return $configuration;
}

function dc_begin_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    $isSecure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
    session_name('DC_AGENT_SESSION');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $isSecure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function dc_is_authenticated(): bool
{
    dc_begin_session();
    $valid = isset($_SESSION['dc_user_id'], $_SESSION['dc_last_active']);
    if (!$valid) return false;

    $elapsed = time() - (int)$_SESSION['dc_last_active'];
    if ($elapsed >= dc_config()['session_idle_seconds']) {
        unset($_SESSION['dc_user_id'], $_SESSION['dc_user_name'], $_SESSION['dc_user_email'], $_SESSION['dc_last_active'], $_SESSION['dc_editor_unlocked_at'], $_SESSION['dc_csrf']);
        return false;
    }

    $_SESSION['dc_last_active'] = time();
    return true;
}

function dc_token(): string
{
    dc_begin_session();
    if (empty($_SESSION['dc_csrf'])) {
        $_SESSION['dc_csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['dc_csrf'];
}

function dc_csrf_valid(string $candidate): bool
{
    return hash_equals(dc_token(), $candidate);
}
