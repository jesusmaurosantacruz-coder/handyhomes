// Leaderboards use the authenticated consolidated API. No public CRM endpoint.
window.DC_LEADERBOARD_CONFIG = {};
